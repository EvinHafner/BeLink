#ifndef GLOBALDATA_H
#define GLOBALDATA_H
#include <QString>
#include <QTcpSocket>
class GlobalData
{
public:
    //全局变量要加上static关键字
    QString uid;
    QString uname;
    QString uphoto;
    QString uip;
    QTcpSocket * socket;
    static GlobalData* globaldata;
    static GlobalData* getInstance()
    {
        if(globaldata == NULL)
        {
            globaldata = new GlobalData;
        }
        return globaldata;
    }
    GlobalData()
    {
        uid = "10000";
        uname = "0";
        uip = "0";
        socket = new QTcpSocket();
        globaldata = NULL;
    }
};

#endif // GLOBALDATA_H
