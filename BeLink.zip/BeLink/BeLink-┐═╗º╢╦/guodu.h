#ifndef GUODU_H
#define GUODU_H

#include <QWidget>

namespace Ui {
class guodu;
}

class guodu : public QWidget
{
    Q_OBJECT

public:
    explicit guodu(QWidget *parent = nullptr);
    ~guodu();

private:
    Ui::guodu *ui;
};

#endif // GUODU_H
