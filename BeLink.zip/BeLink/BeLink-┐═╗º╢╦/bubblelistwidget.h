#ifndef BUBBLELISTWIDGET_H
#define BUBBLELISTWIDGET_H

#include <QListWidget>

class BubbleListWidget : public QListWidget {
    Q_OBJECT

public:
    explicit BubbleListWidget(QListWidget *parent = nullptr);
    void addBubble(const QString &message);
    void setBubbleTextColor(const QColor &color);
    void setBubbleFont(const QFont &font);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    QColor bubbleTextColor = Qt::black; // 默认颜色为黑色
    QFont bubbleFont = QFont(); // 默认字体



};

#endif // BUBBLELISTWIDGET_H
