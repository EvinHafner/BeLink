#include "bubblelistwidget.h"
#include "chatwindow.h"
#include "GlobalData.h"
#include <QPainter>
#include <QFontMetrics>
#include<QDebug>
#include <QScrollArea>
#include <QAbstractItemView>
#include <QScrollBar>
#include <QFileInfo>
#include <QDateTime>



BubbleListWidget::BubbleListWidget(QListWidget *parent) :
    QListWidget(parent) {
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    // 设置滚动条显示策略为始终显示
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOn);

    QString setStyleSheet("QTextEdit {"
                               "   border: 1px solid #ccc;"
                               "   background-color: #f5f5f5;"
                               "   padding: 10px;"
                               "   border-radius: 10px;"
                               "   font-family: Arial;"
                               "   font-size: 12px;"
                               "   color: #333;"
                               "   box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);"
                               "}");

    QString scrollBarStylesheet =
        "QScrollBar:vertical {"
        "    background: transparent;"
        "    width: 12px;"
        "    margin: 0px 0px 0px 0px;"

        "   padding-top:12px;"   // 留出9px给上面和下面的箭头
        "   padding-bottom:12px;"
        "}"
        "QScrollBar::handle:vertical {"
        "    background: qlineargradient(spread:pad, x1:0.5, y1:1, x2:0.5, y2:0, stop:0 rgba(180, 180, 180, 180), stop:1 rgba(180, 180, 180, 100));"
        "    min-height: 20px;"
        "    border-radius: 10px;"
        "    border: 1px solid rgba(100, 100, 100, 100);"
        "    border-top-left-radius: 5px;"
        "    border-top-right-radius: 5px;"
        "    border-bottom-left-radius: 5px;"
        "    border-bottom-right-radius: 5px;"
        "}"
        "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {"
        "    height: 12px;"
        "}"
        "QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {"
        "    background: none;"
        "}"
        "QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {"
        "    width: 15px;"
        "    height: 15px;"
        "    background: gray; /* 设置箭头颜色 */"
        "}";

    verticalScrollBar()->setStyleSheet(scrollBarStylesheet);

}

void BubbleListWidget::addBubble(const QString &message) {
    QListWidgetItem *item = new QListWidgetItem(this);
    item->setData(Qt::UserRole, message);


}
void BubbleListWidget::setBubbleFont(const QFont &font)
{
    bubbleFont = font;
    update(); // 触发重新绘制
}

void BubbleListWidget::setBubbleTextColor(const QColor &color)
{
    bubbleTextColor = color;
    //qDebug()<<"color:"<<color;
    update(); // 触发重新绘制
}

void BubbleListWidget::paintEvent(QPaintEvent *event) {
    QListView::paintEvent(event);
    QPainter painter(viewport());
    painter.setRenderHint(QPainter::Antialiasing);

    // 获取当前的滚动偏移量
    int scrollOffset = verticalScrollBar()->value();
    //qDebug() << "now scrollOffset:" << scrollOffset;
    // 绘制多个矩形，根据滚动偏移量进行调整
    int startY = 10 - scrollOffset;
    //int currentMaximum = verticalScrollBar()->maximum();
    //qDebug() << "now currentMaximum:" << currentMaximum;
    //qDebug() << "now windowheight" << height();

    //qDebug() << "put:" << startY;
    //for (int i = 0; i < 100; ++i) {
   //     painter.setBrush(QBrush(QColor(255, 0, 0, 128)));
       // painter.drawRect(10, startY + i * 60, 50, 50);
    //}

    GlobalData *globaldata = GlobalData::getInstance();

    int y = 0;

    for (int i = 0; i < count(); ++i) {
        QListWidgetItem *item = this->item(i);
    // if(count() == 0)
    //     return;

    //    QListWidgetItem *item = this->item(count()-1);
        QString message = item->data(Qt::UserRole).toString(); // 获取消息内容
        bool isSystem1Message = false;
        bool isSystem2Message = false;
        bool isSystem3Message = false;

        if (message.startsWith("[System1]")) {
            isSystem1Message = true;
            message = message.mid(QString("[System1]").length());
            //qDebug() << "put:" << message;
        } else if (message.startsWith("[System2]")) {
            isSystem2Message = true;
            message = message.mid(QString("[System2]").length());
            //qDebug() << "put:" << message;
        } else if (message.startsWith("[System3]")) {
            isSystem3Message = true;
            message = message.mid(QString("[System3]").length());
            //qDebug() << "put: image" << message;
        }


        QFontMetrics fontMetrics(font()); // 获取当前字体的度量信息
        QSize textSize = fontMetrics.size(Qt::TextSingleLine, message); // 计算单行文本尺寸
        item->setSizeHint(QSize(item->sizeHint().width(),
                                textSize.height()+fontMetrics.height()));

        QRect bubbleRect = visualItemRect(item); // 获取项在视口中的矩形区域
        bubbleRect.setWidth(textSize.width() + 20); // 调整气泡宽度以适应文本
        bubbleRect.setHeight(textSize.height()+fontMetrics.height()); // 调整气泡高度以适应文本和昵称

        bubbleRect.moveTop(startY +y - 10); // 设置气泡的纵向位置
        bubbleRect.moveLeft(60); // 设置气泡的横向位置


        painter.setPen(Qt::black); // 设置文字颜色

        //*****//
        //在这加判断条件，为我发送还是别人发送
        //*****//
    // if (!chatWindow::isMyMessage)
    if(chatWindow::senderID[i/4] != globaldata->uid)
    {
        //以下是别人发送
        if (isSystem1Message) {

            QRect customRect = QRect(10, startY +y, width() - 20, bubbleRect.height());
            painter.drawText(customRect, Qt::AlignCenter, message);// 系统消息1居中显示

            y += bubbleRect.height(); // 更新纵向位置


        } else if (isSystem2Message) {
            QRect customRect(60, startY +y, 200, 30);

            painter.drawText(customRect, Qt::AlignLeft | Qt::AlignTop, message);
            y += bubbleRect.height(); // 更新纵向位置

        } else if(isSystem3Message){

            QRect avatarRect(10, startY +y, 40, 40); // 头像矩形的位置和尺寸

            //绘制头像
            QPixmap avatarPixmap(message);
            painter.drawPixmap(avatarRect, avatarPixmap);

        }
          else {
            if(message.startsWith("pic@")){
                message = message.mid(QString("pic@").length());
                QPixmap avatarPixmap(message);
                QRect avatarRect(60, startY +y, avatarPixmap.width(), avatarPixmap.height());
                painter.drawPixmap(avatarRect, avatarPixmap);
                y += avatarPixmap.height(); // 更新纵向位置
            }
            else{

                painter.setBrush(QColor(200, 220, 255)); // 设置气泡的填充颜色
                painter.setPen(Qt::NoPen);
                painter.drawRoundedRect(bubbleRect, 10, 10); // 绘制气泡
                painter.setPen(bubbleTextColor); // 设置文字颜色
                painter.setFont(bubbleFont); // 设置文字字体

                painter.drawText(bubbleRect.adjusted(10, 5, -10, -5), Qt::AlignLeft | Qt::AlignTop, message); // 其他消息左上对齐显示
                y += bubbleRect.height(); // 更新纵向位置

            }
        }

    }
    // if (chatWindow::isMyMessage)
    if(chatWindow::senderID[i/4] == globaldata->uid)
    {
    //以下是我发送
    if (isSystem1Message) {

        QRect customRect = QRect(10, startY +y, width() - 20, bubbleRect.height());
        painter.drawText(customRect, Qt::AlignCenter, message);// 系统消息1居中显示
        //painter.drawText(10, startY +i*30, message);// 系统消息1居中显示
        y += bubbleRect.height(); // 更新纵向位置
        //qDebug() << "now y:" << y;

    } else if (isSystem2Message) {
        QRect customRect(viewport()->width() - bubbleRect.width() - 40, startY +y, 200, 30);

        painter.drawText(customRect, Qt::AlignLeft | Qt::AlignTop, message);
        y += bubbleRect.height(); // 更新纵向位置
        //qDebug() << "now y:" << y;
    } else if(isSystem3Message){
        qDebug() << "width: " << width();
        QRect avatarRect(viewport()->width() - bubbleRect.width() + 90, startY +y, 40, 40); // 头像矩形的位置和尺寸

        // 绘制头像
        QPixmap avatarPixmap(message);
        painter.drawPixmap(avatarRect, avatarPixmap);

        //qDebug() << "now y:" << y;
    }
      else {
        if(message.startsWith("pic@")){
            message = message.mid(QString("pic@").length());
            QPixmap avatarPixmap(message);
            QRect avatarRect(viewport()->width() - avatarPixmap.width(), startY +y, avatarPixmap.width(), avatarPixmap.height());
            painter.drawPixmap(avatarRect, avatarPixmap);
            y += avatarPixmap.height(); // 更新纵向位置

            // 确定目标文件夹路径
            QString destinationFolderPath = "路径/到/您的/目标文件夹/";
            // 生成图片的唯一文件名
            QFileInfo fileInfo(message);
            QString uniqueFileName = QString("%1_%2.%3")
                .arg(QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss"))
                .arg(qrand() % 1000)  // 添加一个随机数以确保唯一性
                .arg(fileInfo.suffix());
            // 构造目标文件的完整路径
            QString destinationFilePath = destinationFolderPath + uniqueFileName;
            QFile::copy(message, destinationFilePath);
        }
        else{
            qDebug() << "write: image" << message;
            bubbleRect.moveLeft(viewport()->width() - bubbleRect.width() - 60);
            //bubbleRect.moveLeft(width()-110); // 设置气泡的横向位置
            painter.setBrush(QColor(200, 220, 255)); // 设置气泡的填充颜色
            painter.setPen(Qt::NoPen);
            painter.drawRoundedRect(bubbleRect, 10, 10); // 绘制气泡
            painter.setPen(bubbleTextColor); // 设置文字颜色
            painter.setFont(bubbleFont); // 设置文字字体
            //qDebug()<<"color:"<<bubbleTextColor;
            painter.drawText(bubbleRect.adjusted(10, 5, -10, -5), Qt::AlignLeft | Qt::AlignTop, message); // 其他消息左上对齐显示
            y += bubbleRect.height(); // 更新纵向位置
            //qDebug() << "now y:" << y;
        }
    }
    }
}

    if(y >= height())
    // 在添加新消息后，更新滚动条的最大值, 并更新到最大值位置
    verticalScrollBar()->setMaximum(20 + y-height());

}

