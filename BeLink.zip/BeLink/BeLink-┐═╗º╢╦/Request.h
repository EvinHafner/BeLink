#ifndef REQUEST_H
#define REQUEST_H
#include "RequestType.h"
#include <QMessageBox>
#include <QtCore>

class Request{
public:

    RequestType requestType;
    int msgNum;
    QStringList msgList;

    Request();
    Request(const QByteArray &request);
    //识别函数，接收传输编码，识别行为类型
    static RequestType identifyType(const QByteArray &request);
    //编码转请求，接收编码，返回封装的请求类
    void codeToRequest(const QByteArray &request);
    //请求转编码
    QByteArray requestToCode();

};


//输入一个数字/字符串，返回它的长度并编码为长度字符串，如输入10246，返回0005；stri返回0004
QString sthToLengthString(int num);
QString sthToLengthString(QString str);
QString sthToLengthString(QStringList qslist);
#endif // REQUEST_H
