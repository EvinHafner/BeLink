#ifndef NEWPWD_H
#define NEWPWD_H

#include <QWidget>
#include <QTcpSocket>


namespace Ui {
class newpwd;
}

class newpwd : public QWidget
{
    Q_OBJECT

public:
    explicit newpwd(QWidget *parent = nullptr);
    ~newpwd();

private slots:
    void on_pushButton_clicked();

//    void sendRequest();//发送信号

//    void recivmessage();//接受信号

private:
    Ui::newpwd *ui;
    QTcpSocket *m;
};

#endif // NEWPWD_H
