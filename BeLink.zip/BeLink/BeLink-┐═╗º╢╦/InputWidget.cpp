#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QDebug>
#include "InputWidget.h"
#include "Request.h"
#include "LoginWindow.h"
    InputWidget::InputWidget(QWidget* parent) : QWidget(parent) {
        setWindowTitle("添加好友");

        lineEdit = new QLineEdit(this);
        lineEdit->setPlaceholderText("请输入ID号");

        submitButton = new QPushButton("添加", this);

        QVBoxLayout* layout = new QVBoxLayout(this);
        layout->addWidget(lineEdit);
        layout->addWidget(submitButton);

        QObject::connect(submitButton, &QPushButton::clicked, this, &InputWidget::handleSubmit);

        setLayout(layout);
    }


    void InputWidget::handleSubmit()
    {
        //传inputText到服务器
        GlobalData* globaldata = GlobalData::getInstance();

        //尝试连接服务器
//        this->m=new QTcpSocket(this);
//        this->m->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
//        connect(this->m, SIGNAL(connected()), this, SLOT(sendRequest()));

        //ADD_FRIEND_REQUEST = 9,//加好友，需要双方id
        //00090002____Id1____Id2
        //返回指令是1013,1014
        QString text = lineEdit->text();
        Request re;
        re.msgNum=2;
        re.requestType = RequestType::ADD_FRIEND_REQUEST;
        re.msgList.append(globaldata->uid);
        re.msgList.append(text);

        QString stext=re.requestToCode();
        globaldata->socket->write(stext.toUtf8());
        if(globaldata->socket->waitForReadyRead())
        {
            QByteArray byteArray = globaldata->socket->readAll();
            QString rmessage=byteArray;
            //处理编码为请求
            Request re2;
            re2.codeToRequest(byteArray);
            //ADD_FRIEND_SUCCESS = 1013,//添加好友成功
            //1013
            //请求指令是0009
            if(re2.requestType==RequestType::ADD_FRIEND_SUCCESS)
            {
                QMessageBox::information(this,"添加好友","添加好友成功");

            }
            //ADD_FRIEND_FAIL = 1014,//添加好友失败
            //1014
            //请求指令是0009
            if(re2.requestType==RequestType::ADD_FRIEND_FAIL)
            {
                QMessageBox::information(this,"添加好友","添加好友失败");
            }
        }

    }

//    void InputWidget::sendRequest()
//    {
//        GlobalData* globaldata = GlobalData::getInstance();
//        //ADD_FRIEND_REQUEST = 9,//加好友，需要双方id
//        //00090002____Id1____Id2
//        //返回指令是1013,1014
//        QString text = lineEdit->text();
//        Request re;
//        re.msgNum=2;
//        re.requestType = RequestType::ADD_FRIEND_REQUEST;
//        re.msgList.append(globaldata->uid);
//        re.msgList.append(text);

//        QString stext=re.requestToCode();
//        this->m->write(stext.toUtf8());
//        //接受服务器信号
//        connect(this->m,SIGNAL(readyRead()),this,SLOT(recivmessage()));

//    }

//    void InputWidget::recivmessage()
//    {
//        QByteArray byteArray = this->m->readAll();
//        QString rmessage=byteArray;
//        //处理编码为请求
//        Request re2;
//        re2.codeToRequest(byteArray);
//        //ADD_FRIEND_SUCCESS = 1013,//添加好友成功
//        //1013
//        //请求指令是0009
//        if(re2.requestType==RequestType::ADD_FRIEND_SUCCESS)
//        {
//            QMessageBox::information(this,"添加好友","添加好友成功");

//        }
//        //ADD_FRIEND_FAIL = 1014,//添加好友失败
//        //1014
//        //请求指令是0009
//        if(re2.requestType==RequestType::ADD_FRIEND_FAIL)
//        {
//            QMessageBox::information(this,"添加好友","添加好友失败");
//        }
//    }

//    QString InputWidget::Mark(QString m)
//    {
//        QString a="0000";
//        int b,i,c;
//        c=3;
//        b=m.length();
//        for(i=b-1;i>=0;i--)
//        {
//            a[c]=m[i];
//            c--;
//        }
//       return a;
//    }
