#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QTreeWidget>
#include "MyWidget.h"
#include "MainWindow.h"

MainWindow::MainWindow(QWidget* parent ) : QWidget(parent) {
    setWindowTitle("BeLink");

    MyWidget* widget = new MyWidget();
    widget->setWindowTitle("MyTreeWidget控件");

    QPushButton* addFriendButton = new QPushButton("添加朋友", this);

    QWidget* infoWidget = createInfoWidget(parent,widget);
    QTreeWidget* treeWidget = createTreeWidget(parent,widget);

    treeWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->addWidget(infoWidget);
    layout->addWidget(treeWidget);
    layout->addWidget(addFriendButton);
    setStyleSheet("border: 1px solid black;");

    connect(addFriendButton, &QPushButton::clicked, this, &MainWindow::openInputWidget);
}
QTreeWidget* MainWindow::createTreeWidget(QWidget* parent, MyWidget* widget)
{
    // 创建树形部件
    QTreeWidget* treeWidget = new QTreeWidget(parent);
    treeWidget->setHeaderLabel("朋友列表");

    // 遍历查询结果创建分组和联系人节点

        QString groupName="a";
        QTreeWidgetItem* groupItem = new QTreeWidgetItem(treeWidget);
        groupItem->setText(0, groupName);

        // 获取该分组下的联系人信息

            // 创建联系人节点
            QString contactName="A";
            QTreeWidgetItem* contactItem = new QTreeWidgetItem(groupItem);
            contactItem->setText(0, contactName);
            QFont contactFont;
            contactFont.setPointSize(16); // 设置字体大小
            contactItem->setFont(0, contactFont);
            QString avLocation=":/Headers/dog.jpg";
            QPixmap contactPixmap(avLocation);
            contactPixmap = contactPixmap.scaled(QSize(40, 40), Qt::KeepAspectRatio, Qt::SmoothTransformation); // 设置头像大小
            contactItem->setIcon(0, QIcon(contactPixmap));
            groupItem->addChild(contactItem);

        // 将分组节点添加到树形部件中
    treeWidget->addTopLevelItem(groupItem);
    QObject::connect(treeWidget, &QTreeWidget::itemClicked, widget, &MyWidget::itemClicked);
    treeWidget->setIconSize(QSize(30, 30));
    return treeWidget;
}

QWidget* MainWindow::createInfoWidget(QWidget* parent, MyWidget* widget) {
    QWidget* infoWidget = new QWidget(parent);
    infoWidget->setWindowTitle("个人信息");
    QHBoxLayout* infoLayout = new QHBoxLayout(infoWidget);
    infoLayout->setContentsMargins(10, 10, 10, 10);
    infoLayout->setSpacing(10);

    QString location;//头像存储的地址
    // 创建头像标签
    ClickableLabel* avatarLabel = createAvatarLabel(infoWidget,widget,location);


    // 将头像标签和IP地址标签添加到容器布局中
    infoLayout->addWidget(avatarLabel);

    return infoWidget;
}
ClickableLabel* MainWindow::createAvatarLabel(QWidget* parent, MyWidget* widget,QString loc)
{
    ClickableLabel* avatarLabel = new ClickableLabel(parent);
    QPixmap avatarPixmap(loc);
    avatarPixmap = avatarPixmap.scaled(QSize(70, 70), Qt::KeepAspectRatio, Qt::SmoothTransformation);
    avatarLabel->setPixmap(avatarPixmap);
    avatarLabel->setMouseTracking(true);
    avatarLabel->setAttribute(Qt::WA_Hover);
    QObject::connect(avatarLabel, &ClickableLabel::clicked, widget, &MyWidget::avatarClicked);

    return avatarLabel;
}

void MainWindow::rebuildUI(QWidget* window, MyWidget* widget) {
    QVBoxLayout* layout = dynamic_cast<QVBoxLayout*>(window->layout());
    if (layout) {
        // 移除现有部件
        while (QLayoutItem* item = layout->takeAt(0)) {
            delete item->widget();
            delete item;
        }

        // 重新创建部件
        QWidget* infoWidget = createInfoWidget(window, widget);
        QTreeWidget* treeWidget = createTreeWidget(window, widget);
        QPushButton *addFriend = new QPushButton("添加朋友", window);
        QObject::connect(addFriend, &QPushButton::clicked, [&]() {
                openInputWidget();
            });
        treeWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        // 将部件添加到布局中
        layout->addWidget(infoWidget);
        layout->addWidget(treeWidget);
        layout->addWidget(addFriend);
        QObject::connect(addFriend, &QPushButton::clicked, [&]() {
                openInputWidget();
            });
        window->update();
    }
}

void MainWindow::openInputWidget() {
    InputWidget* inputWidget = new InputWidget();
    inputWidget->show();
}
