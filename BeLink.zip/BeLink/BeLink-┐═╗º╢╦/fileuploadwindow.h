#ifndef FILEUPLOADWINDOW_H
#define FILEUPLOADWINDOW_H

#include <QDialog>
#include <QLineEdit>
#include <QPushButton>
#include <QFileDialog>
#include <QVBoxLayout>
#include <QFile>

class FileUploadWindow : public QDialog
{
    Q_OBJECT

public:
    FileUploadWindow(QWidget *parent = nullptr);

signals:
    void fileSelected(const QString &filePath);

private slots:
    void selectFile();
    void uploadFile();

private:
    QLineEdit *filePathLineEdit;
};

#endif // FILEUPLOADWINDOW_H
