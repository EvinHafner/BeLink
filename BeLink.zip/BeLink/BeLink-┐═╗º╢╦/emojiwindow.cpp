#include "emojiwindow.h"

EmojiWindow::EmojiWindow(QWidget *parent)
    : QDialog(parent)
{
    emojis << "😀" << "😁" << "😂" << "🤣" << "😃" << "😄" << "😅" << "😆" << "😉" << "😊";

    QGridLayout *layout = new QGridLayout;

    int row = 0;
    int col = 0;
    for (const QString &emoji : emojis) {
        QPushButton *emojiButton = new QPushButton(emoji, this);
        connect(emojiButton, &QPushButton::clicked, this, &EmojiWindow::emojiButtonClicked);
        layout->addWidget(emojiButton, row, col);
        col++;
        if (col == 5) {
            col = 0;
            row++;
        }
    }

    setLayout(layout);
    setWindowTitle("Select Emoji");
    resize(300, 200);
}

void EmojiWindow::emojiButtonClicked()
{
    QPushButton *emojiButton = qobject_cast<QPushButton *>(sender());
    if (emojiButton) {
        emit emojiSelected(emojiButton->text());
        close();
    }
}
