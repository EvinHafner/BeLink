#ifndef EMOJIWINDOW_H
#define EMOJIWINDOW_H

#include <QDialog>
#include <QPushButton>
#include <QGridLayout>

class EmojiWindow : public QDialog
{
    Q_OBJECT

public:
    EmojiWindow(QWidget *parent = nullptr);

signals:
    void emojiSelected(const QString &emoji);

private slots:
    void emojiButtonClicked();

private:
    QList<QString> emojis;
};

#endif // EMOJIWINDOW_H
