#ifndef CHANGEPWD_H
#define CHANGEPWD_H

#include <QWidget>

namespace Ui {
class changepwd;
}

class changepwd : public QWidget
{
    Q_OBJECT

public:
    explicit changepwd(QWidget *parent = nullptr);
    ~changepwd();

private slots:
    void on_pushButton_clicked();

    void sendRequest();//发送信号

    void recivmessage();//接受信号

private:
    Ui::changepwd *ui;
};

#endif // CHANGEPWD_H
