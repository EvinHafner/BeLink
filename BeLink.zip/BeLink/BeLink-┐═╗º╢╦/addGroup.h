#ifndef ADDGROUP_H
#define ADDGROUP_H

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QDebug>
#include <QTcpSocket>

class addGroup: public QWidget {
public:
    addGroup(QWidget* parent = nullptr) ;

private slots:
    void handleSubmit() ;
    QString Mark(QString m);//字符串长度的格式转换

    void sendRequest();//发送信号

    void recivmessage();//接受信号

private:
    QLineEdit* lineEdit;
    QPushButton* submitButton;
    QTcpSocket *m;

};


#endif // ADDGROUP_H
