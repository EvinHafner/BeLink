#ifndef CHATWINDOW_H
#define CHATWINDOW_H

#include <QMainWindow>
#include <QTextBrowser>
#include <QLineEdit>
#include <QPushButton>
#include <QLabel>
#include <QTcpSocket>
#include <QColorDialog>
#include <QFile>

#include "emojiwindow.h"
#include "fileuploadwindow.h"
#include "bubblelistwidget.h"
#include "Message.h"
#include "UserInfo.h"
#include "RequestType.h"
#include "Request.h"
#include "imageuploadwindow.h"


class chatWindow : public QMainWindow
{
    Q_OBJECT

public:
    chatWindow(UserInfo me, int friendID, QWidget *parent = nullptr, bool isGroup = false);
    ~chatWindow();

    void showUI();
    void showGroupUI();
    QString getLocalIPv4();
    void updateMsg();

    static bool isMyMessage;
    static QStringList senderID;
    void sleep(unsigned int msec);
    void closeEvent ( QCloseEvent * e );

    QByteArray buffer;

    // 用于处理多条reply同时被读取的情况
    QList<Request> splitReply(const QByteArray &code); // 将读取到的QByteArray分割为requestList
    // Request codeToRequest(const QByteArray &code); // 读取一条request并返回
    int lengthOfRequest(const Request &re); // 计算request字节数

private slots:

    void sendMessage();
    void insertEmoji(const QString &emoji);
    void readyRead();
    void openEmojiWindow();
    void openFileUploadWindow();
    void quit();

    void tryConnect();
    void uploadFile(const QString &filePath);
    void sendData();

    void showMessageList();

    void changeBubbleFontColor();
    void changeBubbleTextColor();
    void toggleAnonymous();
    void updateUserInfo();

    void openChatRequest();
    void msgInfoRequest(const QString &msgID);
    void delMsgRequest(const QString &msgID);
    void closeChatRequest();
    void sendMsgRequest(const QString &msgContent);

    void openGroupChatRequest();
    void groupMembersIDRequest();
    void sendGroupMsgRequest(const QString &msgContent);
    void delGroupMsgRequest(const QString &msgID);
    void closeGroupChatRequest();
    void userInfoRequest(int friendID);

    void setselectedimage(const QString &imagePath);
    void openImageUploadWindow();

    void MemberInfoLabel(const UserInfo &user, QListWidget& Display) const;
private:
    UserInfo me;
    UserInfo frd;

    int friendID;
    bool isGroup;

    QList<Message> msgList;
    QList<UserInfo> userList;

    QString nickname;
    QString avatarPath;

    //
    QFile file;
    QString filename;
    qint64 filesize;
    qint64 sendsize;
    qint64 recvsize;

    BubbleListWidget *chatDisplay;
    QVBoxLayout *InfoDisplay;
    QListWidget *InfoDisplay1;
    QLineEdit *messageInput;
    QPushButton *sendButton;
    QPushButton *closeButton;
    QPushButton *messageButton;
    EmojiWindow *emojiWindow;
    FileUploadWindow *fileUploadWindow;
    ImageUploadWindow *imageuploadwindow;

    bool isAnonymous = false;

    QTimer *timer;

    QListWidget *userInfoList;
    QLabel *userInfo1;
    QLabel *userInfo2;

    QTcpSocket *socket;
    //QColor color;
    //QFont font;

    void init();
    void initGroup();

    void updateInfo();
    void showNewMsg(const Message &newMsg);

    void openChatReply(const Request &reply);
    void msgInfoReply(const Request &reply);
    bool delMsgSuccess(const Request &reply);
    bool closeChatSuccess(const Request &reply);
    void sendMsgReply(const Request &reply);
    void openGroupChatReply(const Request &reply);
    void groupMembersIDReply(const Request &reply);
    void sendGruopMsgReply(const Request &reply);
    bool delGroupMsgSuccess(const Request &reply);
    bool closeGroupChatSuccess(const Request &reply);
    void userInfoReply(const Request &reply);
    void clock(int msc);
};

#endif // CHATWINDOW_H

