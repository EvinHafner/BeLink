﻿#include "chatwindow.h"
// #include "chatserver.h"
#include "Message.h"
#include "GlobalData.h"
#include <QApplication>
#include <QHostInfo>
#include <QNetworkInterface>
#include <QDebug>
#include <QPixmap>
#include <QDateTime>
#include <QColorDialog>
#include <QColor>
#include <QPalette>
#include <QFontDialog>
#include <QMessageBox>
#include <QTimer>
#include <QTime>
#include <QByteArray>
#include <QCloseEvent>

// bool chatWindow::isMyMessage = false;
QStringList chatWindow::senderID;

GlobalData *gbdata = GlobalData::getInstance();

void chatWindow::sleep(unsigned int msec)
{
    //currentTime返回当前的时间，用当前的时间加上我们要延时的时间mesc得到一个新的时刻
    QTime reachTime = QTime::currentTime().addMSecs(msec);
    while(QTime::currentTime()<reachTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
}

QList<Request> chatWindow::splitReply(const QByteArray &code)
{
    QByteArray reList = code;
    QString temp = QString::fromUtf8(code);
    QList<Request> requestList;
    QStringList replyList = temp.split('\n');

    foreach(QString reply, replyList){
        if (reply == "")
            continue;
        Request re;
        re.codeToRequest(reply.toUtf8());
        requestList.append(re);
    }
    /*
    while (reList.length() > 0)
    {
        Request re;
        re.codeToRequest(reList);
        requestList.append(re);
        int len = lengthOfRequest(re);
        reList = reList.mid(len);
    }
*/
    return requestList;
}
/*
Request chatWindow::codeToRequest(const QByteArray &code)
{
    Request re;
    //int len = 8;
    re.requestType = RequestType::MESSAGE_INFOMATION_REPLY;
    QString tmpMsgNum=code.mid(4,4);
    re.msgNum = tmpMsgNum.toUInt();
    //读取完类型和信息条数后，循环读取后面的信息具体内容
    QString pureMsg=code.mid(8);
    for(int i = 0; i < re.msgNum; i++){
        quint16 length=pureMsg.mid(0,4).toUInt();
        pureMsg=pureMsg.mid(4);
        //len += 4;
        re.msgList.append(pureMsg.mid(0,length));
        pureMsg=pureMsg.mid(length);
        //len += length;
    }
    return re;
}
*/
int chatWindow::lengthOfRequest(const Request &re)
{
    int length = 4;
    if (re.msgNum != 0)
    {
        length += 4;
        for (QString msg : re.msgList) {
            length += msg.length();
        }
    }
    return length;
}

chatWindow::chatWindow(UserInfo user, int frdID, QWidget *parent, bool isGroup)
    : QMainWindow(parent)
{
    me = user;
    friendID = frdID;
    qDebug() << frdID;
    chatWindow::isGroup = isGroup;
    if(isGroup)
        initGroup();
    else
        init();

    /*QString userHtml1 ="<img src='" + avatarPath + "' width='30' height='30'>"
            + nickname + "\nIP Address: " + ipAddress;
    // need to get user2's info
    QString userHtml2 ="<img src='" + avatarPath + "' width='30' height='30'>"
            + nickname + "\nIP Address: " + ipAddress;
    */
    //userInfo1->setText(userHtml1);
    //userInfo2->setText(userHtml2);

    // tryConnect();
}

chatWindow::~chatWindow()
{
    // 清理资源
    if(isGroup)
        closeGroupChatRequest();
    else
        closeChatRequest();
    // socket->disconnectFromHost();
}

void chatWindow::init()
{
    showUI();
    tryConnect();
    // QByteArray data1 = "00090002000510004000510005";
    // socket->write(data1);
    openChatRequest();
    avatarPath = me.getAvatarUrl();
    nickname = me.getName();
    updateInfo();
    updateMsg();

}

void chatWindow::initGroup()
{
    showGroupUI();
    tryConnect();
    openGroupChatRequest();
    avatarPath = me.getAvatarUrl();
    nickname = me.getName();

    updateInfo();
    updateMsg();
}

void chatWindow::updateInfo()
{
    if (!timer)
    {
        timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &chatWindow::updateUserInfo);
        timer->start(200);
    }
}

QString chatWindow::getLocalIPv4()
{
    QString ipAddress = QHostInfo::localHostName();
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();

    for (const QHostAddress &address : ipAddressesList) {
        if (address.protocol() == QAbstractSocket::IPv4Protocol && !address.isLoopback())
            ipAddress = address.toString();
    }
    return ipAddress;
}

void chatWindow::updateMsg()
{
    if (!isGroup)
    {
        if (!timer)
        {
            timer = new QTimer(this);
            connect(timer, &QTimer::timeout, this, &chatWindow::openChatRequest);
            timer->start(200);
        }
    }
    else
    {
        if (!timer)
        {
            timer = new QTimer(this);
            connect(timer, &QTimer::timeout, this, &chatWindow::openGroupChatRequest);
            timer->start(200);
        }
    }


}

void chatWindow::showUI()
{
    chatDisplay = new BubbleListWidget();
    chatDisplay->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
    // chatDisplay->setStyleSheet();

    InfoDisplay = new QVBoxLayout(this);
    messageInput = new QLineEdit(this);
    sendButton = new QPushButton("Send", this);
    closeButton = new QPushButton("Close", this);
    messageButton = new QPushButton("message history", this);
    emojiWindow = new EmojiWindow(this);
    fileUploadWindow = new FileUploadWindow(this);
    imageuploadwindow = new ImageUploadWindow(this);

    sendButton->setFixedSize(80, 30);
    sendButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #000000; }"
                         "QPushButton:hover { background-color: #3498db; color: #ffffff; }");
    /*
    closeButton->setFixedSize(80, 30);
    closeButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #000000; }"
                         "QPushButton:hover { background-color: #3498db; color: #ffffff; }");
    */

    messageButton->setFixedSize(80, 30);

    messageInput->setMinimumHeight(120);
    resize(800, 600);
    messageInput->setAlignment(Qt::AlignTop | Qt::AlignLeft);
    messageInput->setStyleSheet("QLineEdit {"
                                "   border: 1px solid #999;"
                                "   background-color: #f5f5f5;"
                                "   padding: 5px;"
                                "   border-radius: 10px;"
                                "   font-family: Arial;"
                                "   font-size: 12px;"
                                "   color: #333;"
                                "   box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.2);"
                                "}");

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->setAlignment(Qt::AlignRight);
    //buttonLayout->addWidget(closeButton);
    buttonLayout->addWidget(sendButton);
    //buttonLayout->addWidget(messageButton);

    QSize buttonSize(30, 30);

    QPixmap emojiPixmap(":/buttonLogo/emoji1.png");
    QIcon emojiIcon(emojiPixmap);
    QPushButton *emojiButton = new QPushButton(this);
    emojiButton->setIcon(emojiIcon);
    emojiButton->setIconSize(buttonSize);
    emojiButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                         "QPushButton:hover { background-color: #3498db; color: #ffffff; }");

    QPixmap uploadPixmap(":/buttonLogo/file1.png");
    QIcon uploadIcon(uploadPixmap);
    QPushButton *fileuploadButton = new QPushButton(this);
    fileuploadButton->setIcon(uploadIcon);
    fileuploadButton->setIconSize(buttonSize);
    fileuploadButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                         "QPushButton:hover { background-color: #3498db; color: #ffffff; }");
    // change color
    QPixmap colorPixmap(":/buttonLogo/font1.png");
    QIcon colorIcon(colorPixmap);
    QPushButton *colorButton = new QPushButton(this);
    colorButton->setIcon(colorIcon);
    colorButton->setIconSize(buttonSize);
    colorButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                         "QPushButton:hover { background-color: #3498db; color: #ffffff; }");
    // change font
    QPixmap fontPixmap(":/buttonLogo/color1.png");
    QIcon fontIcon(fontPixmap);
    QPushButton *fontButton = new QPushButton(this);
    fontButton->setIcon(fontIcon);
    fontButton->setIconSize(buttonSize);
    fontButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                             "QPushButton:hover { background-color: #3498db; color: #ffffff; }");

    // 图片上传
    QPixmap imageuploadPixmap(":/buttonLogo/background1.png");
    QIcon imageuploadIcon(imageuploadPixmap);
    QPushButton *imageuploadButton = new QPushButton(this);
    imageuploadButton->setIcon(imageuploadIcon);
    imageuploadButton->setIconSize(buttonSize);
    imageuploadButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                             "QPushButton:hover { background-color: #3498db; color: #ffffff; }");
/*
    QPixmap anonymousPixmap("/home/user/anonymous.jpg");
    QIcon anonymousIcon(anonymousPixmap);
    QPushButton *anonymousButton = new QPushButton(this);
    anonymousButton->setIcon(anonymousIcon);
    anonymousButton->setIconSize(buttonSize);
*/
    QHBoxLayout *pbuttonLayout = new QHBoxLayout;
    pbuttonLayout->setAlignment(Qt::AlignLeft);
    pbuttonLayout->addWidget(emojiButton);
    pbuttonLayout->addWidget(fileuploadButton);
    pbuttonLayout->addWidget(colorButton);
    pbuttonLayout->addWidget(fontButton);
    pbuttonLayout->addWidget(imageuploadButton);
    // pbuttonLayout->addWidget(anonymousButton);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(chatDisplay);
    layout->addLayout(pbuttonLayout);
    layout->addWidget(messageInput);
    layout->addLayout(buttonLayout);
    layout->setStretch(0, 4);
    layout->setStretch(1, 1);
    layout->setStretch(2, 3);
    layout->setStretch(4, 1);

    // InfoDisplay
    userInfo1 = new QLabel;
    userInfo2 = new QLabel;
    QLabel *spacer = new QLabel;

    // 在这里更新用户头像和昵称
    updateUserInfo();

    InfoDisplay->addWidget(userInfo1);
    InfoDisplay->addWidget(userInfo2);
    InfoDisplay->addWidget(spacer);

    QHBoxLayout *layout2 = new QHBoxLayout;
    layout2->addLayout(layout);
    layout2->addLayout(InfoDisplay);
    layout2->setStretch(0, 3);
    layout2->setStretch(1, 1);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(layout2);
    setCentralWidget(centralWidget);

    QString totalbackgroundStyle = "background-image: url('" + QString::fromStdString("./bizhi/chatbizh1.png") + "'); background-attachment: fixed; background-position: center; background-repeat: no-repeat; background-size: cover;";
    centralWidget->setStyleSheet(totalbackgroundStyle);
    QString chatbackgroundStyle = "background-image: url('" + QString::fromStdString("/bizhi/white.jpg") + "'); background-attachment: fixed; background-position: center; background-repeat: no-repeat; background-size: cover;";
    chatDisplay->setStyleSheet(chatbackgroundStyle);
    messageInput->setStyleSheet(chatbackgroundStyle);

    connect(sendButton, &QPushButton::clicked, this, &chatWindow::sendMessage);
    connect(closeButton, &QPushButton::clicked, this, &chatWindow::quit);
    connect(messageInput, &QLineEdit::returnPressed, this, &chatWindow::sendMessage);
    connect(emojiButton, &QPushButton::clicked, this, &chatWindow::openEmojiWindow);
    connect(emojiWindow, &EmojiWindow::emojiSelected, this, &chatWindow::insertEmoji);
    connect(fileUploadWindow, &FileUploadWindow::fileSelected, this, &chatWindow::uploadFile);
    connect(fileuploadButton, &QPushButton::clicked, this, &chatWindow::openFileUploadWindow);
    connect(colorButton, &QPushButton::clicked, this, &chatWindow::changeBubbleFontColor);
    connect(fontButton, &QPushButton::clicked, this, &chatWindow::changeBubbleTextColor);
    connect(messageButton, &QPushButton::clicked, this, &chatWindow::readyRead);
    connect(imageuploadButton, &QPushButton::clicked, this, &chatWindow::openImageUploadWindow);
    connect(imageuploadwindow, &ImageUploadWindow::imageSelected, this, &chatWindow::setselectedimage);
    /*
    // 居中打开
    QDesktopWidget *desktop = QApplication::desktop();
    this->move((desktop->width() - this->width())/ 2,
                 (desktop->height() - this->height()) /2);
    */
    this->show();
}

void chatWindow::showGroupUI()
{
    chatDisplay = new BubbleListWidget();
    chatDisplay->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
    // chatDisplay->setStyleSheet();

    InfoDisplay = new QVBoxLayout(this);
    messageInput = new QLineEdit(this);
    sendButton = new QPushButton("Send", this);
    closeButton = new QPushButton("Close", this);
    messageButton = new QPushButton("Connect", this);
    emojiWindow = new EmojiWindow(this);
    fileUploadWindow = new FileUploadWindow(this);
    imageuploadwindow = new ImageUploadWindow(this);


    sendButton->setFixedSize(80, 30);
    closeButton->setFixedSize(80, 30);
    messageButton->setFixedSize(80, 30);

    sendButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #000000; }"
                             "QPushButton:hover { background-color: #3498db; color: #ffffff; }");
    closeButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #000000; }"
                             "QPushButton:hover { background-color: #3498db; color: #ffffff; }");

    messageInput->setMinimumHeight(120);
    resize(800, 600);
    messageInput->setAlignment(Qt::AlignTop | Qt::AlignLeft);

    QHBoxLayout *buttonLayout = new QHBoxLayout;
    buttonLayout->setAlignment(Qt::AlignRight);
    buttonLayout->addWidget(closeButton);
    buttonLayout->addWidget(sendButton);
    // buttonLayout->addWidget(messageButton);

    QSize buttonSize(30, 30);

    QPixmap emojiPixmap(":/buttonLogo/emoji1.png");
    QIcon emojiIcon(emojiPixmap);
    QPushButton *emojiButton = new QPushButton(this);
    emojiButton->setIcon(emojiIcon);
    emojiButton->setIconSize(buttonSize);
    emojiButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                         "QPushButton:hover { background-color: #3498db; color: #ffffff; }");


    QPixmap uploadPixmap(":/buttonLogo/file1.png");
    QIcon uploadIcon(uploadPixmap);
    QPushButton *fileuploadButton = new QPushButton(this);
    fileuploadButton->setIcon(uploadIcon);
    fileuploadButton->setIconSize(buttonSize);
    fileuploadButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                         "QPushButton:hover { background-color: #3498db; color: #ffffff; }");


    // change color
    QPixmap colorPixmap(":/buttonLogo/font1.png");
    QIcon colorIcon(colorPixmap);
    QPushButton *colorButton = new QPushButton(this);
    colorButton->setIcon(colorIcon);
    colorButton->setIconSize(buttonSize);
    colorButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                         "QPushButton:hover { background-color: #3498db; color: #ffffff; }");

    // change font
    QPixmap fontPixmap(":/buttonLogo/color1.png");
    QIcon fontIcon(fontPixmap);
    QPushButton *fontButton = new QPushButton(this);
    fontButton->setIcon(fontIcon);
    fontButton->setIconSize(buttonSize);
    fontButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                             "QPushButton:hover { background-color: #3498db; color: #ffffff; }");

    // 图片上传
    QPixmap imageuploadPixmap(":/buttonLogo/background1.png");
    QIcon imageuploadIcon(imageuploadPixmap);
    QPushButton *imageuploadButton = new QPushButton(this);
    imageuploadButton->setIcon(imageuploadIcon);
    imageuploadButton->setIconSize(buttonSize);
    imageuploadButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                                "QPushButton:hover { background-color: #3498db; color: #ffffff; }");

    QPixmap anonymousPixmap(":/buttonLogo/anonymous1.png");
    QIcon anonymousIcon(anonymousPixmap);
    QPushButton *anonymousButton = new QPushButton(this);
    anonymousButton->setIcon(anonymousIcon);
    anonymousButton->setIconSize(buttonSize);
    anonymousButton->setStyleSheet("QPushButton { border: 2px solid #3498db; border-radius: 5px; padding: 5px 10px; background-color: #ffffff; color: #0000; }"
                             "QPushButton:hover { background-color: #3498db; color: #ffffff; }");

    QHBoxLayout *pbuttonLayout = new QHBoxLayout;
    pbuttonLayout->setAlignment(Qt::AlignLeft);
    pbuttonLayout->addWidget(emojiButton);
    pbuttonLayout->addWidget(fileuploadButton);
    pbuttonLayout->addWidget(colorButton);
    pbuttonLayout->addWidget(fontButton);
    pbuttonLayout->addWidget(anonymousButton);
    pbuttonLayout->addWidget(imageuploadButton);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(chatDisplay);
    layout->addLayout(pbuttonLayout);
    layout->addWidget(messageInput);
    layout->addLayout(buttonLayout);
    layout->setStretch(0, 4);
    layout->setStretch(1, 1);
    layout->setStretch(2, 3);
    layout->setStretch(4, 1);

    // InfoDisplay
    InfoDisplay1 = new QListWidget(this);
    foreach(const UserInfo &user, userList)
        MemberInfoLabel(user, *InfoDisplay1);

    if (!timer)
    {
        timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &chatWindow::updateUserInfo);
        timer->start(200);
    }

    // 设置定时器间隔，每0.2秒更新一次
    // 500毫秒 = 0.5秒

    updateUserInfo();

    QHBoxLayout *layout2 = new QHBoxLayout;
    layout2->addLayout(layout);
    layout2->addWidget(InfoDisplay1);
    layout2->setStretch(0, 3);
    layout2->setStretch(1, 1);

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(layout2);
    setCentralWidget(centralWidget);

    QString totalbackgroundStyle = "background-image: url('" + QString::fromStdString(":/bizhi/chatbizh1.png") + "'); background-attachment: fixed; background-position: center; background-repeat: no-repeat; background-size: cover;";
    centralWidget->setStyleSheet(totalbackgroundStyle);
    QString chatbackgroundStyle = "background-image: url('" + QString::fromStdString(":/bizhi/white.jpg") + "'); background-attachment: fixed; background-position: center; background-repeat: no-repeat; background-size: cover;";
    chatDisplay->setStyleSheet(chatbackgroundStyle);
    messageInput->setStyleSheet(chatbackgroundStyle);

    connect(sendButton, &QPushButton::clicked, this, &chatWindow::sendMessage);
    connect(closeButton, &QPushButton::clicked, this, &chatWindow::close);
    connect(messageInput, &QLineEdit::returnPressed, this, &chatWindow::sendMessage);
    connect(emojiButton, &QPushButton::clicked, this, &chatWindow::openEmojiWindow);
    connect(emojiWindow, &EmojiWindow::emojiSelected, this, &chatWindow::insertEmoji);
    connect(fileUploadWindow, &FileUploadWindow::fileSelected, this, &chatWindow::uploadFile);
    connect(fileuploadButton, &QPushButton::clicked, this, &chatWindow::openFileUploadWindow);
    connect(colorButton, &QPushButton::clicked, this, &chatWindow::changeBubbleFontColor);
    connect(fontButton, &QPushButton::clicked, this, &chatWindow::changeBubbleTextColor);
    connect(messageButton, &QPushButton::clicked, this, &chatWindow::tryConnect);
    connect(anonymousButton, &QPushButton::clicked, this, &chatWindow::toggleAnonymous);
    connect(imageuploadButton, &QPushButton::clicked, this, &chatWindow::openImageUploadWindow);
    connect(imageuploadwindow, &ImageUploadWindow::imageSelected, this, &chatWindow::setselectedimage);
    this->show();
}

void chatWindow::updateUserInfo()//更新头像昵称IP
{
    if(isGroup)
    {
        userInfoList = new QListWidget;
        QLabel *spacer = new QLabel;
        QString myHtml ="<img src='./Headers/" + frd.getAvatarUrl() + "' width='30' height='30'>"
                + frd.getName();
        QListWidgetItem *info = new QListWidgetItem;
        info->setText(myHtml);
        userInfoList->addItem(info);
        for (const UserInfo &user : userList) {
            QString userHtml ="<img src=':/Headers/" + user.getAvatarUrl() + "' width='30' height='30'>"
                    + user.getName();
            QListWidgetItem *info = new QListWidgetItem;
            info->setText(userHtml);
            userInfoList->addItem(info);
        }
        InfoDisplay = new QVBoxLayout;
        InfoDisplay->addWidget(userInfoList);
        InfoDisplay->addWidget(spacer);
    }
    else
    {
        QString userHtml1 = "<img src=':/Headers/" + me.getAvatarUrl() + "' width='30' height='30'>"
                + me.getName() + "<br>  ID: " + QString::number(frd.getID());
        QString userHtml2 ="<img src=':/Headers/" + frd.getAvatarUrl() + "' width='30' height='30'>"
                + frd.getName() +  "<br>  ID: " + QString::number(frd.getID());
        userInfo1->setText(userHtml1);
        userInfo2->setText(userHtml2);
    }
}

void chatWindow::tryConnect()
{
    socket = gbdata->socket;
    qDebug() << getLocalIPv4();
    // socket->abort();
    // socket->connectToHost(QHostAddress("192.168.43.100"), 12345);

    // connect(socket, &QTcpSocket::readyRead, this, &chatWindow::readyRead);

    /*
    if(gbdata->socket->waitForReadyRead()){
       buffer =gbdata->socket->readAll();
       readyRead();
    }
    */
    // qDebug() << "chatwindow connected!";
}

void chatWindow::sendMessage()
{
    QString msgContent = messageInput->text();
    if (!msgContent.isEmpty())
    {
        /*
        QDateTime currentTime = QDateTime::currentDateTime();
        QString msgTime = currentTime.toString("hh:mm");
        //QString formattedTime = "[" + timeText + "]";

        Request re;
        re.requestType = RequestType::SEND_MESSAGE_REQUEST;
        QString senderID = QString::number(me.getID());
        QString receiverID = QString::number(frd.getID());
        const QString msgType = "0";
        re.msgList.append(senderID);
        re.msgList.append(receiverID);
        re.msgList.append(msgType);
        re.msgList.append(msgContent);
        re.msgList.append(msgTime);
        re.msgNum = re.msgList.length();
        QByteArray data = re.requestToCode();
        //QString newMessage ="<img src='" + avatarPath + "' width='30' height='30'>" + nickname + " " + formattedTime + "<br>" + message;
        socket->write(data);
        */
        //QString selfMessage = "<p style='text-align: right;'>" + newMessage + "</p>";
        //chatDisplay->append(selfMessage);

        sendMsgRequest(msgContent);
        messageInput->clear();
    }
}

void chatWindow::showMessageList()
{
    chatDisplay->clear();
    foreach(Message msg, msgList)
    {
        showNewMsg(msg);
    }
}

QString generateAnonymousNickname(const int &ID)
{
    QString anonymousName = "匿名";
    // 生成四位随机数字
    srand(ID); // 设置随机数种子
    for (int i = 0; i < 4; ++i)
    {
        int digit = rand() % 10;
        anonymousName.append(QString::number(digit));
    }
    return anonymousName;
}

void chatWindow::toggleAnonymous()
{
    QString anonymousAvatar = ":/buttonLogo/anonymousAvatar.png";
    isAnonymous = !isAnonymous; //保证点击时再匿名与非匿名之间切换
    if (isAnonymous)
    {
        nickname = generateAnonymousNickname(me.getID());
        avatarPath = anonymousAvatar;
    }
    else
    {
        nickname = me.getName(); // 保存原始昵称
        avatarPath = me.getAvatarUrl(); // 保存原始头像路径
    }

}

void chatWindow::showNewMsg(const Message &newMsg)
{
    QString chatName;
    QString chatAvatar;
    //QDateTime currentTime = QDateTime::currentDateTime();
    //QString msgTime = currentTime.toString("hh:mm");

    //QListWidgetItem *nowtime = new QListWidgetItem(parts[2], chatDisplay);
    //nowtime->setTextAlignment(Qt::AlignCenter);

    chatWindow::senderID.append(QString::number(newMsg.getSenderID()));

    if(newMsg.getSenderID() == me.getID())
    {
        // isMyMessage = true;
        if (newMsg.getAnonymous())
        {
            chatName = generateAnonymousNickname(me.getID());
            chatAvatar = ":/buttonLogo/anonymousAvatar.png";
                    //QString(":/AnonymousAvatar/avatar" + me.getID() % 3 + ".jpeg");
        }
        else
        {
            chatName = me.getName();
            chatAvatar = ":/Headers/" + me.getAvatarUrl();
        }
    }
    else{
        // isMyMessage = false;
        if (newMsg.getAnonymous())
        {
            chatName = generateAnonymousNickname(frd.getID());
            chatAvatar = ":/buttonLogo/anonymousAvatar.png";
                    //QString(":/AnonymousAvatar/avatar" + frd.getID() % 3 + ".jpeg");
        }
        else
        {
            chatName = frd.getName();
            chatAvatar = ":/Headers/" + frd.getAvatarUrl();
        }
    }

    chatDisplay->addBubble("[System1]" + newMsg.getMsgTime()); // system msg  time
    chatDisplay->addBubble("[System2]" + chatName); // nickname
    chatDisplay->addBubble("[System3]" + chatAvatar); // avatar
    chatDisplay->addBubble(newMsg.getMsgContent()); //消息
}

void chatWindow::readyRead()
{
    buffer.clear();
    // sleep(100);
    // while(buffer == ""){
    qDebug() << "Data available" << socket->bytesAvailable();
    while(socket->bytesAvailable() > 0)
        buffer += socket->readAll();

    QByteArray data= buffer;

    QList<Request> replyList = splitReply(data);

    //Request reply;
    //reply.codeToRequest(data);

    qDebug() << "receive from server: " << data;
    foreach(Request reply, replyList)
    {
        // qDebug() << reply.msgList;
        switch(reply.requestType)
    {
        default: {
            QString warning = QString("WRONG REPLY TYPE!!!\n%1")
                    .arg(QString::fromUtf8(data));
            QMessageBox::warning(this,tr("Warning"),warning);
            break;
        }
    case RequestType::OPEN_CHAT_REPLY: openChatReply(reply); break;
    case RequestType::MESSAGE_INFOMATION_REPLY: msgInfoReply(reply); break;
    case RequestType::DELETE_FRIEND_SUCCESS: delMsgSuccess(reply); break;
    case RequestType::CLOSE_CHAT_SUCCESS: closeChatSuccess(reply); break;
    case RequestType::SEND_MESSAGE_REPLY: sendMsgReply(reply); break;
    case RequestType::OPEN_GROUP_CHAT_REPLY: openGroupChatReply(reply); break;
    case RequestType::GROUP_MEMBERS_ID_REPLY: groupMembersIDReply(reply); break;
    case RequestType::SEND_GROUP_MESSAGE_REPLY: sendGruopMsgReply(reply); break;
    case RequestType::DELETE_GROUP_MESSAGE_SUCCESS: delGroupMsgSuccess(reply); break;
    case RequestType::CLOSE_GROUP_CHAT_SUCCESS: closeGroupChatSuccess(reply); break;
    case RequestType::USERINFO_REPLY: userInfoReply(reply); break;
    }
    }
    buffer.clear();
}

void chatWindow::openChatRequest()
{
    Request re;

    re.requestType = RequestType::OPEN_CHAT_REQUEST;
    QString userID = QString::number(me.getID());
    QString friendID = QString::number(chatWindow::friendID);
    re.msgList.append(userID);
    re.msgList.append(friendID);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);
    //if(gbdata->socket->waitForReadyRead()){
    //     buffer= gbdata->socket->readAll();
    //}
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::msgInfoRequest(const QString &msgID)
{
    Request re;

    re.requestType = RequestType::MESSAGE_INFOMATION_REQUEST;
    re.msgList.append(msgID);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);
    qDebug() << "send to server: " << data;
    // socket->waitForReadyRead();
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::delMsgRequest(const QString &msgID)
{
    Request re;

    re.requestType = RequestType::DELETE_MESSAGE_REQUEST;
    re.msgList.append(msgID);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);

    // delete message
    for (const Message &msg : msgList) {
        if(msg.getMsgID() == msgID.toInt())
            msgList.removeOne(msg);
    }
    chatDisplay->clear();
    for (const Message &msg : msgList) {
        showNewMsg(msg);
    }

    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::closeChatRequest()
{
    Request re;
    QString userID = QString::number(me.getID());
    QString friendID = QString::number(frd.getID());

    re.requestType = RequestType::CLOSE_CHAT_REQUEST;
    re.msgList.append(userID);
    re.msgList.append(friendID);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::sendMsgRequest(const QString &msgContent)
{
    //发送消息的的请求，给出senderid，receiverid，messageType，messagecontent，msgtime，是否匿名
    //00170006____senderid____receiverid____msgType____msgContent____msgTime____isNIMING
    //返回指令是1022
    QDateTime currentTime = QDateTime::currentDateTime();
    QString msgTime = currentTime.toString("hh:mm");
    QString isAms = "0";
    if(isAnonymous)
        isAms = "1";
    Request re;

    re.requestType = RequestType::SEND_MESSAGE_REQUEST;
    QString senderID = QString::number(me.getID());
    QString receiverID = QString::number(frd.getID());
    const QString msgType = "0";
    re.msgList.append(senderID);
    re.msgList.append(receiverID);
    re.msgList.append(msgType);
    re.msgList.append(msgContent);
    re.msgList.append(msgTime);
    re.msgList.append(isAms);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);
    if (socket->waitForReadyRead())
        readyRead();

    // test
    //Message test(MessageType::Text, 0, msgContent, msgTime, me.getID());
    //showNewMsg(test);
}

void chatWindow::openGroupChatRequest()
{
    //打开群聊窗口的请求，需要userId和groupId，返回群头像，群昵称，群消息数量，每条群消息的id
    //00180002____UserId____GroupId
    Request re;

    re.requestType = RequestType::OPEN_GROUP_CHAT_REQUEST;
    QString userID = QString::number(me.getID());
    QString groupID = QString::number(friendID);
    re.msgList.append(userID);
    re.msgList.append(groupID);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::groupMembersIDRequest()
{
    Request re;

    re.requestType = RequestType::GROUP_MEMBERS_ID_REQUEST;
    QString groupID = QString::number(frd.getID());
    re.msgList.append(groupID);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::sendGroupMsgRequest(const QString &msgContent)
{
    //发送群消息请求，需要senderId，groupId，消息类型，消息内容，消息时间，是否匿名
    //00200006____senderId____GroupId____msgType____msgContent____msgTime____IsNIMING
    //返回指令是10
    QDateTime currentTime = QDateTime::currentDateTime();
    QString msgTime = currentTime.toString("hh:mm");
    QString isAms = QString(isAnonymous);
    Request re;

    re.requestType = RequestType::SEND_GROUP_MESSAGE_REQUEST;
    QString senderID = QString::number(me.getID());
    QString groupID = QString::number(frd.getID());
    const QString msgType = "0";
    re.msgList.append(senderID);
    re.msgList.append(groupID);
    re.msgList.append(msgType);
    re.msgList.append(msgContent);
    re.msgList.append(msgTime);
    re.msgList.append(isAms);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::delGroupMsgRequest(const QString &msgID)
{
    Request re;

    re.requestType = RequestType::DELETE_GROUP_MESSAGE_REQUEST;
    re.msgList.append(msgID);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);

    // delete message
    for (const Message &msg : msgList) {
        if(msg.getMsgID() == msgID.toInt())
            msgList.removeOne(msg);
    }
    chatDisplay->clear();
    for (const Message &msg : msgList) {
        showNewMsg(msg);
    }
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::closeGroupChatRequest()
{
    Request re;
    QString userID = QString::number(me.getID());
    QString groupID = QString::number(frd.getID());

    re.requestType = RequestType::CLOSE_GROUP_CHAT_REQUEST;
    re.msgList.append(userID);
    re.msgList.append(groupID);
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::userInfoRequest(int friendID)
{
    //(群聊页面)请求某个用户的信息，给出id，返回昵称、头像、是否在线
    //00280001____UserId
    Request re;
    re.requestType = RequestType::USERINFO_REQUEST;
    re.msgList.append(QString::number(friendID));
    re.msgNum = re.msgList.length();
    QByteArray data = re.requestToCode();
    socket->write(data);

    chatWindow::friendID = friendID;
    if (socket->waitForReadyRead())
        readyRead();
}

void chatWindow::openChatReply(const Request &reply)
{
    //打开聊天页面，返回好友头像、昵称、ip、消息数量与每条消息的id
    //1018xxxx____FriendAvatar____FrieNickname____FriendIp____MsgNum____MsgID____MsgID____MsgID......
    UserInfo chatFrd(friendID, reply.msgList[1], "", reply.msgList[0], reply.msgList[2]);
    frd = chatFrd;
    int msgNum = reply.msgList[3].toInt();
    for (int i = 0; i < msgNum; i++) {
        msgInfoRequest(reply.msgList[i+4]);
        sleep(100);
        // showNewMsg(reply.msgList[i]);
    }
    updateUserInfo();

}

void chatWindow::msgInfoReply(const Request &reply)
{
    //返回消息的类型，内容，时间，发送者id,是否匿名
    //10190005____MsgType____MsgContent____MsgTime____SenderId____IsNIMING
    int senderID = reply.msgList[3].toInt();
    Message newMsg(MessageType::Text, 0,reply.msgList[1], reply.msgList[2],
            senderID, reply.msgList[4].toInt());

    msgList.append(newMsg);
    showNewMsg(newMsg);
    foreach(Message msg, msgList)
        qDebug() << msg.getMsgID() << msg.getMsgContent() << msg.getSenderID();
}

bool chatWindow::delMsgSuccess(const Request &reply)
{
    //删除消息成功
    //1020
    qDebug() << "delete message success! request:" << reply.msgList;
    return true;
}

bool chatWindow::closeChatSuccess(const Request &reply)
{
    //关闭窗口成功
    //1021
    qDebug() << "close chatwindow success! request:" << reply.msgList;
    return true;
}

void chatWindow::sendMsgReply(const Request &reply)
{
    //发送消息成功，返回该条消息的id
    //10220001____msgId
    QString msgID = reply.msgList[0];
    msgInfoRequest(msgID);
}

void chatWindow::openGroupChatReply(const Request &reply)
{
    //打开群聊窗口的请求，返回群头像，群昵称，群消息数量，每条群消息的id
    //1023xxxx____GroupAvatar____GroupName____MsgNum____MsgID____MsgId____MsgID......
    UserInfo chatFrd(friendID, reply.msgList[1], "", reply.msgList[0], "");
    frd = chatFrd;
    int msgNum = reply.msgList[2].toInt();
    for (int i = 0; i < msgNum; i++)
        msgInfoRequest(reply.msgList[i+3]);
}

void chatWindow::groupMembersIDReply(const Request &reply)
{
    //请求群内成员id列表，返回所有群成员id
    //1024XXXX____MemberId____MemberId____MemberId......
    for (const QString &msg : reply.msgList) {
        int memberID = msg.toInt();
        userInfoRequest(memberID);
    }
}

void chatWindow::sendGruopMsgReply(const Request &reply)
{
    //发送消息请求回应，返回这条消息的id
    //10250001____MsgId
    QString msgID = reply.msgList[0];
    msgInfoRequest(msgID);
}

bool chatWindow::delGroupMsgSuccess(const Request &reply)
{
    //删除群消息请求，回应成功
    //1026
    qDebug() << "delete gruop message success! request:" << reply.msgList;
    return true;
}

bool chatWindow::closeGroupChatSuccess(const Request &reply)
{
    //关闭群聊窗口成功
    //1027
    qDebug() << "close group chatwindow success! request:" << reply.msgList;
    return true;
}

void chatWindow::userInfoReply(const Request &reply)
{
    //(群聊页面)请求某个用户的信息，给出id，返回昵称、头像、是否在线
    //10330003____NickName____AvatarName____IsOnline
    //请求指令是0028
    UserInfo user(friendID, reply.msgList[0], "", reply.msgList[1]);
    userList.append(user);
    updateInfo();
}

void chatWindow::clock(int msc)
{
    if (!timer)
    {
        timer = new QTimer;
        timer->start(msc);
    }
}

void chatWindow::openEmojiWindow()
{
    emojiWindow->exec();
}

void chatWindow::insertEmoji(const QString &emoji)
{
    messageInput->insert(emoji);
}

void chatWindow::openFileUploadWindow()
{
    fileUploadWindow->exec();
}

void chatWindow::quit()
{
    close();
    delete this;
}

void chatWindow::closeEvent ( QCloseEvent * e )
{
    close();
    e->accept();//不会将事件传递给组件的父组件
}

void chatWindow::changeBubbleFontColor()
{
    QFont font;
    bool bFlag = true;
    font = QFontDialog::getFont(&bFlag, this);
    if(bFlag)
    {
        chatDisplay->setBubbleFont(font);
    }
}

void chatWindow::changeBubbleTextColor()
{
    QColor color;
    color = QColorDialog::getColor(color, this);

    if (color.isValid())
    {
        QPalette palette;
        palette.setColor(QPalette::Text, color);
        chatDisplay->setBubbleTextColor(color);
    }
}

void chatWindow::uploadFile(const QString &path)
{
    if(!path.isEmpty())
        file.setFileName(path);
    if(file.open(QIODevice::ReadOnly))
        {
            QFileInfo info(path);
            filename = info.fileName();
            filesize = info.size();
            sendsize = 0;
            QMessageBox::warning(this,tr("Warning"),tr("文件加载完成"));
        }
    /*
    QTimer *fileTimer = new QTimer(this);
    connect(fileTimer, &QTimer::timeout, this, &chatWindow::sendData);

    //自定义文件信息
    QString buf = QString("head#%1#%2").arg(filename).arg(filesize);
    qint64 len = socket->write(buf.toUtf8().data());

    //是否发送成功
    if(len >0)
        {
        //使用定时器延时，防止粘包
            fileTimer->start(200);
        }else{
            file.close();
            fileTimer->stop();
        }
        */
    QMessageBox::warning(this,tr("Warning"),tr("文件发送完毕"));
}

void chatWindow::sendData()
{
    if(!socket->isWritable())
        QMessageBox::warning(this,tr("Warning"),tr("请先连接服务器"));
    qint64 len = 0;
    do{
    //每次发送2k文件内容
        char buf[2*1024] = {0};
        len = file.read(buf,sizeof(buf));
        len = socket->write(buf,len);
        sendsize+=len;
        qDebug()<<"SendData";
    }while(len >0);
    if(sendsize == filesize)
    {
        QMessageBox::warning(this,tr("Warning"),tr("文件发送完毕"));
        // socket->close();
    }
}

void chatWindow::openImageUploadWindow()
{
    imageuploadwindow->exec();
}

void chatWindow::setselectedimage(const QString &imagePath)
{
    messageInput->insert("pic@" + imagePath);
}

void chatWindow::MemberInfoLabel(const UserInfo &user, QListWidget& Display) const {
    const QString& avatarPath = user.getAvatarUrl();
    const QString& nickname = user.getName();
    QPixmap avatarPixmap(avatarPath);
    QLabel *label = new QLabel;
    label->setPixmap(avatarPixmap.scaled(30, 30)); // Resize avatar pixmap

    QString ID = QString::number(user.getID());
    QLabel *infoLabel = new QLabel;
    infoLabel->setText(nickname + " ID: " + ID );
    infoLabel->setAlignment(Qt::AlignLeft | Qt::AlignVCenter); // Align text and avatar

    // Create a layout to hold the avatar label and info label
    QHBoxLayout *layout = new QHBoxLayout;
    layout->addWidget(label);
    layout->addWidget(infoLabel);
    layout->setContentsMargins(0, 0, 0, 0);

    // Create a container widget for the layout
    QWidget *widget = new QWidget;
    widget->setLayout(layout);

    QListWidgetItem *item = new QListWidgetItem;
    item->setSizeHint(widget->sizeHint()); // Set item size
    Display.addItem(item);
    Display.setItemWidget(item, widget); // Set widget for the item
}
