#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include "GroupWindow.h"
#include "Request.h"
#include "LoginWindow.h"


    GroupWindow::GroupWindow(QString group,QWidget* parent ) : QWidget(parent) {
        setWindowTitle("为分组增添好友");
        lineEdit = new QLineEdit(this);
        lineEdit->setPlaceholderText("请输入要添加的好友的ID");

        submitButton = new QPushButton("提交", this);
        connect(submitButton, &QPushButton::clicked, [this, group]() {
            submitClicked(group);
        });
        // 使用布局管理器来布局控件
        QVBoxLayout* layout = new QVBoxLayout(this);
        layout->addWidget(lineEdit);
        layout->addWidget(submitButton);
        setLayout(layout);
    }

    //void GroupWindow::submitText(const QString& text)
    //{
        //传text到服务器
    //}

    void GroupWindow::submitClicked(QString group)
    {
        //QString text = lineEdit->text();
        //emit submitText(text);
        //尝试连接服务器
        QString group2=group;
//        this->m=new QTcpSocket(this);
//        this->m->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
//        connect(this->m, SIGNAL(connected()), this, SLOT(sendRequest(group2)));
        GlobalData* globaldata = GlobalData::getInstance();
        //传输组名和要添加的ID
        //CHANGE_FRIEND_GROUP_REQUEST = 8 ,//更改好友所在的分组，需要用户id，新分组名
        //00080002____UserId____FriendId____NewGroupName
        //返回指令是1012
        QString text = lineEdit->text();
        Request re;
        re.msgNum=3;
        re.requestType = RequestType::CHANGE_FRIEND_GROUP_REQUEST;
        re.msgList.append(globaldata->uid);
        re.msgList.append(text);
        re.msgList.append(group);

        QString stext=re.requestToCode();;
        globaldata->socket->write(stext.toUtf8());
        if(globaldata->socket->waitForReadyRead())
        {
            QByteArray byteArray = globaldata->socket->readAll();
            QString rmessage=byteArray;
            //处理编码为请求
            //CHANGE_FRIEND_GROUP_SUCCESS = 1012,//好友更换分组成功
            //1012
            //请求指令是0008

            Request re2;
            re2.codeToRequest(byteArray);
            if(re2.requestType==RequestType::CHANGE_FRIEND_GROUP_SUCCESS)
            {
                QMessageBox::information(this,"更换分组","更换分组成功");

            }
        }
    }

    void GroupWindow::sendRequest(QString group)
    {

        GlobalData* globaldata = GlobalData::getInstance();
        //传输组名和要添加的ID
        //CHANGE_FRIEND_GROUP_REQUEST = 8 ,//更改好友所在的分组，需要用户id，新分组名
        //00080002____UserId____FriendId____NewGroupName
        //返回指令是1012
        QString text = lineEdit->text();
        Request re;
        re.msgNum=3;
        re.requestType = RequestType::CHANGE_FRIEND_GROUP_REQUEST;
        re.msgList.append(globaldata->uid);
        re.msgList.append(text);
        re.msgList.append(group);

        QString stext=re.requestToCode();;
        this->m->write(stext.toUtf8());
        //接受服务器信号
        connect(this->m,SIGNAL(readyRead()),this,SLOT(recivmessage()));

    }
    void GroupWindow::recivmessage()
    {
        QByteArray byteArray = this->m->readAll();
        QString rmessage=byteArray;
        //处理编码为请求
        //CHANGE_FRIEND_GROUP_SUCCESS = 1012,//好友更换分组成功
        //1012
        //请求指令是0008

        Request re2;
        re2.codeToRequest(byteArray);
        if(re2.requestType==RequestType::CHANGE_FRIEND_GROUP_SUCCESS)
        {
            QMessageBox::information(this,"更换分组","更换分组成功");

        }
    }

    QString GroupWindow::Mark(QString m)
    {
        QString a="0000";
        int b,i,c;
        c=3;
        b=m.length();
        for(i=b-1;i>=0;i--)
        {
            a[c]=m[i];
            c--;
        }
       return a;
    }
