#include <QtWidgets>
#include <QTreeWidgetItem>
#include "AvatarChangeDialog.h"
#include <QSqlDatabase>
#include <QSqlError>
#include <QDebug>
#include "MyWidget.h"
#include "GroupWindow.h"

void MyWidget::itemClicked(QTreeWidgetItem* item) {
    GlobalData* globaldata = GlobalData::getInstance();
    // 检查点击的节点类型
    if (item->parent() == nullptr) {
        // 点击的是分组节点
        QString groupName = item->text(0);
        // 跳转到分组窗口
        GroupWindow* groupWindow = new GroupWindow(groupName);
        groupWindow->show();
    } else {
        // 点击的是联系人节点
        QString contactName = item->text(0);
        // 根据联系人名称跳转到不同的窗口

            UserInfo me(globaldata->uid.toInt(), globaldata->uname, "",
                        globaldata->uphoto, globaldata->uip);
            QString contactID = item->data(0,Qt::UserRole).toString();
            qDebug()  << contactID;
            chatWindow *ct =new chatWindow(me,contactID.toInt(), this);


    }
}

void MyWidget::chatClicked(QTreeWidgetItem* item){
   GlobalData* globaldata = GlobalData::getInstance();
    UserInfo me(globaldata->uid.toInt(), globaldata->uname, "",
                globaldata->uphoto, globaldata->uip);
    QString contactID = item->data(0, Qt::UserRole).toString();
    qDebug () <<contactID;
    chatWindow *ct =new chatWindow(me, contactID.toInt(), this,1);


}

void MyWidget::avatarClicked()
{
    // 创建头像切换界面的实例
    AvatarChangeDialog dialog(this);
    // 显示头像切换界面
    dialog.exec();
}
void MyWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        avatarClicked(); // 调用头像点击的逻辑函数
    }
}

void MyWidget::connectToDatabase()
    {
        // 创建数据库连接
        QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");

        // 设置数据库名称
        database.setDatabaseName("path/to/your/database.db");

        // 打开数据库
        if (!database.open()) {
            // 如果无法打开数据库，打印错误信息
            qDebug() << "Error opening database: " << database.lastError().text();
        } else {
            qDebug() << "Database connection established!";

            // 数据库已连接，您可以执行进一步的操作，例如查询、插入等
        }
    }



