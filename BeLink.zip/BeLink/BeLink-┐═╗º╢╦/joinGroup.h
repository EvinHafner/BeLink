#ifndef JOINGROUP_H
#define JOINGROUP_H

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QDebug>
#include <QTcpSocket>
#include "GlobalData.h"

class joinGroup: public QWidget {
public:
    joinGroup(QWidget* parent = nullptr) ;

private slots:
    void handleSubmit() ;
    QString Mark(QString m);//字符串长度的格式转换

private:
    QLineEdit* lineEdit;
    QPushButton* submitButton;

};

#endif // JOINGROUP_H
