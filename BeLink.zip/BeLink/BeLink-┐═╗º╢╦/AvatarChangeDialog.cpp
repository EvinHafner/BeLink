#include "AvatarChangeDialog.h"
#include <QPushButton>
#include <QVBoxLayout>
#include <QDir>
#include <QLabel>
#include <QFileInfoList>
#include <QPixmap>
#include <QDebug>
#include <QSql>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QString>
#include "Request.h"
#include "guodu.h"
#include "LoginWindow.h"
#include "GlobalData.h"

AvatarChangeDialog::AvatarChangeDialog(QWidget *parent) : QDialog(parent),avatarLabel(nullptr)
{
    setWindowTitle("更换头像");
    resize(300, 400);
    // 获取图片路径列表
    QStringList pathList = getImagePathList();

    // 创建按钮布局
    QVBoxLayout *layout = new QVBoxLayout;

    // 遍历路径列表，创建并添加按钮
    for (const QString &path : pathList) {
        QPixmap pixmap(path);
        if (!pixmap.isNull()) {
            QPushButton *button = new QPushButton;
            button->setIcon(QIcon(pixmap));
            button->setIconSize(QSize(100, 100));
            button->setFixedSize(100, 100);
            button->setFlat(true);
            connect(button, &QPushButton::clicked, [this, path]() {
                changeAvatar(path);
            });
            layout->addWidget(button);
        }
    }

    // 设置对话框的布局
    setLayout(layout);
}

QStringList AvatarChangeDialog::getImagePathList()
{
    QStringList pathList;

    // 遍历图片库目录，获取所有图片路径
    QDir imageDir(":/Headers");
    QFileInfoList fileInfoList = imageDir.entryInfoList(QDir::Files);

    for (const QFileInfo &fileInfo : fileInfoList) {
        pathList.append(fileInfo.absoluteFilePath());
    }

    return pathList;
}

void AvatarChangeDialog::changeAvatar(const QString &path)
{

    QPixmap avatarPixmap(path);
    if (avatarPixmap.isNull()) {
        qDebug() << "Failed to load image";
        return; // 或进行适当的错误处理
    }

    // 删除已有的 QLabel 对象
    if (avatarLabel != nullptr) {
        layout()->removeWidget(avatarLabel);
        delete avatarLabel;
    }

    // 删除已有的按钮对象
    for (QPushButton* button : buttonList) {
        layout()->removeWidget(button);
        delete button;
    }
    buttonList.clear();

    // 更新路径列表
    pathList = getImagePathList();

    // 创建 QLabel 对象用于显示头像图片
    avatarLabel = new QLabel(this);
    avatarLabel->setFixedSize(200, 200);
    avatarLabel->setPixmap(avatarPixmap.scaled(avatarLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));

    // 将 QLabel 对象添加到对话框布局中
    layout()->addWidget(avatarLabel);

    // 创建按钮


        QPushButton *button = new QPushButton;
        button->setText("点击更换此头像");  // 设置按钮名称
        connect(button, &QPushButton::clicked, [this, path]()
        {
         // 传path到服务器


            GlobalData* globaldata = GlobalData::getInstance();
            this->close();
            //传输路径

            qDebug() << "更换头像" ;
            //CHANGE_AVATAR_REQUEST = 11,//更换头像，需要userid与新头像name
            //00110002____UserId____AvatarName
            //返回指令是1016
            Request re;
            re.requestType = RequestType::CHANGE_AVATAR_REQUEST;
            re.msgNum = 2;
            re.msgList.append(globaldata->uid);
            QStringList str= path.split("/");
            re.msgList.append(str[2]);
            QString stext = re.requestToCode();
            globaldata->socket->write(stext.toUtf8());
            if(globaldata->socket->waitForReadyRead())
            {
                QByteArray byteArray = globaldata->socket->readAll();
                QString rmessage=byteArray;
                //处理编码为请求
                Request re2;
                re2.codeToRequest(byteArray);
                //判断更改是否成功
                //CHANGE_AVATAR_SUCCESS = 1016,//更换头像成功
                //1016
                //请求指令是0011
                if(re2.requestType==RequestType::CHANGE_AVATAR_SUCCESS)
                {
                    QMessageBox::information(this,"更换头像","更换头像成功");
                }
                globaldata->uphoto=str[2];
            }


        });
        buttonList.append(button);
        layout()->addWidget(button);

}

//void AvatarChangeDialog::sendRequest(QString &path);
//{
//    GlobalData* globaldata = GlobalData::getInstance();
//    this->close();
//    //传输路径

//    qDebug() << "111" ;
//    //CHANGE_AVATAR_REQUEST = 11,//更换头像，需要userid与新头像name
//    //00110002____UserId____AvatarName
//    //返回指令是1016
//    Request re;
//    re.requestType = RequestType::CHANGE_AVATAR_REQUEST;
//    re.msgNum = 2;
//    re.msgList.append(globaldata->uid);
//    re.msgList.append(path);


//    QString stext = re.requestToCode();
//    //int a;
//    //a=path.length();
//    //QString c=QString::number(a);
//    //c=Mark(c);//转为标准形式
//    //QString stext="标识符0001"+c+path;
//    this->m->write(stext.toUtf8());
//    //接受服务器信号
//    connect(this->m,SIGNAL(readyRead()),this,SLOT(recivmessage()));

//}
//void AvatarChangeDialog::recivmessage();
//{
//    QByteArray byteArray = this->m->readAll();
//    QString rmessage=byteArray;
//    //处理编码为请求
//    Request re2;
//    re2.codeToRequest(byteArray);
//    //判断更改是否成功
//    //CHANGE_AVATAR_SUCCESS = 1016,//更换头像成功
//    //1016
//    //请求指令是0011
//    if(re2.requestType==RequestType::CHANGE_AVATAR_SUCCESS)
//    {
//        QMessageBox::information(this,"更换头像","更换头像成功");
//    }


//}

//QString AvatarChangeDialog::Mark(QString m)
//{
//    QString a="0000";
//    int b,i,c;
//    c=3;
//    b=m.length();
//    for(i=b-1;i>=0;i--)
//    {
//        a[c]=m[i];
//        c--;
//    }
//   return a;
//}
