#include "forgetpwd.h"
#include "ui_forgetpwd.h"
#include "newpwd.h"
#include <QMessageBox>
#include <QTcpSocket>
#include <QString>
#include <QHostAddress>

forgetpwd::forgetpwd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::forgetpwd)
{
    ui->setupUi(this);
    ui->label_3->setText(GlobalData2::question);
}

forgetpwd::~forgetpwd()
{
    delete ui;
}

void forgetpwd::on_pushButton_clicked()
{
    QString answer=ui->lineEdit->text();
    if(answer!=GlobalData2::solution)
    {
        QMessageBox::warning(this,"找回密码","回答不正确");
    }
    else
    {
        this->close();
        newpwd *main=new newpwd;
        main->show();
    }

}
QString GlobalData2::question="密保问题";
QString GlobalData2::solution="回答";

