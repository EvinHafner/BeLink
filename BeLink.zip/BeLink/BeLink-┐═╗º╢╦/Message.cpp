#include "Message.h"

Message::Message(MessageType msgType,int msgId,QString msgContent,QString msgTime,int senderId, bool isAms)
    :msgType(msgType),msgId(msgId),msgContent(msgContent),
      msgTime(msgTime), senderId(senderId), isAnonymous(isAms)
{
}

MessageType Message::getMsgType() const{
    return msgType;
}
int     Message::getMsgID() const{
    return msgId;
}
QString Message::getMsgContent() const{
    return msgContent;
}
QString Message::getMsgTime() const{
    return msgTime;
}
int     Message::getSenderID() const{
    return senderId;
}

bool Message::getAnonymous() const
{
    return isAnonymous;
}

bool Message::operator ==(const Message &msg) const
{
    if(this->getMsgID() == msg.getMsgID())
        return true;
    else
        return false;
}
