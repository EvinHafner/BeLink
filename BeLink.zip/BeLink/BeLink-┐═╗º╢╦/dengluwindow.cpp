#include "mainwindow.h"
#include "ui_dengluwindow.h"
#include "signup.h"
#include "guodu.h"
#include "Request.h"
#include "RequestType.h"
#include <QGraphicsDropShadowEffect>
#include <QCoreApplication>
#include <QTextCodec>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QTime>
#include <QSqlError>
#include <QtDebug>
#include <QSqlDriver>
#include <QSqlRecord>
#include <QMessageBox>
#include <QTcpSocket>
#include <QValidator>
#include <QString>
#include <QHostAddress>
#include "dengluwindow.h"
#include "LoginWindow.h"
#include "forgetpwd.h"



//#include <QLoggingCategory>//调试
dengluWindow::dengluWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //设置背景图片
    QPixmap *pix = new QPixmap(":/bizhi/登录壁纸.jpeg");
//    QSize sz = ui->image1->size();
//    ui->image1->setPixmap(pix->scaled(sz));
    //设置一键清空
    ui->lineEdit_password->setClearButtonEnabled(true);
    ui->lineEdit_ID->setClearButtonEnabled(true);
    //密码格式
    QRegExp regx("[0-9]{5}");
    QValidator *validatorName = new QRegExpValidator(regx);
    ui->lineEdit_ID->setValidator(validatorName);

}

dengluWindow::~dengluWindow()
{
    delete ui;
}

//跳转注册
void dengluWindow::on_pushButton_2_clicked()
{
    this->close();
    signup *s=new signup;
    s->show();


}

//登录
void dengluWindow::on_pushButton_clicked()
{
    GlobalData* globaldata = GlobalData::getInstance();
    //防止内容为空
    QString ID=ui->lineEdit_ID->text();
    QString password=ui->lineEdit_password->text();
    if(ID==NULL||password==NULL)
    {
        QMessageBox::warning(this,"登录","内容不能为空");
    }
    else
    {
        if(ID.length()!=5)
        {
            QMessageBox::warning(this,"登录","ID号为5位");
        }
        else
        {

    //尝试连接服务器



    //lobaldata->socket=new QTcpSocket(this);

    //globaldata->socket->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
    //connect(globaldata->socket, SIGNAL(connected()), this, SLOT(sendRequest()));
            GlobalData* globaldata = GlobalData::getInstance();
            //关闭登录界面，打开过渡界面
            this->close();
            this->g=new guodu;
            this->g->show();
            //传输ID和密码
            QString ID=ui->lineEdit_ID->text();
            QString password=ui->lineEdit_password->text();
            //LOGIN_REQUEST = 2,//登录请求 需要id、密码
            //00020002____ID____password
            //返回指令是1002~1004
            Request re;

            re.msgNum=2;
            re.msgList.append(ID);
            re.msgList.append(password);
            re.requestType=RequestType::LOGIN_REQUEST;



            QString stext=re.requestToCode();

            globaldata->socket->write(stext.toUtf8());
            if(globaldata->socket->waitForReadyRead())
            {
                this->g->close();

                //根据返回的信息决定跳转界面
                QByteArray byteArray = globaldata->socket->readAll();
                Request re;
                re.codeToRequest(byteArray);
                QString rmessage=byteArray;

                //判断是否成功
                if(re.requestType == RequestType::LOGIN_FAIL_WRONG_PASSWORD)
                {

                    dengluWindow *main=new dengluWindow;
                    qDebug() << " 1111  ";
                    main->show();
                    QMessageBox::warning(this,"登录失败","密码不正确");
                }
                if(re.requestType==RequestType::LOGIN_FAIL_NO_USER)
                {

                    dengluWindow *main=new dengluWindow;
                    qDebug() << " 1111  ";
                    main->show();
                    QMessageBox::warning(this,"登录失败","用户不存在");
                }
                if(re.requestType==RequestType::LOGIN_SUCCESS)
                {
                    //转到好友界面

                    QString ID=ui->lineEdit_ID->text();
                    globaldata->uid=ID;
                    globaldata->uname=re.msgList[0];
                    globaldata->uphoto=re.msgList[1];
                    globaldata->uip=re.msgList[2];

                    qDebug()<<globaldata->uid;
                    LoginWindow *main=new LoginWindow;
                    main->show();
                }
            }

        }

    }

}
//void dengluWindow::sendRequest()
//{
//    GlobalData* globaldata = GlobalData::getInstance();
//    //关闭登录界面，打开过渡界面
//    this->close();
//    this->g=new guodu;
//    this->g->show();
//    //传输ID和密码
//    QString ID=ui->lineEdit_ID->text();
//    QString password=ui->lineEdit_password->text();
//    //LOGIN_REQUEST = 2,//登录请求 需要id、密码
//    //00020002____ID____password
//    //返回指令是1002~1004
//    Request re;
//    re.msgNum=2;
//    re.msgList.append(ID);
//    re.msgList.append(password);
//    re.requestType=RequestType::LOGIN_REQUEST;



//    QString stext=re.requestToCode();

//    globaldata->socket->write(stext.toUtf8());

//    //接受服务器信号
//    connect(globaldata->socket,SIGNAL(readyRead()),this,SLOT(recivmessage()));
//}

//void dengluWindow::recivmessage()
//{
//    GlobalData* globaldata = GlobalData::getInstance();
//    //关闭过渡界面
//    this->g->close();

//    //根据返回的信息决定跳转界面
//    QByteArray byteArray = globaldata->socket->readAll();
//    Request re;
//    re.codeToRequest(byteArray);
//    QString rmessage=byteArray;

//    //判断是否成功
//    if(re.requestType == RequestType::LOGIN_FAIL_WRONG_PASSWORD)
//    {

//        dengluWindow *main=new dengluWindow;
//        qDebug() << " 1111  ";
//        main->show();
//        QMessageBox::warning(this,"登录失败","密码不正确");
//    }
//    if(re.requestType==RequestType::LOGIN_FAIL_NO_USER)
//    {

//        dengluWindow *main=new dengluWindow;
//        qDebug() << " 1111  ";
//        main->show();
//        QMessageBox::warning(this,"登录失败","用户不存在");
//    }
//    if(re.requestType==RequestType::LOGIN_SUCCESS)
//    {
//        //转到好友界面

//        QString ID=ui->lineEdit_ID->text();
//        globaldata->uid=ID;
//        globaldata->uname=re.msgList[0];
//        globaldata->uphoto=re.msgList[1];
//        globaldata->uip=re.msgList[2];

//        qDebug()<<globaldata->uid;
//        LoginWindow *main=new LoginWindow;
//        main->show();
//    }
//}
//转换标准格式
//QString dengluWindow::Mark(QString m)
//{
//    QString a="0000";
//    int b,i,c;
//    c=3;
//    b=m.length();
//    for(i=b-1;i>=0;i--)
//    {
//        a[c]=m[i];
//        c--;
//    }
//   return a;
//}


void dengluWindow::on_pushButton_3_clicked()
{
    QString ID=ui->lineEdit_ID->text();
    if(ID==NULL||ID.length()!=5)
    {
        QMessageBox::warning(this,"忘记密码","用户ID格式不正确");
    }
    else
    {
    GlobalData * globaldata= GlobalData::getInstance();
    QString ID=ui->lineEdit_ID->text();
    globaldata->uid=ID;
    qDebug()<<ID;
    //SECURITY_QUESTION_ANSWER_REQUEST = 29,//(登录页面、主页面)密保问题、答案申请，给出用户id，返回密保问题和答案
    //00290001____UserId
    //返回指令是1034
    Request re;
    re.requestType=RequestType::SECURITY_QUESTION_ANSWER_REQUEST;
    re.msgNum=1;
    re.msgList.append(ID);
    QString stext=re.requestToCode();
    qDebug() << stext;

    globaldata->socket->write(stext.toUtf8());
    if(globaldata->socket->waitForReadyRead())
    {
        QByteArray byteArray = globaldata->socket->readAll();
        QString read=byteArray;
        qDebug() << read;
        //SECURITY_QUESTION_ANSWER_REPLY = 1034,//(登录页面、主页面)密保问题、答案申请，给出用户id，返回密保问题和答案
        //10340002____SecurityQues____Answer
        //请求指令是0029
        qDebug() << " 收到忘记密码  ";
        Request re;
        re.codeToRequest(byteArray);
        //qDebug() << re.msgList[0];
        if(re.requestType == RequestType::SECURITY_QUESTION_ANSWER_REPLY)
        {
            GlobalData2::question=re.msgList[0];
            GlobalData2::solution=re.msgList[1];
            this->close();
            forgetpwd *main=new forgetpwd;
            main->show();//打开找回密码界面

        }
    }

    //globaldata->socket->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
    //connect(globaldata->socket, SIGNAL(connected()), this, SLOT(sendRequest2()));
    qDebug() << " 1111  ";
    }
}

void dengluWindow::sendRequest2()
{

    GlobalData * globaldata= GlobalData::getInstance();

    QString ID=ui->lineEdit_ID->text();
    globaldata->uid=ID;
    //SECURITY_QUESTION_ANSWER_REQUEST = 29,//(登录页面、主页面)密保问题、答案申请，给出用户id，返回密保问题和答案
    //00290001____UserId
    //返回指令是1034
    Request re;
    re.requestType=RequestType::SECURITY_QUESTION_ANSWER_REQUEST;
    re.msgNum=1;
    re.msgList.append(ID);
    QString stext=re.requestToCode();
    qDebug() << stext;

    globaldata->socket->write(stext.toUtf8());
    //接受服务器信号
    connect(globaldata->socket,SIGNAL(readyRead()),this,SLOT(recivmessage2()));
}
void dengluWindow::recivmessage2()
{
    GlobalData * globaldata= GlobalData::getInstance();
    //根据返回的信息决定跳转界面
    QByteArray byteArray = globaldata->socket->readAll();
    QString read=byteArray;
    qDebug() << read;
    //SECURITY_QUESTION_ANSWER_REPLY = 1034,//(登录页面、主页面)密保问题、答案申请，给出用户id，返回密保问题和答案
    //10340002____SecurityQues____Answer
    //请求指令是0029
    qDebug() << " 收到忘记密码  ";
    Request re;
    re.codeToRequest(byteArray);
    //qDebug() << re.msgList[0];
    if(re.requestType == RequestType::SECURITY_QUESTION_ANSWER_REPLY)
    {
        GlobalData2::question=re.msgList[0];
        GlobalData2::solution=re.msgList[1];
        this->close();
        forgetpwd *main=new forgetpwd;
        main->show();//打开找回密码界面

    }
}
