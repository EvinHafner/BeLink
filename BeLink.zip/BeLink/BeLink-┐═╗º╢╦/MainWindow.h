//#ifndef MAINWINDOW_H
//#define MAINWINDOW_H

//#include <QMainWindow>
//#include <QTcpSocket>
//#include "guodu.h"

//QT_BEGIN_NAMESPACE
//namespace Ui { class MainWindow; }
//QT_END_NAMESPACE

//class dengluWindow : public QMainWindow
//{
//    Q_OBJECT

//public:
//    dengluWindow(QWidget *parent = nullptr);
//    ~dengluWindow();

//private slots:
//    void on_pushButton_2_clicked();

//    void on_pushButton_clicked();//登录按钮

//    void sendRequest();//发送信号

//    void recivmessage();//接受信号

//    QString Mark(QString m);//字符串长度的格式转换

//private:
//    Ui::MainWindow *ui;
//    QTcpSocket *m;
//    guodu *g;
//};
//#endif // MAINWINDOW_H
////客户端

