#include "ChangeNickname.h"
#include "Request.h"
#include "guodu.h"
#include "LoginWindow.h"
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QDebug>
   ChangeNickname::ChangeNickname(QWidget* parent) : QWidget(parent) {

        setWindowTitle("修改昵称");

        lineEdit = new QLineEdit(this);
        lineEdit->setPlaceholderText("请输入新昵称");

        submitButton = new QPushButton("修改", this);

        QVBoxLayout* layout = new QVBoxLayout(this);
        layout->addWidget(lineEdit);
        layout->addWidget(submitButton);

        QObject::connect(submitButton, &QPushButton::clicked, this, &ChangeNickname::handleSubmit);

        setLayout(layout);
    }


    void ChangeNickname::handleSubmit()
    {
        GlobalData* globaldata = GlobalData::getInstance();
        //传inputText到服务器
        //连接服务器
        QString inputText = lineEdit->text();

        //globaldata->socket=new QTcpSocket(this);
        //this->m->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
        //connect(this->m, SIGNAL(connected()), this, SLOT(sendRequest()));
        //GlobalData* globaldata = GlobalData::getInstance();


        //CHANGE_NICKNAME_REQUEST = 12,//更换昵称，需要UserId与新昵称
        //00120002____UserId____NickName
        //返回指令是1017

        //QString inputText = lineEdit->text();
        Request re;
        re.msgNum=2;
        re.requestType=RequestType::CHANGE_NICKNAME_REQUEST;
        re.msgList.append(globaldata -> uid);
        re.msgList.append(inputText);
        QString stext = re.requestToCode();
        globaldata->socket->write(stext.toUtf8());
        if(globaldata->socket->waitForReadyRead())
        {
            QByteArray byteArray = globaldata->socket->readAll();
            QString rmessage=byteArray;
            //处理编码为请求
            Request re2;
            re2.codeToRequest(byteArray);
            //判断更改是否成功
            //CHANGE_NICKNAME_SUCCESS = 1017,//更换昵称成功
            //1017
            //请求指令是0012
            if(re2.requestType==RequestType::CHANGE_NICKNAME_SUCCESS)
            {
                QMessageBox::information(this,"修改昵称","修改成功");
            }
            globaldata->uname=inputText;
        }

    }

//    void ChangeNickname::sendRequest()
//    {
        //GlobalData* globaldata = GlobalData::getInstance();
        //CHANGE_NICKNAME_REQUEST = 12,//更换昵称，需要UserId与新昵称
        //00120002____UserId____NickName
        //返回指令是1017

        //QString inputText = lineEdit->text();
//        Request re;
//        re.msgNum=2;
//        re.requestType=RequestType::CHANGE_NICKNAME_REQUEST;
//        re.msgList.append(globaldata -> uid);
//        re.msgList.append(inputText);
//        QString stext = re.requestToCode();
//        this->m->write(stext.toUtf8());
//        connect(this->m,SIGNAL(readyRead()),this,SLOT(recivmessage()));
//    }
//    void ChangeNickname::recivmessage()
//    {
//        QByteArray byteArray = this->m->readAll();
//        QString rmessage=byteArray;
//        //处理编码为请求
//        Request re2;
//        re2.codeToRequest(byteArray);
//        //判断更改是否成功
//        //CHANGE_NICKNAME_SUCCESS = 1017,//更换昵称成功
//        //1017
//        //请求指令是0012
//        if(re2.requestType==RequestType::CHANGE_NICKNAME_SUCCESS)
//        {
//            QMessageBox::information(this,"修改昵称","修改成功");
//        }
//    }
