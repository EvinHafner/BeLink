#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QDebug>
#include "joinGroup.h"
#include "Request.h"
#include "guodu.h"
#include "LoginWindow.h"
    joinGroup::joinGroup(QWidget* parent) : QWidget(parent) {
        setWindowTitle("加入群聊");

        lineEdit = new QLineEdit(this);
        lineEdit->setPlaceholderText("请输入群聊ID");

        submitButton = new QPushButton("加入", this);

        QVBoxLayout* layout = new QVBoxLayout(this);
        layout->addWidget(lineEdit);
        layout->addWidget(submitButton);


        QObject::connect(submitButton, &QPushButton::clicked, this, &joinGroup::handleSubmit);

        setLayout(layout);
    }


    void joinGroup::handleSubmit()
    {
         GlobalData* globaldata = GlobalData::getInstance();
        //传inputText到服务器
        //连接服务器
        QString inputText = lineEdit->text();
           Request re;
           re.msgNum=2;
           re.requestType=RequestType::JOIN_GROUP_CHAT_REQUEST;
           re.msgList.append(globaldata->uid);
           re.msgList.append(inputText);
           QString stext = re.requestToCode();
           globaldata->socket->write(stext.toUtf8());
           if(globaldata->socket->waitForReadyRead()){
               QByteArray byteArray = globaldata->socket->readAll();
               QString rmessage=byteArray;
               //处理编码为请求
               Request re2;
               re2.codeToRequest(byteArray);

               if(re2.requestType==RequestType::JOIN_GROUP_CHAT_SUCCESS)
               {
                   QMessageBox::information(this,"加入群聊","加入群聊成功");
               }
                             //CREATE_GROUP_FAIL = 1011,//创建好友分组失败 只可能是因为与现有组组名重复
                             //1011
                             //请求指令是0007
                             if(re2.requestType==RequestType::CREATE_GROUP_FAIL)
                             {
                                 QMessageBox::information(this,"加入群聊失败捏","原神，启动！");
                             }

                         }

                   }
