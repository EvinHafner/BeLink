#include "fileuploadwindow.h"

FileUploadWindow::FileUploadWindow(QWidget *parent)
    : QDialog(parent)
{
    filePathLineEdit = new QLineEdit(this);

    QPushButton *selectButton = new QPushButton("Select File", this);
    connect(selectButton, &QPushButton::clicked, this, &FileUploadWindow::selectFile);

    QPushButton *uploadButton = new QPushButton("Upload", this);
    connect(uploadButton, &QPushButton::clicked, this, &FileUploadWindow::uploadFile);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(filePathLineEdit);
    layout->addWidget(selectButton);
    layout->addWidget(uploadButton);

    setLayout(layout);
    setWindowTitle("File Upload");
}

void FileUploadWindow::selectFile()
{
    QString filePath = QFileDialog::getOpenFileName(this, "Select File", QDir::homePath());
    filePathLineEdit->setText(filePath);
}

void FileUploadWindow::uploadFile()
{
    QString filePath = filePathLineEdit->text();
    if (!filePath.isEmpty()) {
        emit fileSelected(filePath);
        close();
    }
}
