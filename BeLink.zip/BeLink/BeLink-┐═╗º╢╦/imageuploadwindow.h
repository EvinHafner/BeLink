#ifndef IMAGEUPLOADWINDOW_H
#define IMAGEUPLOADWINDOW_H

#include <QDialog>
#include <QPushButton>
#include <QLineEdit>
#include <QVBoxLayout>

class ImageUploadWindow : public QDialog
{
    Q_OBJECT

public:
    ImageUploadWindow(QWidget *parent = nullptr);

signals:
    void imageSelected(const QString &imagePath);

private slots:
    void selectImage();

private:
    QLineEdit *imagePathInput;
    QPushButton *selectButton;
};

#endif // IMAGEUPLOADWINDOW_H
