#ifndef SETGROUP_H
#define SETGROUP_H

#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QDebug>
#include <QTcpSocket>
#include "GlobalData.h"

class setGroup: public QWidget {
public:
    setGroup(QWidget* parent = nullptr) ;

private slots:
    void handleSubmit() ;
    QString Mark(QString m);//字符串长度的格式转换

private:
    QLineEdit* lineEdit;
    QPushButton* submitButton;

};

#endif // SETGROUP_H
