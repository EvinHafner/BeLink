#ifndef SIGNUP_H
#define SIGNUP_H

#include <QWidget>
#include <QTcpSocket>
#include "guodu.h"

namespace Ui {
class signup;
}

class signup : public QWidget
{
    Q_OBJECT

public:
    explicit signup(QWidget *parent = nullptr);
    ~signup();

private slots:
    void on_pushButton_clicked();

    void on_lineEdit_3_editingFinished();

    void on_pushButton_2_clicked();

    void sendRequest();//发送信号

    void recivmessage();//接受信号
    QString Mark(QString m);//字符串长度的格式转换

private:
    Ui::signup *ui;
    QTcpSocket *m;
    guodu *g;
};

#endif // SIGNUP_H
