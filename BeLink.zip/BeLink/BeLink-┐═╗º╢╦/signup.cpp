#include "signup.h"
#include "ui_signup.h"
#include "mainwindow.h"
#include "Request.h"
#include "chatwindow.h"
#include <QGraphicsDropShadowEffect>
#include <QCoreApplication>
#include <QTextCodec>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QTime>
#include <QSqlError>
#include <QtDebug>
#include <QSqlDriver>
#include <QSqlRecord>
#include <QWidget>
#include <QValidator>
#include <QMessageBox>
#include <QTcpSocket>
#include <QString>
#include <QHostAddress>
#include "dengluwindow.h"
#include "LoginWindow.h"
#include <QHostInfo>
#include <QNetworkInterface>

signup::signup(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::signup)
{
    ui->setupUi(this);
    //设置背景图片
    QPixmap *pix = new QPixmap(":/bizhi/登录壁纸.jpeg");
    QSize sz = ui->beijing1->size();
    ui->beijing1->setPixmap(pix->scaled(sz));
    //设置一键清空
    ui->lineEdit_2->setClearButtonEnabled(true);
    //密码格式（由数字和26个英文字母组成的字符串）
    QRegExp regx("^[A-Za-z0-9]+$");
    QValidator *validatorName = new QRegExpValidator(regx);
    ui->lineEdit_2->setValidator(validatorName);
    ui->lineEdit_3->setValidator(validatorName);

}

signup::~signup()
{
    delete ui;
}

void signup::on_pushButton_clicked()
{
    QString username=ui->lineEdit->text();//昵称
    QString passwd=ui->lineEdit_2->text();//密码
    QString surepasswd=ui->lineEdit_3->text();//确认密码
    QString question=ui->lineEdit_4->text();//密保问题
    QString solution=ui->lineEdit_5->text();//回答



    if(username==NULL||passwd==NULL||surepasswd==NULL||question==NULL||solution==NULL)
    {
        QMessageBox::warning(this,"注册认证","内容不能为空");
    }
    else
    {
        if(passwd!=surepasswd)
        {
            QMessageBox::warning(this,"注册认证","两次密码不一致");
        }
        else
        {
            //尝试连接服务器
//            this->m=new QTcpSocket(this);

//            this->m->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
//            connect(this->m, SIGNAL(connected()), this, SLOT(sendRequest()));
            GlobalData * globaldata= GlobalData::getInstance();
            //关闭登录界面，打开过渡界面
            this->close();
            this->g=new guodu;
            this->g->show();
            //传输昵称，密码，密保问题，回答
            QString username=ui->lineEdit->text();//昵称
            QString passwd=ui->lineEdit_2->text();//密码
            QString surepasswd=ui->lineEdit_3->text();//确认密码
            QString question=ui->lineEdit_4->text();//密保问题
            QString solution=ui->lineEdit_5->text();//回答

            //REGISTER_REQUEST = 1,//注册请求 需要昵称、密码、ip、密保问题、答案
            //00010005____Nickname____password____ip____SecurityQuestion____Answer
            //返回指令是1001
            QString ipAddress = QHostInfo::localHostName();
            QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();

            for (const QHostAddress &address : ipAddressesList) {
                if (address.protocol() == QAbstractSocket::IPv4Protocol && !address.isLoopback())
                    ipAddress = address.toString();
            }
            globaldata->uip = ipAddress;
            Request re;
            re.msgNum=5;
            re.requestType=RequestType::REGISTER_REQUEST;
            re.msgList.append(username);
            re.msgList.append(passwd);
            re.msgList.append(globaldata->uip);
            re.msgList.append(question);
            re.msgList.append(solution);
            QString stext=re.requestToCode();
            globaldata->socket->write(stext.toUtf8());
            if(globaldata->socket->waitForReadyRead())
            {
                //关闭过渡界面
                this->g->close();

                //根据返回的信息决定跳转界面
                QByteArray byteArray = globaldata->socket->readAll();
                QString rmessage=byteArray;
                Request re;
                re.codeToRequest(byteArray);
                if(re.requestType==RequestType::REGISTER_SUCCESS)
                {
                    globaldata->uid=re.msgList[0];
                    globaldata->uname=username;
                    globaldata->uphoto="default.jpg";

                    QMessageBox::information(this,"注册认证","注册成功");
                    //转为用户主界面
                    LoginWindow *main=new LoginWindow;
                    main->show();
                }

            }
        }

    }


}
void signup::sendRequest()
{

    //关闭登录界面，打开过渡界面
    this->close();
    this->g=new guodu;
    this->g->show();
    //传输昵称，密码，密保问题，回答
    QString username=ui->lineEdit->text();//昵称
    QString passwd=ui->lineEdit_2->text();//密码
    QString surepasswd=ui->lineEdit_3->text();//确认密码
    QString question=ui->lineEdit_4->text();//密保问题
    QString solution=ui->lineEdit_5->text();//回答
    //REGISTER_REQUEST = 1,//注册请求 需要昵称、密码、ip、密保问题、答案

        //00010005____Nickname____password____ip____SecurityQuestion____Answer

        //返回指令是1001



        Request re;

        re.msgNum=5;

        re.requestType=RequestType::REGISTER_REQUEST;

        re.msgList.append(username);

        re.msgList.append(passwd);
        //re.msgList.append();
        re.msgList.append(question);

        re.msgList.append(solution);

        QString stext=re.requestToCode();
    this->m->write(stext.toUtf8());
    //受服务器信号
    connect(this->m,SIGNAL(readyRead()),this,SLOT(recivmessage()));
}

void signup::recivmessage()
{
    GlobalData* globaldata = GlobalData::getInstance();
    //关闭过渡界面
    this->g->close();

    //根据返回的信息决定跳转界面
    QByteArray byteArray = this->m->readAll();
    QString rmessage=byteArray;
    Request re;
    re.codeToRequest(byteArray);
    if(re.requestType==RequestType::REGISTER_SUCCESS)
    {
        globaldata->uid=re.msgList[0];
        QMessageBox::information(this,"注册认证","注册成功");
        //转为用户主界面
        LoginWindow *main=new LoginWindow;
        main->show();
    }


}

void signup::on_lineEdit_3_editingFinished()
{
    QString passwd=ui->lineEdit_2->text();
    QString surepasswd=ui->lineEdit_3->text();
    if(passwd!=surepasswd)
    {
        QMessageBox::warning(this,"注册认证","两次密码不一致");
    }
}
//返回登录界面
void signup::on_pushButton_2_clicked()
{
    this->close();
    dengluWindow *s=new dengluWindow;
    s->show();
}
QString signup::Mark(QString m)
{
    QString a="0000";
    int b,i,c;
    c=3;
    b=m.length();
    for(i=b-1;i>=0;i--)
    {
        a[c]=m[i];
        c--;
    }
   return a;
}
