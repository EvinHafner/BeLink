#include "GlobalData.h"
#include "MyWidget.h"
#include "LoginWindow.h"
#include "changepwd.h"
#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QTreeWidget>
#include <QBitArray>
#include "setGroup.h"
#include "Request.h"
#include <QPalette>



LoginWindow::LoginWindow(QWidget* parent ) : QWidget(parent) {

    //GlobalData::socket.connectToHost("192.168.43.100",12345);
    //connect(this->m, SIGNAL(connected()), this, SLOT(sendRequest(path)));
//    GlobalData* globaldata = GlobalData::getInstance();
    setWindowTitle("BeLink");


    MyWidget* widget = new MyWidget();
    widget->setWindowTitle("MyTreeWidget控件");

//    QPushButton* addFriendButton = new QPushButton("添加朋友", this);
//    QPushButton* addGroupButton = new QPushButton("新建分组", this);

//    QWidget* infoWidget = createInfoWidget(parent,widget);

//    QTreeWidget* treeWidget = createTreeWidget(parent,widget);

//    treeWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

//    QVBoxLayout* layout = new QVBoxLayout(this);
//    layout->addWidget(infoWidget);
//    layout->addWidget(treeWidget);
//    layout->addWidget(addFriendButton);
//    layout->addWidget(addGroupButton);
//    setStyleSheet("border: 1px solid black;");
    QPushButton* addFriendButton = new QPushButton("添加朋友", this);
    QPushButton* addGroupButton = new QPushButton("新建分组", this);
    QPushButton* joinGroupButton = new QPushButton("加入群聊", this);//功能待完善
    QPushButton* setGroupButton = new QPushButton("创建群聊", this);//功能待完善

    QWidget* infoWidget = createInfoWidget(parent,widget);
    QTreeWidget* treeWidget = createTreeWidget(parent,widget);
    QTreeWidget* chatWidget = createGroupChat(parent,widget);

    treeWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    QVBoxLayout* layout = new QVBoxLayout(this);
    layout->addWidget(infoWidget);
    layout->addWidget(treeWidget);
    layout->addWidget(chatWidget);
    QHBoxLayout* layout_of_bottom = new QHBoxLayout;
    layout_of_bottom->addWidget(addFriendButton);
    layout_of_bottom->addWidget(addGroupButton);
    layout_of_bottom->addWidget(joinGroupButton);
    layout_of_bottom->addWidget(setGroupButton);
    layout->addLayout(layout_of_bottom);
    setStyleSheet("border: 1px solid black;");
    connect(addFriendButton, &QPushButton::clicked, this, &LoginWindow::openInputWidget);
    connect(addGroupButton, &QPushButton::clicked, this, &LoginWindow::openaddGroup);
    connect(joinGroupButton,&QPushButton::clicked,this,&LoginWindow::openjoinGroup);
    connect(setGroupButton, &QPushButton::clicked, this, &LoginWindow::opensetGroup);
    // 创建 QTimer 对象
    QTimer* timer = new QTimer(this);
    // 连接 QTimer 的 timeout() 信号到 refresh() 槽函数
    QObject::connect(timer, &QTimer::timeout, this, [this,widget]() {
        rebuildUI(this,widget);
    });
    // 设置定时器间隔为 30000 毫秒（即每30秒触发一次）
    timer->setInterval(10000);
    // 启动定时器
    timer->start();
    QPixmap backgroundImage(":/back/backG.png");
    QPalette palette;
    palette.setBrush(QPalette::Background,QBrush(backgroundImage));
    this->setPalette(palette);
}

void LoginWindow::receive(){
    GlobalData * globaldata =GlobalData::getInstance();
    RB = globaldata-> socket -> readAll();
}

QTreeWidget* LoginWindow::createTreeWidget(QWidget* parent, MyWidget* widget)
{
    GlobalData* globaldata = GlobalData::getInstance();
    //persume id

    // 创建树形部件
    QTreeWidget* treeWidget = new QTreeWidget(parent);
    treeWidget->setHeaderLabel("朋友列表");

    //ask for group list
    Request groupList;
    groupList.requestType = RequestType ::GROUP_NAMES_REQUEST;
    groupList.msgNum = 1;
    groupList.msgList.append(globaldata->uid);
    QString gL = groupList.requestToCode();
    qDebug() << RB;
    //qDebug() << globaldata->socket->state();
    //qDebug() << connect(globaldata->socket,&QTcpSocket::readyRead,this,&LoginWindow::receive);

    //qDebug() << connect(globaldata->socket,&QTcpSocket::readyRead,this,&LoginWindow::receive);
    globaldata -> socket -> write(gL.toUtf8());
    //connect(globaldata->socket,&QTcpSocket::readyRead,this,&LoginWindow::receive);
    if(globaldata->socket->waitForReadyRead()){
        RB=globaldata->socket->readAll();
        qDebug() << RB;
    }
//    //example
//    //back
//    QByteArray code;
//    Request re;
//    re.codeToRequest(code);
//    //ask
//    QString groupname;
//    re.requestType =RequestType::FRIENDS_OF_GROUP_REPLY;
//    re.msgNum = 2;
//    re.msgList.append(id);
//    re.msgList.append(groupname);
//    QByteArray re2 = re.requestToCode();
    //return group list)
    //QByteArray gLB= globaldata -> socket ->readAll();
    Request groupListB;
    groupListB.codeToRequest(RB);


    for (QString groupName : groupListB.msgList){
        if(groupName == "群聊"){
            continue;
        }
        QTreeWidgetItem* groupItem = new QTreeWidgetItem(treeWidget);
        groupItem->setText(0, groupName);

        //ask for people in group

        QString gRA;
        Request groupRequestA;
        groupRequestA.requestType = RequestType::FRIENDS_OF_GROUP_REQUEST;
        groupRequestA.msgNum = 2;
        groupRequestA.msgList.append(globaldata->uid);
        groupRequestA.msgList.append(groupName);
        gRA = groupRequestA.requestToCode();
        globaldata ->socket ->write(gRA.toUtf8());

        //receive people in group
        //connect(globaldata->socket,SIGNAL(readyRead()),this,SLOT(receive()));
        //QByteArray gRB= globaldata ->socket ->readAll();
        if(globaldata->socket->waitForReadyRead()){
            RB=globaldata->socket->readAll();
            qDebug() << RB;
        }
        Request groupRequestB;
        groupRequestB.codeToRequest(RB);

        for (QString contactID : groupRequestB.msgList){
            //ask for selfinfo
            QString fRA;
            Request friendRequestA;
            friendRequestA.requestType = RequestType::FRIEND_INFOMATION_REQUEST;
            friendRequestA.msgNum = 2;
            friendRequestA.msgList.append(globaldata->uid);
            friendRequestA.msgList.append(contactID);
            fRA = friendRequestA.requestToCode();
            globaldata ->socket ->write(fRA.toUtf8());

            //receive for selfinfo
            //connect(globaldata->socket,SIGNAL(readyRead()),this,SLOT(receive()));
            if(globaldata->socket->waitForReadyRead()){
                RB=globaldata->socket->readAll();
            }
            //QByteArray fRB = globaldata ->socket ->readAll();
            Request friendRequestB;
            friendRequestB.codeToRequest(RB);

            QString contactName = friendRequestB.msgList[0];
            QString avLocation = friendRequestB.msgList[1];
            int isOnline = friendRequestB.msgList[2].toInt();
            int existNew = friendRequestB.msgList[3].toInt();
            QTreeWidgetItem* contactItem = new QTreeWidgetItem(groupItem);
            contactItem->setText(0, contactName);
            contactItem->setData(0,Qt::UserRole,contactID);
            QFont contactFont;
            contactFont.setPointSize(16); // 设置字体大小
            contactItem->setFont(0, contactFont);
            qDebug() << avLocation;
            if (isOnline == 1){
                if (existNew == 1){
                    avLocation = ":/HeadersN/N" +avLocation;
                }
                else {
                    avLocation = ":/Headers/" +avLocation;
                }
            }
            else{
                if (existNew == 1){
                    avLocation = ":/HeadersNG/NG" +avLocation;
                }
                else {
                    avLocation = ":/HeadersG/G" +avLocation;
                }
            }
//            QString avLocation=":/Headers/dog.jpg";
            QPixmap contactPixmap(avLocation);
            contactPixmap = contactPixmap.scaled(QSize(40, 40), Qt::KeepAspectRatio, Qt::SmoothTransformation); // 设置头像大小
            contactItem->setIcon(0, QIcon(contactPixmap));
            groupItem->addChild(contactItem);
            //qDebug() << RB;
        }

        // 将分组节点添加到树形部件中
        treeWidget->expandAll();
        treeWidget->addTopLevelItem(groupItem);
    }

    QObject::connect(treeWidget, &QTreeWidget::itemClicked, widget, &MyWidget::itemClicked);

    treeWidget->setIconSize(QSize(30, 30));
    qDebug() << "createTree";
    treeWidget->setStyleSheet("background-image: url(:/back/cloud.png)");
    return treeWidget;
}

void LoginWindow::opensetGroup(){
    setGroup  *set = new setGroup();
    set->show();
}

void LoginWindow::openChangeNick() {
    // 创建跳转目标界面的对象
  ChangeNickname* otherWidget = new ChangeNickname();
    // 执行界面的跳转
    otherWidget->show();
}

void LoginWindow::openjoinGroup(){
    joinGroup* join = new joinGroup();
    join->show();
}

void LoginWindow::openChangepwd() {
    // 创建跳转目标界面的对象
    changepwd * main = new changepwd();
    // 跳转修改密码界面
    main->show();
}


QWidget* LoginWindow::createInfoWidget(QWidget* parent, MyWidget* widget)
{
    GlobalData* globaldata = GlobalData::getInstance();
    //    //example
    //    //back
    //    QByteArray code;
    //    Request re;
    //    re.codeToRequest(code);
    //    //ask
    //    QString groupname;
    //    re.requestType =RequestType::FRIENDS_OF_GROUP_REPLY;
    //    re.msgNum = 2;
    //    re.msgList.append(id);
    //    re.msgList.append(groupname);
    //    QByteArray re2 = re.requestToCode();


    QWidget* infoWidget = new QWidget(parent);
    infoWidget->setWindowTitle("个人信息");
    QHBoxLayout* infoLayout = new QHBoxLayout(infoWidget);
    infoLayout->setContentsMargins(10, 10, 10, 10);
    infoLayout->setSpacing(10);


    QString location;//头像存储的地址
    // 创建头像标签
    ClickableLabel* avatarLabel = createAvatarLabel(infoWidget,widget,":/Headers/" + globaldata->uphoto);

    // 创建显示昵称的位置
    QPushButton* button = new QPushButton(globaldata -> uname, infoWidget);

    QLabel* IPandID = new QLabel("ID:"+ globaldata -> uid +"\nIP:"+ globaldata -> uip, infoWidget);

    // 将头像标签和IP地址标签添加到容器布局中
    infoLayout->addWidget( avatarLabel);
    infoLayout->addStretch();
    // 将按钮添加到布局中
    infoLayout->addWidget(button);
    infoLayout->addWidget(IPandID);
    QObject::connect(button, &QPushButton::clicked, this, &LoginWindow::openChangeNick);

    QPushButton* changePassword = new QPushButton("修改密码", this);// waiting...
        infoLayout->addWidget(changePassword);
    QObject::connect(changePassword, &QPushButton::clicked, this, &LoginWindow::openChangepwd);
    qDebug() << "createInfo";
    return infoWidget;
}
ClickableLabel* LoginWindow::createAvatarLabel(QWidget* parent, MyWidget* widget,QString loc)
{
    ClickableLabel* avatarLabel = new ClickableLabel(parent);
    QPixmap avatarPixmap(loc);
    avatarPixmap = avatarPixmap.scaled(QSize(70, 70), Qt::KeepAspectRatio, Qt::SmoothTransformation);
    avatarLabel->setPixmap(avatarPixmap);
    avatarLabel->setMouseTracking(true);
    avatarLabel->setAttribute(Qt::WA_Hover);
    QObject::connect(avatarLabel, &ClickableLabel::clicked, widget, &MyWidget::avatarClicked);

    return avatarLabel;
}

void LoginWindow::rebuildUI(QWidget* window, MyWidget* widget) {
    qDebug() << "refresh";
    QVBoxLayout* layout = dynamic_cast<QVBoxLayout*>(window->layout());
    if (layout) {
        // 移除现有部件
        while (QLayoutItem* item = layout->takeAt(0)) {
            delete item->widget();
            delete item;
        }

        // 重新创建部件
        QWidget* infoWidget = createInfoWidget(window, widget);
        QTreeWidget* treeWidget = createTreeWidget(window, widget);
        QTreeWidget* chatWidget = createGroupChat(window,widget);
        QPushButton *addFriend = new QPushButton("添加朋友", window);
        // addFriend->setIcon(QIcon("qrc:/Headers/default.jpg"));
        QPushButton *addGroup = new QPushButton("新建分组", window);
        QPushButton *joinGroup = new QPushButton("加入群聊", window);
        QPushButton *setGroup = new QPushButton("创建群聊", window);
        QObject::connect(addFriend, &QPushButton::clicked, [&]() {openInputWidget();});
        QObject::connect(addGroup, &QPushButton::clicked, [&]() {openaddGroup();});
        QObject::connect(setGroup, &QPushButton::clicked, [&]() {opensetGroup();});
        treeWidget->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        // 将部件添加到布局中
        layout->addWidget(infoWidget);
        layout->addWidget(treeWidget);
        layout->addWidget(chatWidget);
        QHBoxLayout* layout1 = new QHBoxLayout();
        layout1->addWidget(addFriend);
        layout1->addWidget(addGroup);
        layout1->addWidget(joinGroup);
        layout1->addWidget(setGroup);
        layout->addLayout(layout1);
        QObject::connect(joinGroup, &QPushButton::clicked, [&]() {
                openjoinGroup();
            });
        /*
        QObject::connect(addGroup, &QPushButton::clicked, [&]() {
                openaddGroup();
            }); */
        window->setLayout(layout);
        window->update();
    }
}

void LoginWindow::openInputWidget() {
    InputWidget* inputWidget = new InputWidget();
    inputWidget->show();
}

void LoginWindow::openaddGroup() {
    addGroup * AddGroup =new addGroup();
    AddGroup->show();
}

QTreeWidget* LoginWindow::createGroupChat(QWidget* parent, MyWidget* widget){

    GlobalData * globaldata = GlobalData::getInstance();

    QString id =globaldata->uid;

    // 创建树形部件

    QTreeWidget* treeWidget = new QTreeWidget(parent);

    treeWidget->setHeaderLabel("群聊列表");

    Request chatList;

    chatList.requestType = RequestType ::GROUP_CHAT_OF_USER_REQUEST;

    chatList.msgNum = 1;

    chatList.msgList.append(id);

    QString cLA = chatList.requestToCode();

    globaldata->socket ->write(cLA.toUtf8());

    if(globaldata->socket->waitForReadyRead()){

        RB=globaldata->socket->readAll();

    }

    //QByteArray cLB= globaldata->socket ->readAll();

    Request chatListB;

    chatListB.codeToRequest(RB);


    for (QString contactID : chatListB.msgList){

        //ask for selfinfo

        QString fRA;

        Request friendRequestA;

        friendRequestA.requestType = RequestType::GROUP_CHAT_INFOMATION_REQUEST;

        friendRequestA.msgNum = 2;

        friendRequestA.msgList.append(id);

        friendRequestA.msgList.append(contactID);

        fRA = friendRequestA.requestToCode();

        globaldata->socket ->write(fRA.toUtf8());


        if(globaldata->socket->waitForReadyRead()){

            RB=globaldata->socket->readAll();

        }

        //receive for selfinfo

        //QByteArray fRB = globaldata->socket ->readAll();

        Request friendRequestB;

        friendRequestB.codeToRequest(RB);


        QString contactName = friendRequestB.msgList[0];

        QString avLocation = friendRequestB.msgList[1];



        QTreeWidgetItem* contactItem = new QTreeWidgetItem(treeWidget);

        contactItem->setText(0, contactName+"  ("+contactID+")");

        contactItem->setData(0, Qt::UserRole, contactID); // 将 contactID 存储在 UserRole 中

        QFont contactFont;

        contactFont.setPointSize(16); // 设置字体大小

        contactItem->setFont(0, contactFont);


        QPixmap contactPixmap(":/Headers/default.jpg");

        contactPixmap = contactPixmap.scaled(QSize(40, 40), Qt::KeepAspectRatio, Qt::SmoothTransformation); // 设置头像大小

        contactItem->setIcon(0, QIcon(contactPixmap));

        treeWidget->addTopLevelItem(contactItem);

    }

    QObject::connect(treeWidget, &QTreeWidget::itemClicked, widget, &MyWidget::chatClicked);


    treeWidget->setIconSize(QSize(30, 30));

    treeWidget->expandAll();

    treeWidget->setStyleSheet("background-image: url(:/back/tree.jpg)");

    return treeWidget;

}

void LoginWindow::closeEvent(QCloseEvent *e){

    //窗口关闭时弹出的提示窗口

    QMessageBox msgBox;

    msgBox.setText("提示");

    msgBox.setInformativeText("确认退出?");

    msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);

    msgBox.setDefaultButton(QMessageBox::Ok);

    int ret = msgBox.exec();

    if(ret == QMessageBox::Ok){

        //若用户点击确认，则接收这个事件,当前窗口会关闭

        GlobalData* globaldata = GlobalData::getInstance();

        Request re;

        re.requestType = RequestType ::LOG_OUT_REQUEST;

        re.msgNum = 1;

        re.msgList.append(globaldata->uid);

        QString gl = re.requestToCode();

        globaldata -> socket -> write(gl.toUtf8());

        if(globaldata->socket->waitForReadyRead()){

            QByteArray rb=globaldata->socket->readAll();

            Request r;

            r.codeToRequest(rb);

            if (r.requestType == RequestType::LOG_OUT_SUCCESS){

               e->accept();

            }

            else{

                e->ignore();

            }

        }



    }else{

        //若用户点击取消，则忽略这个事件，当前窗口不会关闭
        e->ignore();


    }

}

QByteArray LoginWindow::RB="2333";
