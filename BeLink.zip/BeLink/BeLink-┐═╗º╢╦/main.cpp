#include <QtWidgets>
#include "MyWidget.h"
#include <QApplication>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QStringList>
#include <QTableWidget>
#include <QLabel>
#include "AvatarChangeDialog.h"
#include "ClickableLabel.h"
#include <QtSql>
#include <QSqlDatabase>
#include <QSqlQuery>
#include "MainWindow.h"
#include "LoginWindow.h"
#include "InputWidget.h"
//#include <QHostAddress>
#include "Request.h"
#include <QTcpSocket>
#include "mainwindow.h"
#include "dengluwindow.h"

GlobalData* GlobalData::globaldata = NULL;

int main(int argc, char **argv)
{
    QApplication app(argc, argv);
    GlobalData* globaldata = GlobalData::getInstance();
    globaldata->socket = new QTcpSocket ();
    globaldata->socket->connectToHost("172.26.196.15",12345);//服务器的IP地址和端口号192.168.43.100
    // 创建主窗口
    dengluWindow mainWin;
    QDesktopWidget* desktop = QApplication::desktop();
    mainWin.move((desktop->width() - mainWin.width()) / 2, (desktop->height() - mainWin.height())/ 2);
    mainWin.show();
//    LoginWindow mainWin;
//    QString id,pwd,text2;
//    id ="1111";
//    pwd = "aadada";

//    Request re,re2;
//    re.requestType = RequestType::LOGIN_REQUEST;
//    re.msgNum = 2;
//    re.msgList.append(id);
//    re.msgList.append(pwd);

//    QByteArray qb = re.requestToCode();

//    re2.codeToRequest(qb);
//    text2=qb;
//    qDebug() << text2;
//    qDebug() <<re2.msgNum ;
//    qDebug() <<re2.msgList[0] ;
    return app.exec();

}
//void connection()
//{
//    QTcpSocket *m;
//    m=new QTcpSocket();
//    m->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
//    connect(m, &QTcpSocket::connected, [m]()
//    {
//            m->write("请求数据"); // 发送请求
//            m->waitForBytesWritten(); // 等待写入完成
//            // 可以继续进行后续操作，如读取服务器响应等
//            m->close(); // 关闭连接
//            m->deleteLater(); // 释放内存
//        });
//}
