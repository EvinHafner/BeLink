#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include <QApplication>
#include <QWidget>
#include <QPushButton>
#include <QVBoxLayout>
#include <QTreeWidget>
#include "MyWidget.h"
#include "AvatarChangeDialog.h"
#include "ClickableLabel.h"
#include "GroupWindow.h"
#include "InputWidget.h"
#include "ChangeNickname.h"
#include "addGroup.h"
#include "Request.h"
#include <QTcpSocket>
#include <GlobalData.h>
#include "joinGroup.h"
#include <QCloseEvent>


class LoginWindow : public QWidget {
public:
    MyWidget * widget;
    LoginWindow(QWidget* parent = nullptr) ;
    void closeEvent (QCloseEvent *);
    static QString uid;
private:
    QWidget* createInfoWidget(QWidget* parent, MyWidget* widget);

    QTreeWidget* createTreeWidget(QWidget* parent, MyWidget* widget);

    QTreeWidget* createGroupChat(QWidget* parent, MyWidget* widget);

    ClickableLabel* createAvatarLabel(QWidget* parent, MyWidget* widget,QString loc);

    void openInputWidget();

    void rebuildUI(QWidget* window, MyWidget* widget);

    void openChangeNick();

    void sendRequest(QByteArray a);

    void openaddGroup();

    void openjoinGroup();

    void receive();

    void openChangepwd();
    void opensetGroup();

    static QByteArray RB;

    QTcpSocket *m;
};




#endif // LOGINWINDOW_H
