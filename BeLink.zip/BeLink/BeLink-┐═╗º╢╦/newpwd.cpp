#include "newpwd.h"
#include "ui_newpwd.h"
#include <QValidator>
#include <QMessageBox>
#include <QTcpSocket>
#include <QString>
#include <QHostAddress>
#include "Request.h"
#include "dengluwindow.h"
#include "LoginWindow.h"

newpwd::newpwd(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::newpwd)
{
    ui->setupUi(this);
    //密码格式（由数字和26个英文字母组成的字符串）
    QRegExp regx("^[A-Za-z0-9]+$");
    QValidator *validatorName = new QRegExpValidator(regx);
    ui->lineEdit_2->setValidator(validatorName);
    ui->lineEdit->setValidator(validatorName);
    //设置一键清空
    ui->lineEdit_2->setClearButtonEnabled(true);
    ui->lineEdit->setClearButtonEnabled(true);
}

newpwd::~newpwd()
{
    delete ui;
}

void newpwd::on_pushButton_clicked()
{
//    GlobalData * globaldata= GlobalData::getInstance();
    QString newpwd=ui->lineEdit->text();
    QString surenewpwd=ui->lineEdit_2->text();
    if(newpwd==NULL)
    {
        QMessageBox::warning(this,"修改密码","内容不能为空");
    }
    else
    {
        if(newpwd!=surenewpwd)
        {
            QMessageBox::warning(this,"修改密码","两次密码不一致");
        }
        else
        {
            //尝试连接服务器


//            globaldata->socket->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
//            connect(globaldata->socket, SIGNAL(connected()), this, SLOT(sendRequest()));
            GlobalData * globaldata= GlobalData::getInstance();
            QString newpwd=ui->lineEdit->text();
            //NEW_PASSWORD_REQUEST = 30,//(忘记密码时，密保问题通过后用)，给出用户id和新密码，返回成功
            //00300002____UseriD____NewPwd
            //返回指令是1035
            Request re;
            re.msgNum=2;
            re.requestType=RequestType::NEW_PASSWORD_REQUEST;
            re.msgList.append(globaldata->uid);
            re.msgList.append(newpwd);

            QString stext=re.requestToCode();
            globaldata->socket->write(stext.toUtf8());
            //受服务器信号
            qDebug() << " 1111  ";
            qDebug()<<stext;
            QString read;
            QByteArray byteArray;
            if(globaldata->socket->waitForReadyRead())
            {
                //NEW_PASSWORD_REPLY = 1035,//(忘记密码时，密保问题通过后用)，给出用户id和新密码，返回成功
                //1035
                //请求指令是0030
                qDebug() << " jin ";
                //GlobalData * globaldata= GlobalData::getInstance();
                byteArray = globaldata->socket->readAll();
                read=byteArray;


            }
            qDebug()<<read;
            Request re2;
            re2.codeToRequest(byteArray);
            qDebug() << " 222222 ";

            if(re2.requestType==RequestType::NEW_PASSWORD_REPLY)
            {
                QMessageBox::information(this,"修改密码","密码修改成功");
                this->close();
                dengluWindow *main=new dengluWindow;//回到登录界面
                main->show();
            }
            else
            {
                QMessageBox::warning(this,"修改密码","密码修改失败");
            }




        }
    }
}
//void newpwd::sendRequest()
//{
//    GlobalData * globaldata= GlobalData::getInstance();
//    QString newpwd=ui->lineEdit->text();
//    //NEW_PASSWORD_REQUEST = 30,//(忘记密码时，密保问题通过后用)，给出用户id和新密码，返回成功
//    //00300002____UseriD____NewPwd
//    //返回指令是1035
//    Request re;
//    re.msgNum=2;
//    re.requestType=RequestType::NEW_PASSWORD_REQUEST;
//    re.msgList.append(globaldata->uid);
//    re.msgList.append(newpwd);

//    QString stext=re.requestToCode();
//    globaldata->socket->write(stext.toUtf8());
//    //受服务器信号
//    connect(globaldata->socket,SIGNAL(readyRead()),this,SLOT(recivmessage()));
//}
//void newpwd::recivmessage()
//{
//    //NEW_PASSWORD_REPLY = 1035,//(忘记密码时，密保问题通过后用)，给出用户id和新密码，返回成功
//    //1035
//    //请求指令是0030
//    GlobalData * globaldata= GlobalData::getInstance();
//    QByteArray byteArray = globaldata->socket->readAll();
//    Request re;
//    re.codeToRequest(byteArray);
//    if(re.requestType==RequestType::NEW_PASSWORD_REPLY)
//    {
//        QMessageBox::information(this,"修改密码","密码修改成功");
//        this->close();
//        dengluWindow *main=new dengluWindow;//回到登录界面
//        main->show();
//    }
//    else
//    {
//        QMessageBox::warning(this,"修改密码","密码修改失败");
//    }

//}
