#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QDebug>
#include "setGroup.h"
#include "Request.h"
#include "guodu.h"
#include "LoginWindow.h"
    setGroup::setGroup(QWidget* parent) : QWidget(parent) {
        setWindowTitle("创建群聊");

        lineEdit = new QLineEdit(this);
        lineEdit->setPlaceholderText("请给群聊起个名字");

        submitButton = new QPushButton("创建", this);

        QVBoxLayout* layout = new QVBoxLayout(this);
        layout->addWidget(lineEdit);
        layout->addWidget(submitButton);


        QObject::connect(submitButton, &QPushButton::clicked, this, &setGroup::handleSubmit);

        setLayout(layout);
    }



void setGroup::handleSubmit()
{
     GlobalData* globaldata = GlobalData::getInstance();
    //传inputText到服务器
    //连接服务器
    QString inputText = lineEdit->text();
       Request re;
       re.msgNum=2;
       re.requestType=RequestType::CREATE_GROUP_CHAT_REQUEST;
       re.msgList.append(globaldata->uid);
       re.msgList.append(inputText);
       QString stext = re.requestToCode();
       globaldata->socket->write(stext.toUtf8());
       if(globaldata->socket->waitForReadyRead()){
           QByteArray byteArray = globaldata->socket->readAll();
           QString rmessage=byteArray;
           //处理编码为请求
           Request re2;
           re2.codeToRequest(byteArray);

           if(re2.requestType==RequestType::CREATE_GROUP_CHAT_REPLY)
           {
               QMessageBox::information(this,"创建群聊","创建群聊成功");
           }
                    /*
                         if(re2.requestType==RequestType::CREATE_GROUP_FAIL)
                         {
                             QMessageBox::information(this,"创建群聊失败捏","原神，启动！");
                         }
                         */

                     }

               }
