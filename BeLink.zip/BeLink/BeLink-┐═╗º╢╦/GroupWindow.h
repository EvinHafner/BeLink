#ifndef GROUPWINDPW_H
#define GROUPWINDPW_H
#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QTcpSocket>
class GroupWindow : public QWidget {
public:
    GroupWindow(QString group,QWidget* parent = nullptr);

signals:
    void submitText(const QString& text);

private slots:
    void submitClicked(QString group) ;

    QString Mark(QString m);//字符串长度的格式转换

    void sendRequest(QString group);//发送信号

    void recivmessage();//接受信号
private:
    QLineEdit* lineEdit;
    QPushButton* submitButton;
    QTcpSocket *m;
};


#endif // GROUPWINDPW_H
