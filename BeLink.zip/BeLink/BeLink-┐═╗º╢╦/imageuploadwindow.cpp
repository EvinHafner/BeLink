#include "imageuploadwindow.h"
#include <QFileDialog>

ImageUploadWindow::ImageUploadWindow(QWidget *parent)
    : QDialog(parent)
{
    imagePathInput = new QLineEdit(this);
    selectButton = new QPushButton("select image", this);

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(imagePathInput);
    layout->addWidget(selectButton);

    setLayout(layout);

    connect(selectButton, &QPushButton::clicked, this, &ImageUploadWindow::selectImage);
}

void ImageUploadWindow::selectImage()
{
    QString imagePath = QFileDialog::getOpenFileName(this, "选择图片", QString(), "图片 (*.png *.jpg *.jpeg *.gif *.bmp)");
    if (!imagePath.isEmpty())
    {
        imagePathInput->setText(imagePath);
        emit imageSelected(imagePath);
        accept();
    }
}

