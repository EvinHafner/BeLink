#include <QWidget>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>
#include <QDebug>
#include "addGroup.h"
#include "Request.h"
#include "guodu.h"
#include "LoginWindow.h"
    addGroup::addGroup(QWidget* parent) : QWidget(parent) {
        setWindowTitle("新建分组");

        lineEdit = new QLineEdit(this);
        lineEdit->setPlaceholderText("请输入分组名称");

        submitButton = new QPushButton("添加", this);

        QVBoxLayout* layout = new QVBoxLayout(this);
        layout->addWidget(lineEdit);
        layout->addWidget(submitButton);


        QObject::connect(submitButton, &QPushButton::clicked, this, &addGroup::handleSubmit);

        setLayout(layout);
    }


    void addGroup::handleSubmit()
    {
         GlobalData* globaldata = GlobalData::getInstance();
        //传inputText到服务器
        //连接服务器
        QString inputText = lineEdit->text();

//        globaldata->socket=new QTcpSocket(this);
//        globaldata->socket->connectToHost("192.168.43.100",12345);//服务器的IP地址和端口号192.168.43.100
//        connect(globaldata->socket, SIGNAL(connected()), this, SLOT(sendRequest()));
        //QString inputText = lineEdit->text();
           Request re;
           re.msgNum=2;
           re.requestType=RequestType::CREATE_GROUP_REQUEST;
           re.msgList.append(globaldata->uid);
           re.msgList.append(inputText);
           QString stext = re.requestToCode();
           globaldata->socket->write(stext.toUtf8());
           if(globaldata->socket->waitForReadyRead()){
               QByteArray byteArray = globaldata->socket->readAll();
               QString rmessage=byteArray;
               //处理编码为请求
               Request re2;
               re2.codeToRequest(byteArray);
               //CREATE_GROUP_SUCCESS = 1010,//创建好友分组成功
               //1010
               //请求指令是0007
               if(re2.requestType==RequestType::CREATE_GROUP_SUCCESS)
               {
                   QMessageBox::information(this,"创建分组","创建分组成功");
               }
                             //CREATE_GROUP_FAIL = 1011,//创建好友分组失败 只可能是因为与现有组组名重复
                             //1011
                             //请求指令是0007
                             if(re2.requestType==RequestType::CREATE_GROUP_FAIL)
                             {
                                 QMessageBox::information(this,"创建分组失败","与已有组名重复");
                             }

                         }

                   }
