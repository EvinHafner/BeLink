//Use to create a change avatar's dialog
#ifndef AVATARCHANGEDIALOG_H
#define AVATARCHANGEDIALOG_H

#include <QDialog>
#include <QLabel>
#include <QTcpSocket>

class AvatarChangeDialog : public QDialog
{
    Q_OBJECT

public:
    AvatarChangeDialog(QWidget *parent = nullptr);
    QStringList getImagePathList();
    void changeAvatar(const QString &path);
    QStringList pathList;
private slots:
    //QString Mark(QString m);//字符串长度的格式转换

    //void sendRequest(QString &path);//发送信号

    //void recivmessage();//接受信号


private:
    QLabel *avatarLabel;
    QList<QPushButton*> buttonList;
    QTcpSocket *m;

};

#endif // AVATARCHANGEDIALOG_H

