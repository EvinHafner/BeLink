#include "guodu.h"
#include "ui_guodu.h"

guodu::guodu(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::guodu)
{
    ui->setupUi(this);
}

guodu::~guodu()
{
    delete ui;
}
