#ifndef FORGETPWD_H
#define FORGETPWD_H

#include <QWidget>
#include <QTcpSocket>

namespace Ui {
class forgetpwd;
}

class forgetpwd : public QWidget
{
    Q_OBJECT

public:
    explicit forgetpwd(QWidget *parent = nullptr);
    ~forgetpwd();


private slots:
    void on_pushButton_clicked();



private:
    Ui::forgetpwd *ui;
    QTcpSocket *m;
};
class GlobalData2
{
public:
    //全局变量要加上static关键字

    static QString question;
    static QString solution;

};

#endif // FORGETPWD_H
