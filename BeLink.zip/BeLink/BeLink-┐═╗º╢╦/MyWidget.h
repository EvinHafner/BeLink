//Functions when clicked and etc...

#ifndef MYWIDGET_H
#define MYWIDGET_H

#include "chatwindow.h"
#include "AvatarChangeDialog.h"
#include "GlobalData.h"
#include "UserInfo.h"
#include <QtWidgets>
#include <QTreeWidgetItem>
#include <QSqlDatabase>
#include <QSqlError>
#include <QDebug>

class MyWidget:public QWidget{
    Q_OBJECT
public:

public slots:

    void itemClicked(QTreeWidgetItem* item);

    void chatClicked(QTreeWidgetItem* item);

    void connectToDatabase();

    void avatarClicked();

    void mousePressEvent(QMouseEvent *event);


};



#endif // MYWIDGET_H
