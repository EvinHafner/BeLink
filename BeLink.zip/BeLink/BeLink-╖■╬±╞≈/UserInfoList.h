#ifndef USERINFOLIST_H
#define USERINFOLIST_H
#include "UserInfo.h"
//用户信息链表的节点
class UserInfoNode {
public:
    UserInfoNode(UserInfo data) : data(data), next(nullptr) {}
    UserInfo data;
    UserInfoNode* next;
};
//用户信息链表
class UserInfoList {
public:
    UserInfoList() : head(nullptr), tail(nullptr) {}
    ~UserInfoList() {
        clear();
    }
    //添加节点
    void append(const UserInfo& userInfo) {
        UserInfoNode* newNode = new UserInfoNode(userInfo);
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }
    UserInfoNode* getHead() const {
            return head;
    }

    // 添加其他需要的函数，如删除节点、遍历等
    void printList() const {
        UserInfoNode* current = head;
        while (current) {
            std::cout << "ID:" << current->data.getID()
                      << " Name:" << current->data.getName().toStdString()
                      << " Password:" << current->data.getPwd().toStdString()
                      << " Avatar URL:" << current->data.getAvatarUrl().toStdString()
                      << " IP :" << current->data.getIp().toStdString()
                      << std::endl;
            current = current->next;
        }
    }
    int getMaxId() const{
        int max_id = 0;
        UserInfoNode* current = head;
        while (current) {
            int temp_id = current->data.getID();
            max_id = std::max(max_id,temp_id);

            current = current->next;
        }
        return max_id;
    }
private:
    UserInfoNode* head;
    UserInfoNode* tail;
    //清除链表
    void clear() {
        UserInfoNode* current = head;
        while (current) {
            UserInfoNode* next = current->next;
            //delete current;
            current = next;
        }
        head = tail = nullptr;
    }
};


#endif // USERINFOLIST_H
