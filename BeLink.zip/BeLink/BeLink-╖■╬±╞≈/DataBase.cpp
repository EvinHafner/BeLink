#include "DataBase.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QVariant>
#include <QtDebug>
#include <QStandardPaths>

DataBase* DataBase::db = NULL;
DataBase::DataBase() {
    // 构造函数的初始化代码（如果有的话）
    QString databasePath = QStandardPaths::writableLocation(QStandardPaths::DocumentsLocation) + "/BeLink.db";
    sqldb = QSqlDatabase::addDatabase("QSQLITE");
    sqldb.setDatabaseName(databasePath);
    if (!sqldb.open()) {
        QMessageBox::warning(NULL, "错误", "打开数据库时出现错误!", QMessageBox::Yes);
        printf("打开数据库失败！");

    }else{

        printf("成功打开数据库！\n");
    }
    QSqlQuery query;
    //建表操
    //用户信息表
    if (!sqldb.tables().contains("UserInfo")){

        if(!query.exec("CREATE TABLE UserInfo("
                   "Id INT PRIMARY KEY,"
                   "Nickname VARCHAR(20) NOT NULL,"
                   "Password VARCHAR(16) NOT NULL, "
                   "Avatar VARCHAR(512) NOT NULL,"
                   "Ip VARCHAR(20))")){
            printf("用户信息表未成功建立！");
        }else{
            printf("用户信息表建立成功！\n");
        }

    }else{
        printf("用户信息表已存在\n");
    }
    //用户密保问题
    if (!sqldb.tables().contains("UserSecurityQuestionInfo")){
        if(!query.exec("CREATE TABLE UserSecurityQuestionInfo("
               "UserId INT,"
               "Question VARCHAR(50) NOT NULL,"
               "Answer VARCHAR(50)NOT NULL,"
               "FOREIGN KEY (UserId) REFERENCES UserInfo(Id))")){
            printf("用户密保信息表未建立");
        }
    }else{
        printf("用户密保问题表已存在\n");
    }
    //用户好友分组
    if (!sqldb.tables().contains("FriendGroup")){
        if(!query.exec("CREATE TABLE FriendGroup("
                   "UserId INT,"
                   " GroupName VARCHAR(10) NOT NULL,"
                   " FriendNum INT NOT NULL,"
                   " OnlineFriendNum VARCHAR INT,"
                   " FOREIGN KEY (UserId) REFERENCES UserInfo(Id),"
                       "PRIMARY KEY (UserId, GroupName) )")){
            printf("用户好友分组表未成功建立");
        }
    }else{
        printf("用户好友分组表已存在\n");
    }
    //用户好友关系
    if (!sqldb.tables().contains("FriendShip")){
        if(!query.exec("CREATE TABLE FriendShip(UserId INT,"
                       "FriendId INT,"
                       "FriendGroup VARCHAR(10),"
                       "ExistMessage BOOL NOT NULL,"
                       "FOREIGN KEY (UserId) REFERENCES UserInfo(Id),"
                       "FOREIGN KEY (FriendId) REFERENCES UserInfo(Id),"
                       "FOREIGN KEY (FriendGroup) REFERENCES FriendGroup(GroupName))")){
            printf("用户好友关系表未成功建立");
        }
    }else{
        printf("用户好友关系表已存在\n");
    }
    //好友聊天窗口表
    if (!sqldb.tables().contains("FriendChatWindow")){
        if(!query.exec("CREATE TABLE FriendChatWindow("
                       "UserId INT,"
                       "FriendId INT, "
                       "IsOpen BOOL NOT NULL, "
                       "FOREIGN KEY (UserId) REFERENCES UserInfo(Id))")){
            printf("好友聊天窗口表未成功建立");
        }
    }else{
        printf("好友聊天窗口表已存在\n");
    }

    //用户在线状态
    if (!sqldb.tables().contains("UserOnline")){
        if(!query.exec("CREATE TABLE UserOnline(UserId INT,"
                   " IsOnline BOOL NOT NULL,"
                   " FOREIGN KEY (UserId) REFERENCES UserInfo(Id))")){

            printf("用户在线状态表未成功建立");
        }
    }else{
        printf("用户在线状态表已存在\n");
    }
    //在线消息总表
    if (!sqldb.tables().contains("OnlineMsgId")){
        if(!query.exec("CREATE TABLE OnlineMsgId("
                       "SenderId INT,"
                       "ReceiverId INT,"
                       "MsgId INT NOT NULL,"
                       "MsgType INT NOT NULL,"
                       "MsgTime VARCHAR(50) NOT NULL,"
                       "FOREIGN KEY (SenderId) REFERENCES UserInfo(Id));")){

            printf("在线消息总表未成功建立");
        }
    }else{
        printf("在线消息总表已存在\n");
    }
    //在线文字消息表
    if (!sqldb.tables().contains("OnlineTextMsg")){
        if(!query.exec("CREATE TABLE OnlineTextMsg("
                       "Id INT,"
                       "TextContent VARCHAR(512),"
                       "FOREIGN KEY (Id) REFERENCES OnlineMsgId(MsgId))")){

            printf("在线文字消息表未成功建立");
        }
    }else{
        printf("在线文字消息表已存在\n");
    }
    //在线图片消息表
    if (!sqldb.tables().contains("OnlineAvatarMsg")){
        if(!query.exec("CREATE TABLE OnlineAvatarMsg("
                       "Id INT,"
                       "AvatarUrl VARCHAR(512),"
                       "FOREIGN KEY (Id) REFERENCES OnlineMsgId(MsgId))")){

            printf("在线图片消息表未成功建立");
        }
    }else{
        printf("在线图片消息表已存在\n");
    }
    //在线文件消息表
    if (!sqldb.tables().contains("OnlineFileMsg")){
        if(!query.exec("CREATE TABLE OnlineFileMsg("
                       "Id INT,"
                       "FileName VARCHAR(512),"
                       "FOREIGN KEY (Id) REFERENCES OnlineMsgId(MsgId))")){
            printf("在线文件消息表未成功建立");
        }
    }else{
        printf("在线文件消息表已存在\n");
    }
    //群聊信息表
    if (!sqldb.tables().contains("GroupChatInfo")){
        if(!query.exec("CREATE TABLE GroupChatInfo("
                       "Id INT PRIMARY KEY,"
                       "GroupAvatar VARCHAR(100) NOT NULL,"
                       "GroupName VARCHAR(50) NOT NULL,"
                       "GroupPeopleNum INT NOT NULL)")){
            printf("群聊信息表未成功建立");
        }
    }else{
        printf("群聊信息表已存在\n");
    }
    //群聊人员表
    if (!sqldb.tables().contains("GroupMember")){
        if(!query.exec("CREATE TABLE GroupMember("
                       "GroupId INT,"
                       "UserId INT,"
                       "ExistMessage BOOL NOT NULL,"
                       "FOREIGN KEY (GroupId) REFERENCES GroupChatInfo(Id),"
                       "FOREIGN KEY (UserId) REFERENCES UserInfo(Id),"
                       "PRIMARY KEY (GroupId, UserId))")){
            printf("群聊人员表未成功建立");
        }
    }else{
        printf("群聊人员表已存在\n");
    }
    //消息匿名表
    if (!sqldb.tables().contains("MsgIsNIMING")){
        if(!query.exec("CREATE TABLE MsgIsNIMING("
                       "MsgId INT,"
                       "IsNIMING BOOL NOT NULL,"
                       "FOREIGN KEY (MsgId) REFERENCES OnlineMsgId(MsgId))")){
            printf("消息匿名表未成功建立");
        }
    }else{
        printf("消息匿名表已存在\n");
    }

    //图片传输表
    if (!sqldb.tables().contains("AvatarTrans")){
        if(!query.exec("CREATE TABLE AvatarTrans("
                       "MsgId INT,"
                       "AvatarCode VARCHAR,"
                       "AvatarSize INT,"
                       "FOREIGN KEY (MsgId) REFERENCES OnlineMsgId(MsgId))")){
            printf("消息匿名表未成功建立");
        }
    }else{
        printf("消息匿名表已存在\n");
    }


    /*if(!query.exec("DROP TABLE FriendChatWindow;")){
            printf("删表失败");
    }
    if(!query.exec("DROP TABLE OnlineMsgId;")){
        printf("删表失败");
    }
    if(!query.exec("DROP TABLE OnlineTextMsg;")){
        printf("删表失败");
    }
    if(!query.exec("DROP TABLE GroupChatInfo;")){
        printf("删表失败");
    }
    if(!query.exec("DROP TABLE GroupMember;")){
        printf("删表失败");
    }*/
    /*
    query.exec("CREATE TABLE ");
    query.exec("CREATE TABLE ");
    query.exec("CREATE TABLE ");
    query.exec("CREATE TABLE ");
    query.exec("CREATE TABLE ");
    query.exec("CREATE TABLE ");*/

    //插入查询操作 测试用
    //insertUserInfo(10001,"star","1459923393","avatar2.jpg","192.168.43.101");

}
DataBase::~DataBase() {
    sqldb.close();
    if(db != NULL){
        delete db;
    }
}

DataBase* DataBase::getInstance() {

    if (db == NULL){
        db = new DataBase;
    }

    return db;
}




//外部函数

int DataBase::addUserToDB(QString nickname,QString password,QString ip,QString question,QString answer){
    //第一步查询最大id，第二步最大id+1，第三步生成头像id，第四步生成默认好友分组，第五步加入个人信息表，
    //第六步加入个人在线表，第七步加入好友分组表
    //DataBase& database = DataBase::getInstance();
    int newId = getMaxId() + 1;


    QString new_avatar_id = "default.jpg";
    QStringList qslist;
    qslist.append("家人");
    qslist.append("朋友");
    qslist.append("同学");

    std::cout <<"最大值是\n"<< std::endl;
    if(!insertUserInfo(newId,nickname,password,new_avatar_id,ip)){
        qDebug()<< "插入用户信息表失败！";
        return 0;
    }
    std::cout << newId << std::endl;
    if(!insertUserOnline(newId,false)){
        qDebug()<< "插入用户在线状态表失败！";
        return 0;
    }
    std::cout << "??" <<std::endl;
    int group_num = qslist.count();
    for(int i = 0 ; i < group_num ; i++){
        if(!insertFriendGroup(newId,qslist.at(i),0,0)){
            qDebug()<< "插入好友分组表失败！";
        }
        std::cout << "!!!!" <<std::endl;
    }
    std::cout << "新用户添加成功！\n" << std::endl;
    insertUserSecurityQuesInfo(newId,question,answer);
    return newId;
}

bool DataBase::checkUserExistById(int userId){
    //直接查
    QSqlQuery query;
    query.prepare("SELECT * FROM UserInfo WHERE Id = :Id");
    query.bindValue(":Id",userId);

    if (query.exec()) {
        if (query.next()) {
            // User with ID 5 exists
            return true;
        } else {
            // User with ID 5 doesn't exist
            return false;
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }
}

bool DataBase::checkUserLegalByIdAndPassword(int userId,QString userPwd){
    //直接查
    QSqlQuery query;
    query.prepare("SELECT * FROM UserInfo WHERE Id = :Id and Password = :Password");
    query.bindValue(":Id",userId);
    query.bindValue(":Password",userPwd);

    if (query.exec()) {
        if (query.next()) {
            // User with ID 5 exists
            return true;
        } else {
            // User with ID 5 doesn't exist
            return false;
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }
}
bool DataBase::changeUserOfflineToOnline(int userId){
    QSqlQuery query;
    QString updateQuery = "UPDATE UserOnline SET IsOnline = :IsOnline WHERE UserId = :userId";
    query.prepare(updateQuery);
    query.bindValue(":IsOnline", true);
    query.bindValue(":userId", userId);
    if (!query.exec()) {
        qDebug() << "Error updating online status: " << query.lastError();
        return false;
    }
    return true;
}

UserInfo DataBase::getUserInfoById(int userId){

    QSqlQuery query;

    if (!query.exec(QString("SELECT Nickname, Password, Avatar, Ip FROM UserInfo WHERE Id = %1").arg(userId))) {
        qDebug() << "Error executing query: " << query.lastError();
        return UserInfo();
    }

    if (query.next()) {
        QString name = query.value(0).toString();
        QString password = query.value(1).toString();
        QString avatar = query.value(2).toString();
        QString ip = query.value(3).toString();

        return UserInfo(userId, name, password, avatar, ip);
     } else {
        qDebug() << "User with ID" << userId << "not found";
        return UserInfo(); // Return an empty UserInfo instance or handle the not found case
     }

}
QStringList DataBase::getFriendGroupNamesById(int id){

    QStringList friendGroups;

    QSqlQuery query;
    query.prepare("SELECT GroupName FROM FriendGroup WHERE UserId = :userId");
    query.bindValue(":userId", id);

    if (query.exec()) {
        while (query.next()) {
            QString groupName = query.value(0).toString();
            friendGroups.append(groupName);
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }

    return friendGroups;
}

bool DataBase::createFriendGroup(int userId, QString newGroupName) {
    // Check if the new group name already exists for the user
    QStringList existingGroups = getFriendGroupNamesById(userId);
    if (existingGroups.contains(newGroupName)) {
        qDebug() << "Group name already exists.";
        return false;
    }

    // If not, create the new friend group
    QSqlQuery query;
    query.prepare("INSERT INTO FriendGroup (UserId, GroupName, FriendNum, OnlineFriendNum) "
                  "VALUES (:userId, :groupName, 0, 0)");
    query.bindValue(":userId", userId);
    query.bindValue(":groupName", newGroupName);

    if (query.exec()) {
        qDebug() << "Friend group created successfully.";
        return true;
    } else {
        qDebug() << "Error creating friend group: " << query.lastError();
        return false;
    }
}
UserInfoList DataBase::getFriendInfoListByUserIDandFriendGroupName(int userId,QString friendGroupName){
    UserInfoList result;  // 创建一个 UserInfoList 类型的链表，用于存储好友信息

        QSqlQuery query;
        QString queryString = "SELECT FriendId FROM FriendShip WHERE UserId = :userId AND FriendGroup = :friendGroupName";
        query.prepare(queryString);
        query.bindValue(":userId", userId);
        query.bindValue(":friendGroupName", friendGroupName);

        if (query.exec()) {
            while (query.next()) {
                int friendId = query.value("FriendId").toInt();

                // 在这里根据好友的ID从数据库中获取对应的用户信息
                // 假设你有一个函数叫做 getUserInfoById，用于根据ID获取用户信息
                UserInfo friendInfo = getUserInfoById(friendId);

                // 将获取到的好友信息添加到 result 链表中
                result.append(friendInfo);
            }
        } else {
            // 处理查询失败的情况
        }

        return result;  // 返回存储好友信息的链表
}

bool DataBase::checkIsOnlineById(int userId) {
    QSqlQuery query;
    query.prepare("SELECT IsOnline FROM UserOnline WHERE UserId = :userId");
    query.bindValue(":userId", userId);

    if (query.exec() && query.next()) {
        bool isOnline = query.value("IsOnline").toBool();
        return isOnline;
    } else {
        qDebug() << "查询用户在线状态失败";
        // 返回默认的不在线状态，或者抛出异常等
        return false;
    }
}
bool DataBase::checkExistMessageById(int userId, int friendId) {
    QSqlQuery query;
    query.prepare("SELECT ExistMessage FROM FriendShip WHERE UserId = :userId AND FriendId = :friendId");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    if (query.exec() && query.next()) {
        bool hasUnreadMessage = query.value("ExistMessage").toBool();
        return hasUnreadMessage;
    } else {
        qDebug() << "Error while querying for ExistMessage:";
        qDebug() << query.lastError().text();

        // 返回默认的未读消息状态（false）或者进行其他错误处理
        return false;
    }
}
bool DataBase::checkFriendship(int userId, int friendId) {
    QSqlQuery query;
    query.prepare("SELECT * FROM FriendShip WHERE (UserId = :userId AND FriendId = :friendId) OR (UserId = :friendId AND FriendId = :userId)");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);
    if (!query.exec()){
        qDebug() << "Error while querying for ExistMessage:";
        qDebug() << query.lastError().text();
    }
    if (query.next()) {
        // 如果查询结果不为空，则表示这两个用户是好友
        return true;
    } else {
        // 查询结果为空，表示这两个用户不是好友
        return false;
    }
}







bool DataBase::addFriendship(int userId, int friendId) {
    QSqlDatabase database = QSqlDatabase::database();  // 获取已经建立的数据库连接
    if(checkFriendship(userId,friendId)){
        return false;
    }
    // 开启事务以确保所有操作的一致性
    database.transaction();

    QSqlQuery query;

    // 添加第一行，双方都以 userId 为主动添加方
    query.prepare("INSERT INTO FriendShip (UserId, FriendId, FriendGroup, ExistMessage) VALUES (:userId, :friendId, :group, :existMessage)");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);
    query.bindValue(":group", "朋友");  // 默认分组为 "朋友"
    query.bindValue(":existMessage", false);

    if (!query.exec()) {
        qDebug() << "Error while adding friendship (user as initiator):";
        qDebug() << query.lastError().text();
        database.rollback();  // 回滚事务
        return false;
    }

    // 添加第二行，双方都以 friendId 为主动添加方
    query.prepare("INSERT INTO FriendShip (UserId, FriendId, FriendGroup, ExistMessage) VALUES (:userId, :friendId, :group, :existMessage)");
    query.bindValue(":userId", friendId);
    query.bindValue(":friendId", userId);
    query.bindValue(":group", "朋友");  // 默认分组为 "朋友"
    query.bindValue(":existMessage", false);

    if (!query.exec()) {
        qDebug() << "Error while adding friendship (friend as initiator):";
        qDebug() << query.lastError().text();
        database.rollback();  // 回滚事务
        return false;
    }
    // 添加好友窗口表的两行记录
        query.prepare("INSERT INTO FriendChatWindow (UserId, FriendId, IsOpen) VALUES (:userId, :friendId, :isOpen)");
        query.bindValue(":userId", userId);
        query.bindValue(":friendId", friendId);
        query.bindValue(":isOpen", false);  // 默认设置为未打开

        if (!query.exec()) {
            qDebug() << "Error while adding friend chat window (user as initiator):";
            qDebug() << query.lastError().text();
            database.rollback();  // 回滚事务
            return false;
        }

        query.bindValue(":userId", friendId);
        query.bindValue(":friendId", userId);
        query.bindValue(":isOpen", false);  // 默认设置为未打开

        if (!query.exec()) {
            qDebug() << "Error while adding friend chat window (friend as initiator):";
            qDebug() << query.lastError().text();
            database.rollback();  // 回滚事务
            return false;
        }

    // 在 FriendGroup 表中更新分组好友数
    if (!updateFriendGroupFriendNum(userId, "朋友", 1) || !updateFriendGroupFriendNum(friendId, "朋友", 1)) {
        qDebug() << "Error while updating FriendGroup FriendNum:";
        database.rollback();  // 回滚事务
        return false;
    }

    // 提交事务
    if (!database.commit()) {
        qDebug() << "Error while committing transaction:";
        qDebug() << database.lastError().text();
        return false;
    }

    return true;  // 操作成功
}

bool DataBase::deleteFriendship(int userId, int friendId) {
    QSqlDatabase database = QSqlDatabase::database();  // 获取已经建立的数据库连接

    // 开启事务以确保所有操作的一致性
    database.transaction();

    QSqlQuery query;



    // 查询双方的分组情况
    QString userGroup = getFriendGroup(userId, friendId);
    QString friendGroup = getFriendGroup(friendId, userId);



    // 删除好友关系
    query.prepare("DELETE FROM FriendShip WHERE (UserId = :userId AND FriendId = :friendId)");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    if (!query.exec()) {
        qDebug() << "Error while deleting friendship (user as initiator):";
        qDebug() << query.lastError().text();
        database.rollback();  // 回滚事务
        return false;
    }

    query.prepare("DELETE FROM FriendShip WHERE (UserId = :userId AND FriendId = :friendId)");
    query.bindValue(":userId", friendId);
    query.bindValue(":friendId", userId);

    if (!query.exec()) {
        qDebug() << "Error while deleting friendship (friend as initiator):";
        qDebug() << query.lastError().text();
        database.rollback();  // 回滚事务
        return false;
    }

    // 在 FriendGroup 表中更新分组好友数
    if (!updateFriendGroupFriendNum(userId, userGroup, -1) || !updateFriendGroupFriendNum(friendId, friendGroup, -1)) {
        qDebug() << "Error while updating FriendGroup FriendNum:";
        database.rollback();  // 回滚事务
        return false;
    }

    // 提交事务
    if (!database.commit()) {
        qDebug() << "Error while committing transaction:";
        qDebug() << database.lastError().text();
        return false;
    }

    return true;  // 操作成功
}
bool DataBase::changeNicknameByIdAndNewName(int userId,QString newName){
    QSqlQuery query;
    query.prepare("UPDATE UserInfo SET Nickname = :newName WHERE Id = :userId");
    query.bindValue(":newName", newName);
    query.bindValue(":userId", userId);

    return query.exec();  // 返回操作是否成功
}

bool DataBase::changeAvatarByIdAndUrl(int userId, QString url) {
    QSqlQuery query;
    query.prepare("UPDATE UserInfo SET Avatar = :newUrl WHERE Id = :userId");
    query.bindValue(":newUrl", url);
    query.bindValue(":userId", userId);

    return query.exec();  // 返回操作是否成功
}

bool DataBase::changeFriendGroupName(int userId, QString oldName, QString newName) {
    QSqlDatabase database = QSqlDatabase::database();  // 获取已经建立的数据库连接

    // 开启事务以确保所有操作的一致性
    database.transaction();

    QSqlQuery query;

    // 更新 FriendGroup 表中的好友组名
    query.prepare("UPDATE FriendGroup SET GroupName = :newName WHERE UserId = :userId AND GroupName = :oldName");
    query.bindValue(":newName", newName);
    query.bindValue(":userId", userId);
    query.bindValue(":oldName", oldName);

    if (!query.exec()) {
        qDebug() << "Error while updating FriendGroup table:";
        qDebug() << query.lastError().text();
        database.rollback();  // 回滚事务
        return false;
    }

    // 更新 FriendShip 表中的好友组名
    query.prepare("UPDATE FriendShip SET FriendGroup = :newName WHERE UserId = :userId AND FriendGroup = :oldName");
    query.bindValue(":newName", newName);
    query.bindValue(":userId", userId);
    query.bindValue(":oldName", oldName);

    if (!query.exec()) {
        qDebug() << "Error while updating FriendShip table:";
        qDebug() << query.lastError().text();
        database.rollback();  // 回滚事务
        return false;
    }

    // 提交事务
    if (!database.commit()) {
        qDebug() << "Error while committing transaction:";
        qDebug() << database.lastError().text();
        return false;
    }

    return true;  // 操作成功
}



bool DataBase::changeFriendGroup(int userId, int friendId, QString newGroupName) {
    QSqlDatabase database = QSqlDatabase::database();  // 获取已经建立的数据库连接

    // 开启事务以确保所有操作的一致性
    database.transaction();

    QSqlQuery query;
    QString currentGroupName;  // 用于存储原分组名

    // 获取原分组名
    query.prepare("SELECT FriendGroup FROM FriendShip WHERE UserId = :userId AND FriendId = :friendId");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    if (query.exec() && query.next()) {
        currentGroupName = query.value("FriendGroup").toString();
    } else {
        qDebug() << "Error while getting original friend group:";
        qDebug() << query.lastError().text();
        database.rollback();  // 回滚事务
        return false;
    }

    // 更新 FriendShip 表中的好友分组
    query.prepare("UPDATE FriendShip SET FriendGroup = :newGroupName WHERE UserId = :userId AND FriendId = :friendId");
    query.bindValue(":newGroupName", newGroupName);
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    if (!query.exec()) {
        qDebug() << "Error while updating FriendShip table:";
        qDebug() << query.lastError().text();
        database.rollback();  // 回滚事务
        return false;
    }

    // 在 FriendGroup 表中更新分组好友数
        if (!updateFriendGroupFriendNum(userId, currentGroupName, -1)) {
            qDebug() << "Error while updating original FriendGroup FriendNum:";
            database.rollback();  // 回滚事务
            return false;
        }

        if (!updateFriendGroupFriendNum(userId, newGroupName, 1)) {
            qDebug() << "Error while updating new FriendGroup FriendNum:";
            database.rollback();  // 回滚事务
            return false;
        }

    // 提交事务
    if (!database.commit()) {
        qDebug() << "Error while committing transaction:";
        qDebug() << database.lastError().text();
        return false;
    }

    return true;  // 操作成功
}

int DataBase::createGroupChat(int userId,QString groupName){
    //查询最大groupid，调用插入群信息函数完成群信息表创建，然后调用插入群聊人员表函数完成群聊人员表插入。
    int newGroupId = getMaxGroupChatId() + 1;
    QString groupAvatar = "GroupAvatar.jpg";
    insertGroupInfo(newGroupId,groupAvatar,groupName,1);
    insertFriendChatWindow(userId,newGroupId,false);
    return newGroupId;
}

bool DataBase::joinGroupChat(int userId,int groupId){
    if(!updateGroupPeopleNum(groupId,1)){
        return false;
    }
    return insertGroupMember(groupId,userId,false);
}
bool DataBase::quitGroupChat(int userId,int groupId){
    if(!updateGroupPeopleNum(groupId,-1)){
        return false;
    }
    return deleteGroupMember(userId,groupId);
}
bool DataBase::openGroupChatWindow(int userId,int groupId){
    updateFriendChatWindow(userId,groupId,true);
    return updateGroupMemberExistMessage(groupId,userId,false);
}
int DataBase::sendGroupChatMessage(int userId,int groupId,MessageType msgType,QString msgContent,QString msgTime){
    int newMsgId = getMaxMsgId() + 1;
    insertOnlineMsgId(userId,groupId,newMsgId,static_cast<int>(msgType),msgTime);
    if (msgType == MessageType::Text) {
        insertOnlineTextMsg(newMsgId,msgContent);
    } else if (msgType == MessageType::Avatar) {
        insertOnlineAvatarMsg(newMsgId,msgContent);
    } else if (msgType == MessageType::File) {
        insertOnlineFileMsg(newMsgId,msgContent);
    }
    QList<int> userIds = getUsersInGroup(groupId);
    for (int i = 0; i < userIds.size(); ++i){
        int tempId = userIds.at(i);
        if(tempId != userId){
            whenReceiveGroupChatMessage(tempId,groupId);
        }
    }
    return newMsgId;
}
QList<int> DataBase::getUsersInGroup(int groupId) {
    QList<int> userIds;

    QSqlQuery query;
    query.prepare("SELECT UserId FROM GroupMember WHERE GroupId = :groupId;");
    query.bindValue(":groupId", groupId);

    if (query.exec()) {
        while (query.next()) {
            int userId = query.value("UserId").toInt();
            userIds.append(userId);
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }

    return userIds;
}
QList<int> DataBase::getUserJoinedGroups(int userId) {
    QList<int> groupIds;
    QSqlQuery query;

    query.prepare("SELECT Id FROM GroupChatInfo WHERE Id IN "
                  "(SELECT GroupId FROM GroupMember WHERE UserId = :userId);");
    query.bindValue(":userId", userId);

    if (query.exec()) {
        while (query.next()) {
            groupIds.append(query.value("Id").toInt());
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }

    return groupIds;
}
GroupChatInfo DataBase::getGroupInfoById(int groupId) {
    QSqlQuery query;
    query.prepare("SELECT * FROM GroupChatInfo WHERE Id = :groupId");
    query.bindValue(":groupId", groupId);

    if (query.exec() && query.next()) {
        int id = query.value("Id").toInt();
        QString name = query.value("GroupName").toString();
        QString avatarUrl = query.value("GroupAvatar").toString();

        GroupChatInfo groupInfo(id, name, avatarUrl);
        return groupInfo;
    } else {
        qDebug() << "Error getting group info: " << query.lastError();
        return GroupChatInfo(); // Return an empty GroupChatInfo object if not found
    }
}

































//
int DataBase::addFriendMessage(int UserId,int FriendId,MessageType msgType,QString msgContent,QString msgTime){
    int newMsgId = getMaxMsgId() + 1;
    std::cout<<UserId<<std::endl;
    insertOnlineMsgId(UserId,FriendId,newMsgId,static_cast<int>(msgType),msgTime);
    if (msgType == MessageType::Text) {
        insertOnlineTextMsg(newMsgId,msgContent);
    } else if (msgType == MessageType::Avatar) {
        insertOnlineAvatarMsg(newMsgId,msgContent);
    } else if (msgType == MessageType::File) {
        insertOnlineFileMsg(newMsgId,msgContent);
    }
    whenReceiveMessage(FriendId,UserId);
    return newMsgId;
}
Message DataBase::getMessageById(int msgId){
    Message message;

    QSqlQuery query;

    // 查询 OnlineMsgId 表获取消息信息
    query.prepare("SELECT * FROM OnlineMsgId WHERE MsgId = :msgId;");
    query.bindValue(":msgId", msgId);

    if (query.exec() && query.next()) {
        MessageType msgType = static_cast<MessageType>(query.value("MsgType").toInt());
        QString msgTime = query.value("MsgTime").toString();
        int senderId = query.value("SenderId").toInt();

        QString msgContent;

        // 根据消息类型查询不同的消息内容表
        if (msgType == MessageType::Text) {
            // 查询 OnlineTextMsg 表获取文本消息内容
            QSqlQuery textQuery;
            textQuery.prepare("SELECT TextContent FROM OnlineTextMsg WHERE Id = :msgId;");
            textQuery.bindValue(":msgId", msgId);
            if (textQuery.exec() && textQuery.next()) {
                msgContent = textQuery.value("TextContent").toString();
            } else {
                qDebug() << "Error getting TextContent: " << textQuery.lastError();
            }
        } else if (msgType == MessageType::Avatar) {
            // 查询 OnlineAvatarMsg 表获取头像消息内容
            QSqlQuery avatarQuery;
            avatarQuery.prepare("SELECT AvatarUrl FROM OnlineAvatarMsg WHERE Id = :msgId;");
            avatarQuery.bindValue(":msgId", msgId);
            if (avatarQuery.exec() && avatarQuery.next()) {
                msgContent = avatarQuery.value("AvatarUrl").toString();
            } else {
                qDebug() << "Error getting AvatarUrl: " << avatarQuery.lastError();
            }
        } else if (msgType == MessageType::File) {
            // 查询 OnlineFileMsg 表获取文件消息内容
            QSqlQuery fileQuery;
            fileQuery.prepare("SELECT FileName FROM OnlineFileMsg WHERE Id = :msgId;");
            fileQuery.bindValue(":msgId", msgId);
            if (fileQuery.exec() && fileQuery.next()) {
                msgContent = fileQuery.value("FileName").toString();
            } else {
                qDebug() << "Error getting FileName: " << fileQuery.lastError();
            }
        }

        // 构造 Message 对象
        message = Message(msgType, msgId, msgContent, msgTime, senderId);
    } else {
        qDebug() << "Error getting message from OnlineMsgId: " << query.lastError();
    }

    return message;

}
QList<int> DataBase::getMessagesForReceiver(int receiverId) {
    QList<int> messageIds;

    QSqlQuery query;
    query.prepare("SELECT MsgId FROM OnlineMsgId WHERE ReceiverId = :receiverId");
    query.bindValue(":receiverId", receiverId);

    if (query.exec()) {
        while (query.next()) {
            int msgId = query.value("MsgId").toInt();
            messageIds.append(msgId);
        }
    } else {
        qDebug() << "Error getting messages for receiver: " << query.lastError();
    }

    return messageIds;
}







bool DataBase::deleteFriendMessage(int msgId){
    QSqlQuery query;
    Message msg;
    msg = getMessageById(msgId);
    MessageType msgType = msg.getMsgType();

    if (msgType == MessageType::Text) {
        // 在OnlineTextMsg表中删除文本消息
        query.prepare("DELETE FROM OnlineTextMsg WHERE Id = :msgId");
    } else if (msgType == MessageType::Avatar) {
        // 在OnlineAvatarMsg表中删除头像消息
        query.prepare("DELETE FROM OnlineAvatarMsg WHERE Id = :msgId");
    } else if (msgType == MessageType::File) {
        // 在OnlineFileMsg表中删除文件消息
        query.prepare("DELETE FROM OnlineFileMsg WHERE Id = :msgId");
    } else {
        qDebug() << "Invalid message type";
        return false;
    }
    // 执行删除操作
    query.bindValue(":msgId", msgId);
    if (!query.exec()) {
        qDebug() << "Error deleting message: " << query.lastError();
        return false;
    }
    // 在OnlineMsgId表中删除消息记录
    query.prepare("DELETE FROM OnlineMsgId WHERE MsgId = :msgId");
    query.bindValue(":msgId", msgId);
    if (!query.exec()) {
        qDebug() << "Error deleting message from OnlineMsgId: " << query.lastError();
        return false;
    }
    return true;

}










//内部函数
//列出用户信息表
UserInfoList DataBase::getUserInfoList() {
    UserInfoList userInfoList;

    QSqlQuery query;
    if (query.exec("SELECT Id, Nickname, Password, Avatar FROM UserInfo")) {
        while (query.next()) {
            int id = query.value(0).toInt();
            QString nickname = query.value(1).toString();
            QString password = query.value(2).toString();
            QString avatar = query.value(3).toString();

            UserInfo userInfo(id, nickname, password, avatar);
            userInfoList.append(userInfo);
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }

    return userInfoList;
}
//列出在线状态表
void DataBase::printAllUserOnlineStatus() {
    QSqlQuery query;

    if (!query.exec("SELECT UserId, IsOnline FROM UserOnline")) {
        qDebug() << "Error executing query: " << query.lastError();
        return;
    }

    while (query.next()) {
        int userId = query.value(0).toInt();
        bool isOnline = query.value(1).toBool();

        qDebug() << "User ID:" << userId << "Is Online:" << isOnline;
    }
}

//列出群信息表
void DataBase::printAllGroupChatInfo() {
    QSqlQuery query;
    if (query.exec("SELECT * FROM GroupChatInfo;")) {
        while (query.next()) {
            int groupId = query.value("Id").toInt();
            QString groupAvatar = query.value("GroupAvatar").toString();
            QString groupName = query.value("GroupName").toString();
            int groupPeopleNum = query.value("GroupPeopleNum").toInt();

            qDebug() << "Group ID:" << groupId << "Group Name:" << groupName << "Group People Num:" << groupPeopleNum;
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }
}



//获取最大id
int DataBase::getMaxId(){
    UserInfoList userInfoList = getUserInfoList();
    userInfoList.printList();
    return userInfoList.getMaxId();
}
int DataBase::getMaxMsgId(){
    MessageList msgList = getAllMessages();
    msgList.printList();
    return msgList.getMaxMsgId();
}
int DataBase::getMaxGroupChatId() {
    int maxGroupId = 99999;

    QSqlQuery query;
    if (query.exec("SELECT MAX(Id) FROM GroupChatInfo;")) {
        if (query.next()) {
            maxGroupId = query.value(0).toInt();
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }

    return maxGroupId;
}
bool DataBase::isGroupExist(int groupId) {
    QSqlQuery query;
    query.prepare("SELECT Id FROM GroupChatInfo WHERE Id = :groupId;");
    query.bindValue(":groupId", groupId);

    if (query.exec() && query.next()) {
        return true;  // Group exists
    } else {
        return false; // Group doesn't exist
    }
}
bool DataBase::checkExistMessageInGroup(int groupId, int userId) {
    QSqlQuery query;
    query.prepare("SELECT ExistMessage FROM GroupMember WHERE GroupId = :groupId AND UserId = :userId;");
    query.bindValue(":groupId", groupId);
    query.bindValue(":userId", userId);

    if (query.exec() && query.next()) {
        bool existMessage = query.value("ExistMessage").toBool();
        return existMessage;
    } else {
        qDebug() << "Error checking existMessage in GroupMember table: " << query.lastError();
        return false;
    }
}











//数据库基本操作
bool DataBase::insertUserInfo(int id,QString nickname,QString password,QString avatar,QString ip ){

    QSqlQuery query;

    query.prepare("SELECT * FROM UserInfo WHERE Id = :Id");
    query.bindValue(":Id",id);

    if (query.exec()) {
        if (query.next()) {
            // User with ID 5 exists
            qDebug() << "插入用户信息表错误--主键重复！\n";
            return false;
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }

    query.prepare("INSERT INTO UserInfo (Id,Nickname,Password, Avatar, Ip) VALUES "
               "(:Id,:Nickname,:Password,:Avatar,:Ip);");
    query.bindValue(":Id",id);
    query.bindValue(":Nickname",nickname);
    query.bindValue(":Password",password);
    query.bindValue(":Avatar",avatar);
    query.bindValue(":Ip",ip);

    if(!query.exec()){
        qDebug() << "插入用户信息表失败: " << query.lastError();
        return false;
    }
    return true;
}

bool DataBase::insertUserOnline(int id,bool is_online){
    QSqlQuery query;

    query.prepare("SELECT * FROM UserOnline WHERE UserId = :UserId");
    query.bindValue(":UserId",id);

    if (query.exec()) {
        if (query.next()) {
            // User with ID 5 exists
            qDebug() << "插入用户在线状态表错误--主键重复！\n";
            return false;
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }

    query.prepare("INSERT INTO UserOnline (UserId,IsOnline) VALUES "
               "(:UserId,:IsOnline);");
    query.bindValue(":UserId",id);
    query.bindValue(":IsOnline",is_online);
    if(!query.exec()){
        qDebug() << "插入用户在线状态失败: " << query.lastError();
        return false;
    }
    return true;
}

bool DataBase::insertUserSecurityQuesInfo(int id,QString question,QString answer){
    QSqlQuery query;

    query.prepare("SELECT * FROM UserSecurityQuestionInfo WHERE UserId = :UserId");
    query.bindValue(":UserId",id);

    if (query.exec()) {
        if (query.next()) {
            // User with ID 5 exists
            qDebug() << "插入用户密保问题表错误--主键重复！\n";
            return false;
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }

    query.prepare("INSERT INTO UserSecurityQuestionInfo (UserId,Question,Answer) VALUES "
               "(:UserId,:Question,:Answer);");
    query.bindValue(":UserId",id);
    query.bindValue(":Question",question);
    query.bindValue(":Answer",answer);
    
    if(!query.exec()){
        qDebug() << "插入用户密保问题失败: " << query.lastError();
        return false;
    }
    return true;
}
bool DataBase::insertFriendShip(int id,int friend_id,QString group_name,bool exist_message){
    QSqlQuery query;

    query.prepare("SELECT * FROM UserInfo WHERE UserId = :UserId and FriendId = :FriendId");
    query.bindValue(":UserId",id);
    query.bindValue(":FriendId",friend_id);

    if (query.exec()) {
        if (query.next()) {
            // User with ID 5 exists
            qDebug() << "插入好友关系表错误--主键重复！\n";
            return false;
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }

    query.prepare("INSERT INTO FriendShip (UserId,FriendId,FriendGroup,ExistMessage) VALUES "
               "(:UserId,:FriendId,:GroupName,:ExistMessage);");
    query.bindValue(":UserId",id);
    query.bindValue(":FriendId",friend_id);
    query.bindValue(":GroupName",group_name);
    query.bindValue(":ExistMessage",exist_message);
    if(!query.exec()){
        qDebug() << "插入好友关系表失败: " << query.lastError();
        return false;
    }
    return true;
}

bool DataBase::insertFriendGroup(int id,QString group_name,int friend_num,int online_friend_num){
    QSqlQuery query;

    query.prepare("SELECT * FROM FriendGroup WHERE UserId = :UserId AND GroupName = :GroupName"); // 使用正确的参数名
    query.bindValue(":UserId", id); // 使用正确的参数名
    query.bindValue(":GroupName",group_name);

    if (query.exec()) {
        if (query.next()) {
            // User with ID 5 exists
            qDebug() << "插入好友组别表错误--主键重复！\n";
            return false;
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }


    query.prepare("INSERT INTO FriendGroup (UserId,GroupName,FriendNum,OnlineFriendNum) VALUES "
               "(:UserId,:GroupName,:FriendNum,:OnlineFriendNum);");
    query.bindValue(":UserId",id);
    query.bindValue(":GroupName",group_name);
    query.bindValue(":FriendNum",friend_num);
    query.bindValue(":OnlineFriendNum",online_friend_num);

    if(!query.exec()){
        qDebug() << "插入好友组别表失败: " << query.lastError();
        return false;
    }
    return true;
}

bool DataBase::insertOnlineMsgId(int senderId, int receiverId, int msgId, int msgType, QString msgTime){


    QSqlQuery query;
    std::cout << senderId << std::endl;
    query.prepare("INSERT INTO OnlineMsgId (SenderId, ReceiverId, MsgId, MsgType, MsgTime) "
                  "VALUES (:SenderId, :ReceiverId, :MsgId, :MsgType, :MsgTime)");
    query.bindValue(":SenderId", senderId);
    query.bindValue(":ReceiverId", receiverId);
    query.bindValue(":MsgId", msgId);
    query.bindValue(":MsgType", msgType);
    query.bindValue(":MsgTime", msgTime);

    return query.exec();
}

bool DataBase::insertOnlineTextMsg(int msgId, QString textContent){
    QSqlQuery query;
    query.prepare("INSERT INTO OnlineTextMsg (Id, TextContent) "
                  "VALUES (:Id, :TextContent)");
    query.bindValue(":Id", msgId);
    query.bindValue(":TextContent", textContent);

    return query.exec();
}

bool DataBase::insertOnlineAvatarMsg(int msgId, QString avatarUrl){
    QSqlQuery query;
    query.prepare("INSERT INTO OnlineAvatarMsg (Id, AvatarUrl) "
                  "VALUES (:Id, :AvatarUrl)");
    query.bindValue(":Id", msgId);
    query.bindValue(":AvatarUrl", avatarUrl);

    return query.exec();
}
bool DataBase::insertOnlineFileMsg(int msgId, QString fileName){
    QSqlQuery query;
    query.prepare("INSERT INTO OnlineFileMsg (Id, FileName) "
                  "VALUES (:Id, :FileName)");
    query.bindValue(":Id", msgId);
    query.bindValue(":FileName", fileName);

    return query.exec();
}
bool DataBase::insertGroupInfo(int groupId, QString groupAvatar,const QString &groupName, int groupPeopleNum) {
    QSqlQuery query;
    query.prepare("INSERT INTO GroupChatInfo (Id, GroupAvatar,GroupName, GroupPeopleNum) "
                  "VALUES (:groupId,:groupAvatar ,:groupName, :groupPeopleNum);");
    query.bindValue(":groupId", groupId);
    query.bindValue(":groupAvatar",groupAvatar);
    query.bindValue(":groupName", groupName);
    query.bindValue(":groupPeopleNum", groupPeopleNum);

    if (!query.exec()) {
        qDebug() << "Error inserting group info: " << query.lastError();
        return false;
    }

    return true;
}

bool DataBase::insertGroupMember(int groupId, int userId, bool existMessage) {
    QSqlQuery query;
    query.prepare("INSERT INTO GroupMember (GroupId, UserId, ExistMessage) "
                  "VALUES (:groupId, :userId, :existMessage);");
    query.bindValue(":groupId", groupId);
    query.bindValue(":userId", userId);
    query.bindValue(":existMessage", existMessage);

    if (!query.exec()) {
        qDebug() << "Error inserting group member: " << query.lastError();
        return false;
    }

    return true;
}
bool DataBase::insertFriendChatWindow(int userId, int friendId, bool isOpen) {
    QSqlQuery query;

    query.prepare("INSERT INTO FriendChatWindow (UserId, FriendId, IsOpen) VALUES (:userId, :friendId, :isOpen);");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);
    query.bindValue(":isOpen", isOpen);

    if (!query.exec()) {
        qDebug() << "Error inserting into FriendChatWindow: " << query.lastError();
        return false;
    }

    return true;
}

bool DataBase::insertMsgIsNIMING(int msgId, bool isNIMING) {
    QSqlQuery query;

    query.prepare("INSERT INTO MsgIsNIMING (MsgId, IsNIMING) VALUES (:msgId, :isNIMING)");
    query.bindValue(":msgId", msgId);
    query.bindValue(":isNIMING", isNIMING);

    if (!query.exec()) {
        qDebug() << "Error inserting into MsgIsNIMING table: " << query.lastError();
        return false;
    }

    return true;
}





MessageList DataBase::getMessagesBetweenUsers(int userId, int friendId) {
    MessageList messageList;

    QSqlQuery query;
    query.prepare("SELECT * FROM OnlineMsgId WHERE "
                  "(SenderId = :userId AND ReceiverId = :friendId) OR "
                  "(SenderId = :friendId AND ReceiverId = :userId)"
                  "ORDER BY MsgId;");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    if (query.exec()) {
        while (query.next()) {
            int msgId = query.value("MsgId").toInt();
            MessageType msgType = static_cast<MessageType>(query.value("MsgType").toInt());
            QString msgTime = query.value("MsgTime").toString();

            QString msgContent;
            if (msgType == MessageType::Text) {
                msgContent = getOnlineTextContentFromMsgId(msgId);
            } else if (msgType == MessageType::Avatar) {
                msgContent = getOnlineAvatarContentFromMsgId(msgId);
            } else if (msgType == MessageType::File) {
                msgContent = getOnlineFileContentFromMsgId(msgId);
            }

            int senderId = query.value("SenderId").toInt();
            Message message(msgType, msgId, msgContent, msgTime, senderId);
            messageList.append(message);
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }

    return messageList;
}

MessageList DataBase::getAllMessages() {
    MessageList messageList;

    QSqlQuery query;
    query.prepare("SELECT * FROM OnlineMsgId "
                  "ORDER BY MsgId;");

    if (query.exec()) {
        while (query.next()) {
            int msgId = query.value("MsgId").toInt();
            MessageType msgType = static_cast<MessageType>(query.value("MsgType").toInt());
            QString msgTime = query.value("MsgTime").toString();

            QString msgContent;
            if (msgType == MessageType::Text) {
                msgContent = getOnlineTextContentFromMsgId(msgId);
            } else if (msgType == MessageType::Avatar) {
                msgContent = getOnlineAvatarContentFromMsgId(msgId);
            } else if (msgType == MessageType::File) {
                msgContent = getOnlineFileContentFromMsgId(msgId);
            }

            int senderId = query.value("SenderId").toInt();
            Message message(msgType, msgId, msgContent, msgTime, senderId);
            messageList.append(message);
        }
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }

    return messageList;
}



QString DataBase::getOnlineTextContentFromMsgId(int msgId) {
    QString textContent;

    QSqlQuery query;
    query.prepare("SELECT TextContent FROM OnlineTextMsg WHERE Id = :msgId;");
    query.bindValue(":msgId", msgId);

    if (query.exec() && query.next()) {
        textContent = query.value(0).toString();
    } else {
        qDebug() << "Error executing query or no matching record found: " << query.lastError();
    }

    return textContent;
}

QString DataBase::getOnlineAvatarContentFromMsgId(int msgId) {
    QString avatarContent;

    QSqlQuery query;
    query.prepare("SELECT AvatarContent FROM OnlineAvatarMsg WHERE Id = :msgId;");
    query.bindValue(":msgId", msgId);

    if (query.exec() && query.next()) {
        avatarContent = query.value(0).toString();
    } else {
        qDebug() << "Error executing query or no matching record found: " << query.lastError();
    }

    return avatarContent;
}

QString DataBase::getOnlineFileContentFromMsgId(int msgId) {
    QString fileContent;

    QSqlQuery query;
    query.prepare("SELECT FileContent FROM OnlineFileMsg WHERE Id = :msgId;");
    query.bindValue(":msgId", msgId);

    if (query.exec() && query.next()) {
        fileContent = query.value(0).toString();
    } else {
        qDebug() << "Error executing query or no matching record found: " << query.lastError();
    }

    return fileContent;
}
QString DataBase::getFriendGroup(int userId, int friendId) {
    QSqlQuery query;
    query.prepare("SELECT FriendGroup FROM FriendShip WHERE UserId = :userId AND FriendId = :friendId");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    if (query.exec() && query.next()) {
        return query.value("FriendGroup").toString();
    } else {
        qDebug() << "Error while getting friend group:";
        qDebug() << query.lastError().text();
        return QString();  // 返回空字符串表示获取分组失败
    }
}

bool DataBase::getIsNIMING(int msgId) {
    QSqlQuery query;

    query.prepare("SELECT IsNIMING FROM MsgIsNIMING WHERE MsgId = :msgId");
    query.bindValue(":msgId", msgId);

    if (query.exec() && query.next()) {
        return query.value("IsNIMING").toBool();
    } else {
        qDebug() << "Error getting IsNIMING value: " << query.lastError();
        return false;  // You might want to handle this error case differently
    }
}


// 更新好友聊天窗口状态
bool DataBase::updateFriendChatWindow(int userId, int friendId, bool isOpen) {
    QSqlQuery query;

    // 更新好友聊天窗口表的状态
    query.prepare("INSERT OR REPLACE INTO FriendChatWindow (UserId, FriendId, IsOpen) "
                  "VALUES (:userId, :friendId, :isOpen);");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);
    query.bindValue(":isOpen", isOpen);

    if (!query.exec()) {
        qDebug() << "Error updating FriendChatWindow: " << query.lastError();
        return false;
    }

    return true;
}


bool DataBase::updateFriendshipExistMessage(int userId, int friendId, bool existMessage) {
    QSqlQuery query;
    query.prepare("UPDATE FriendShip SET ExistMessage = :existMessage "
                  "WHERE UserId = :userId AND FriendId = :friendId ;");

    query.bindValue(":existMessage", existMessage);
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    if (!query.exec()) {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }

    return true;
}
bool DataBase::updateFriendGroupFriendNum(int userId, QString groupName, int friendNumChange) {
    QSqlQuery query;
    query.prepare("UPDATE FriendGroup SET FriendNum = FriendNum + :friendNumChange WHERE UserId = :userId AND GroupName = :groupName");
    query.bindValue(":friendNumChange", friendNumChange);
    query.bindValue(":userId", userId);
    query.bindValue(":groupName", groupName);

    if (!query.exec()) {
        qDebug() << "Error while updating FriendGroup FriendNum:";
        qDebug() << query.lastError().text();
        return false;
    }
    return true;
}
bool DataBase::whenReceiveMessage(int userId, int friendId) {
    QSqlQuery query;

    // 查询好友窗口表的状态
    query.prepare("SELECT IsOpen FROM FriendChatWindow "
                  "WHERE UserId = :userId AND FriendId = :friendId;");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    bool isOpen = false;
    if (query.exec() && query.next()) {
        isOpen = query.value("IsOpen").toBool();
    } else {
        qDebug() << "Error getting FriendChatWindow status: " << query.lastError();
        return false;
    }

    // 查询好友关系表中的 ExistMessage 字段
    query.prepare("SELECT ExistMessage FROM FriendShip "
                  "WHERE UserId = :userId AND FriendId = :friendId;");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    bool existMessage = false;
    if (query.exec() && query.next()) {
        existMessage = query.value("ExistMessage").toBool();
    } else {
        qDebug() << "Error getting FriendShip ExistMessage: " << query.lastError();
        return false;
    }

    // 更新好友关系表中的 ExistMessage 字段

    //如果窗口是关着的，且现在没有未读消息
    if (!isOpen){
        if (!existMessage) {
            query.prepare("UPDATE FriendShip SET ExistMessage = :existMessage "
                          "WHERE UserId = :userId AND FriendId = :friendId;");
            query.bindValue(":existMessage", true);
            query.bindValue(":userId", userId);
            query.bindValue(":friendId", friendId);

            if (!query.exec()) {
                qDebug() << "Error updating FriendShip ExistMessage: " << query.lastError();
                return false;
            }
        }
    }
    return true;
}
bool DataBase::whenReceiveGroupChatMessage(int userId, int groupId){
    QSqlQuery query;

    // 查询好友窗口表的状态
    query.prepare("SELECT IsOpen FROM FriendChatWindow "
                  "WHERE UserId = :userId AND FriendId = :friendId;");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", groupId);

    bool isOpen = false;
    if (query.exec() && query.next()) {
        isOpen = query.value("IsOpen").toBool();
    } else {
        qDebug() << "Error getting FriendChatWindow status: " << query.lastError();
        return false;
    }
    if(!isOpen){
        return updateGroupMemberExistMessage(groupId,userId,true);
    }
    return true;
}

bool DataBase::whenOpenWindow(int userId,int friendId){
    QSqlQuery query;
    // 查询好友关系表中的 ExistMessage 字段
    query.prepare("SELECT ExistMessage FROM FriendShip "
                  "WHERE UserId = :userId AND FriendId = :friendId;");
    query.bindValue(":userId", userId);
    query.bindValue(":friendId", friendId);

    bool existMessage = false;
    if (query.exec() && query.next()) {
        existMessage = query.value("ExistMessage").toBool();
    } else {
        qDebug() << "Error getting FriendShip ExistMessage: " << query.lastError();
        return false;
    }
    //window状态设为打开
    updateFriendChatWindow(userId,friendId,true);

    if(existMessage){
        if(updateFriendshipExistMessage(userId,friendId,false)){
            return true;
        }else{
            return false;
        }
    }
    return true;
}


bool DataBase::whenCloseWindow(int userId,int friendID){
    return updateFriendChatWindow(userId,friendID,false);

}
bool DataBase::whenCloseGroupChatWindow(int userId,int groupId){
    return updateFriendChatWindow(userId,groupId,false);
}
bool DataBase::updateGroupMemberExistMessage(int groupId, int userId, bool existMessage) {
    QSqlQuery query;
    query.prepare("UPDATE GroupMember SET ExistMessage = :existMessage "
                  "WHERE GroupId = :groupId AND UserId = :userId;");
    query.bindValue(":existMessage", existMessage);
    query.bindValue(":groupId", groupId);
    query.bindValue(":userId", userId);

    if (!query.exec()) {
        qDebug() << "Error updating GroupMember ExistMessage: " << query.lastError();
        return false;
    }

    return true;
}
bool DataBase::updateGroupPeopleNum(int groupId, int changeAmount) {
    if (changeAmount != 1 && changeAmount != -1) {
        qDebug() << "Invalid changeAmount value. It should be either 1 or -1.";
        return false;
    }

    QSqlQuery query;

    query.prepare("UPDATE GroupChatInfo SET GroupPeopleNum = GroupPeopleNum + :changeAmount "
                  "WHERE Id = :groupId;");
    query.bindValue(":changeAmount", changeAmount);
    query.bindValue(":groupId", groupId);

    if (!query.exec()) {
        qDebug() << "Error updating GroupChatInfo GroupPeopleNum: " << query.lastError();
        return false;
    }

    return true;
}

bool DataBase::deleteGroupMember(int userId, int groupId) {
    QSqlQuery query;

    query.prepare("DELETE FROM GroupMember WHERE UserId = :userId AND GroupId = :groupId;");
    query.bindValue(":userId", userId);
    query.bindValue(":groupId", groupId);

    if (!query.exec()) {
        qDebug() << "Error deleting from GroupMember: " << query.lastError();
        return false;
    }

    return true;
}
bool DataBase::deleteMsgIsNIMING(int msgId) {
    QSqlQuery query;

    query.prepare("DELETE FROM MsgIsNIMING WHERE MsgId = :msgId");
    query.bindValue(":msgId", msgId);

    if (!query.exec()) {
        qDebug() << "Error deleting from MsgIsNIMING table: " << query.lastError();
        return false;
    }

    return true;
}

//获取某个用户的密保问题和答案
QStringList DataBase::getUserSecurityQuestion(int userId) {
    QStringList securityInfo;

    QSqlQuery query;
    query.prepare("SELECT Question, Answer FROM UserSecurityQuestionInfo WHERE UserId = :userId;");
    query.bindValue(":userId", userId);

    if (query.exec() && query.next()) {
        QString question = query.value("Question").toString();
        QString answer = query.value("Answer").toString();

        securityInfo << question << answer;
    } else {
        qDebug() << "Error executing query: " << query.lastError();
    }

    return securityInfo;
}

bool DataBase::updateUserPassword(int userId, const QString &newPassword) {
    QSqlQuery query;
    query.prepare("UPDATE UserInfo SET Password = :newPassword WHERE Id = :userId;");
    query.bindValue(":newPassword", newPassword);
    query.bindValue(":userId", userId);

    if (!query.exec()) {
        qDebug() << "Error executing query: " << query.lastError();
        return false;
    }

    return true;
}






