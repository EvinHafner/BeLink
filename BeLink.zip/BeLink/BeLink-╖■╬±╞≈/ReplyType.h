#ifndef REPLYTYPE_H
#define REPLYTYPE_H

#endif // REPLYTYPE_H
