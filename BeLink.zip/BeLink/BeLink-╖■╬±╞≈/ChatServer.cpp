#include "ChatServer.h"
#include "Request.h"
#include "RequestHandler.h"
#include <QDebug>

ChatServer::ChatServer(QObject *parent)
    : QObject(parent)
{
    server = new QTcpServer(this);
    connect(server, &QTcpServer::newConnection, this, &ChatServer::newConnection);

    if (!server->listen(QHostAddress::Any, 12345)) {
        qDebug() << "Server could not start!";
    } else {
        qDebug() << "Server started!";
    }
}

void ChatServer::newConnection()
{
    qDebug() << "用户连接操作发生" ;
    QTcpSocket *socket = server->nextPendingConnection();
    sockets.append(socket);
    connect(socket, &QTcpSocket::readyRead, this, &ChatServer::readyRead);
}

void ChatServer::readyRead()
{
    QTcpSocket *senderSocket = qobject_cast<QTcpSocket *>(sender());
    if (!senderSocket)
        return;
    QByteArray data = senderSocket->readAll();
    QString actext=data;
    qDebug() << actext;
    //Request re=RequestHandler::codeToRequest(data);
    //qDebug() << re.msgList;
    sendMessage(data);
}

void ChatServer::sendMessage(const QByteArray &message)
{
    foreach (QTcpSocket *socket, sockets)
    {
        socket->write(message);
    }
}
