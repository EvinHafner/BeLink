#ifndef REQUESTTYPE_H
#define REQUESTTYPE_H


#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include "UserInfo.h"
#include "UserInfoList.h"
#include "Message.h"
#include "MessageList.h"
#include "DataBase.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QVariant>
#include <QtDebug>
#include <QStandardPaths>
enum class RequestType: quint16{
//编码方式
/*
    四位识别码|四位数据数码|____具体数据|____具体数据|…………

    1.备注：所有布尔值都用1(true)或0(false)表示
      例如：查询用户在线状态后需要返回一个bool型变量IsOnline，在编码后就变成：0001IsOnline(00011或00010)

    2.备注：特殊类型MessageType，传递时用0（text）或1（avatar）或2（file）表示

*/
//所有客户端向服务器发送的指令 识别码第一位是0


    REGISTER_REQUEST = 1,//注册请求 需要昵称、密码、ip、密保问题、答案
    //00010005____Nickname____password____ip____SecurityQuestion____Answer
    //返回指令是1001

    LOGIN_REQUEST = 2,//登录请求 需要id、密码
    //00020002____ID____password
    //返回指令是1002~1004

    GROUP_NAMES_REQUEST = 3,//请求返回好友组名 需要用户id
    //00030001____ID
    //返回指令是1005

    FRIENDS_OF_GROUP_REQUEST = 4,//请求某一组下所有好友id 需要用户id和组名
    //00040002____ID____GroupName
    //返回指令是1006

    FRIEND_INFOMATION_REQUEST = 5,//请求某个好友的信息（昵称，头像，是否在线，是否有未读消息） 需要用户id和好友id
    //00050002____UserId____FriendId
    //返回指令是1007

    CHANGE_GTOUP_NAME_REQUEST = 6,//请求更改某个组的组名，需要用户id，旧组名，新组名
    //00060003____UserId____OldName____NewGroupName
    //返回指令是1008、1009

    CREATE_GROUP_REQUEST = 7,//请求新建好友分组，需要用户id，新建的好友组名
    //00070002____UserId____GroupName
    //返回指令是1010、1011

    CHANGE_FRIEND_GROUP_REQUEST = 8 ,//更改好友所在的分组，需要用户id，新分组名
    //00080002____UserId____FriendId____NewGroupName
    //返回指令是1012

    ADD_FRIEND_REQUEST = 9,//加好友，需要双方id
    //00090002____Id1____Id2
    //返回指令是1013,1014

    DELETE_FRIEND_REQUEST = 10,//删除好友，需要双方id
    //00100002____Id1____Id2
    //返回指令是1015

    CHANGE_AVATAR_REQUEST = 11,//更换头像，需要userid与新头像name
    //00110002____UserId____AvatarName
    //返回指令是1016
    
    CHANGE_NICKNAME_REQUEST = 12,//更换昵称，需要UserId与新昵称
    //00120002____UserId____NickName
    //返回指令是1017

    OPEN_CHAT_REQUEST = 13,//打开与某个好友的聊天页面，需要UserId与FriendId，返回好友头像、昵称、ip、消息数量与每条消息的ID
    //00130002____UserId____FriendID
    //返回指令是1018
    
    MESSAGE_INFOMATION_REQUEST = 14,//获取消息的信息，给出msgid，返回消息类型、消息内容、消息时间、消息发送者id,是否匿名
    //00140001____MsgID
    //返回指令是1019
    
    DELETE_MESSAGE_REQUEST = 15,//删除消息，给出消息id，返回成功
    //00150001____MsgID
    //返回指令是1020

    CLOSE_CHAT_REQUEST = 16,//关闭窗口时的操作，给出userId和friendId，返回成功
    //00160002____UserId____FriendId
    //返回指令是1021

    SEND_MESSAGE_REQUEST = 17,//发送消息的的请求，给出senderid，receiverid，messageType，messagecontent，msgtime，是否匿名
    //00170006____senderid____receiverid____msgType____msgContent____msgTime____isNIMING
    //返回指令是1022

    OPEN_GROUP_CHAT_REQUEST = 18,//打开群聊窗口的请求，需要userId和groupId，返回群头像，群昵称，群消息数量，每条群消息的id
    //00180002____UserId____GroupId
    //返回指令是1023

    GROUP_MEMBERS_ID_REQUEST = 19,//请求所有群成员id，需要groupId，返回所有群成员id
    //00190001____GroupId
    //返回指令是1024

    SEND_GROUP_MESSAGE_REQUEST = 20,//发送群消息请求，需要senderId，groupId，消息类型，消息内容，消息时间，是否匿名
    //00200006____senderId____GroupId____msgType____msgContent____msgTime____IsNIMING
    //返回指令是1025

    DELETE_GROUP_MESSAGE_REQUEST = 21,//删除群消息请求，需要消息id,返回成功
    //00210001____MsgId
    //返回指令是1026

    CLOSE_GROUP_CHAT_REQUEST = 22,//关闭群聊窗口的请求，需要userId和GroupId，返回成功
    //00220002____UserId____GroupId
    //返回指令是1027

    JOIN_GROUP_CHAT_REQUEST = 23,//加群请求，需要userID和groupID,返回成功
    //00230002____UserId____GroupId
    //返回指令是1028

    QUIT_GROUP_CHAT_REQUEST = 24,//退群请求，需要userId和groupId，返回成功
    //00240002____UserId____GroupId
    //返回指令是1029

    CREATE_GROUP_CHAT_REQUEST = 25,//建群请求，需要userid和群名，返回群id
    //00250002____UserId____GroupName
    //返回指令是1030

    GROUP_CHAT_INFOMATION_REQUEST = 26,//（主页面）请求群信息，需要userid和群id，返回群名、群头像、是否有未读消息
    //00260001____UserId____GroupId
    //返回指令是1031

    GROUP_CHAT_OF_USER_REQUEST = 27,//（主页面）请求某个用户群列表的所有群的id，需要userid，返回所有群id
    //00270001____UserId
    //返回指令是1032
    
    USERINFO_REQUEST = 28,//(群聊页面)请求某个用户的信息，给出id，返回昵称、头像、是否在线
    //00280001____UserId
    //返回指令是1033

    SECURITY_QUESTION_ANSWER_REQUEST = 29,//(登录页面、主页面)密保问题、答案申请，给出用户id，返回密保问题和答案
    //00290001____UserId
    //返回指令是1034

    NEW_PASSWORD_REQUEST = 30,//(忘记密码时，密保问题通过后用)，给出用户id和新密码，返回成功
    //00300002____UseriD____NewPwd
    //返回指令是1035

    CHANGE_PASSWORD_REQUEST = 31,//(记得密码时，修改密码)给出用户id、旧密码、新密码，返回成功与否
    //00310003____UserId____OldPwd____NewPwd
    //返回指令是1036



//所有服务器向客户端发送的指令 识别码第一位是1


    REGISTER_SUCCESS = 1001,//注册成功 返回用户id
    //10010001____ID
    //请求指令是0001

    LOGIN_SUCCESS = 1002,//登录成功 返回昵称、头像、ip
    //10020003____Nickname____AvatarName____ip
    //请求指令是0002

    LOGIN_FAIL_WRONG_PASSWORD = 1003,//登录失败 密码错误
    //1003
    //请求指令是0002

    LOGIN_FAIL_NO_USER = 1004,//登录失败 无此用户
    //1004
    //请求指令是0002

    GROUP_NAMES_REPLY = 1005,//返回所有好友组名
    //1005xxxx____GroupName____GroupName......
    //请求指令是0003

    FRIENDS_OF_GROUP_REPLY = 1006,//返回某组下所有好友id
    //1006xxxx____FriendId____FriendId......
    //请求指令是0004

    FRIEND_INFOMATION_REPLY = 1007,//返回某个好友的昵称、头像、是否在线、是否有未读消息
    //10070004____NickName____AvatarName0001IsOnline0001ExistMessage
    //请求指令是0005

    CHANGE_GTOUP_NAME_SUCCESS = 1008,//更改好友分组名成功
    //1008
    //请求指令是0006

    CHANGE_GTOUP_NAME_FAIL = 1009,//更改好友分组名失败，只可能是因为与现有组名重复
    //1009
    //请求指令是0006

    CREATE_GROUP_SUCCESS = 1010,//创建好友分组成功
    //1010
    //请求指令是0007

    CREATE_GROUP_FAIL = 1011,//创建好友分组失败 只可能是因为与现有组组名重复
    //1011
    //请求指令是0007

    CHANGE_FRIEND_GROUP_SUCCESS = 1012,//好友更换分组成功
    //1012
    //请求指令是0008

    ADD_FRIEND_SUCCESS = 1013,//添加好友成功
    //1013
    //请求指令是0009

    ADD_FRIEND_FAIL = 1014,//添加好友失败
    //1014
    //请求指令是0009

    DELETE_FRIEND_SUCCESS = 1015,//删除好友成功
    //1015
    //请求指令是0010

    CHANGE_AVATAR_SUCCESS = 1016,//更换头像成功
    //1016
    //请求指令是0011

    CHANGE_NICKNAME_SUCCESS = 1017,//更换昵称成功
    //1017
    //请求指令是0012

    OPEN_CHAT_REPLY = 1018,//打开聊天页面，返回好友头像、昵称、ip、消息数量与每条消息的id
    //1018xxxx____FriendAvatar____FrieNickname____FriendIp____MsgNum____MsgID____MsgID____MsgID......
    //请求指令是0013

    MESSAGE_INFOMATION_REPLY = 1019,//返回消息的类型，内容，时间，发送者id,是否匿名
    //10190005____MsgType____MsgContent____MsgTime____SenderId____IsNIMING
    //请求指令是0014

    DELETE_MESSAGE_SUCCESS = 1020,//删除消息成功
    //1020
    //请求指令是0015

    CLOSE_CHAT_SUCCESS = 1021,//关闭窗口成功
    //1021
    //请求指令是0016

    SEND_MESSAGE_REPLY = 1022,//发送消息成功，返回该条消息的id
    //10220001____msgId
    //请求指令是0017

    OPEN_GROUP_CHAT_REPLY = 1023,//打开群聊窗口的请求，返回群头像，群昵称，群消息数量，每条群消息的id
    //1023xxxx____GroupAvatar____GroupName____MsgNum____MsgID____MsgId____MsgID......
    //请求指令是0018

    GROUP_MEMBERS_ID_REPLY = 1024,//请求群内成员id列表，返回所有群成员id
    //1024XXXX____MemberId____MemberId____MemberId......
    //请求指令是0019

    SEND_GROUP_MESSAGE_REPLY = 1025,//发送消息请求回应，返回这条消息的id
    //10250001____MsgId
    //请求指令是0020

    DELETE_GROUP_MESSAGE_SUCCESS = 1026,//删除群消息请求，回应成功
    //1026
    //请求指令是0021

    CLOSE_GROUP_CHAT_SUCCESS = 1027,//关闭群聊窗口成功
    //1027
    //请求指令是0022

    JOIN_GROUP_CHAT_SUCCESS = 1028,//加群成功
    //1028
    //请求指令是0023

    QUIT_GROUP_CHAT_SUCCESS = 1029,//退群成功
    //1029
    //请求指令是0024

    CREATE_GROUP_CHAT_REPLY = 1030,//建群请求回应，返回群id
    //10300001____GroupId
    //请求指令是0025

    GROUP_CHAT_INFOMATION_REPLY = 1031,//群信息请求回应，返回群名、群头像、是否有未读消息
    //10310003____GroupName____GroupAvatar____ExistMessage
    //请求指令是0026

    GROUP_CHAT_OF_USER_REPLY = 1032,//群id请求回应，返回某个用户的所有加入的群的id
    //1032xxxx____GroupId____GroupId____GroupId......
    //请求指令是0027

    USERINFO_REPLY = 1033,//(群聊页面)请求某个用户的信息，给出id，返回昵称、头像、是否在线
    //10330003____NickName____AvatarName____IsOnline
    //请求指令是0028

    SECURITY_QUESTION_ANSWER_REPLY = 1034,//(登录页面、主页面)密保问题、答案申请，给出用户id，返回密保问题和答案
    //10340002____SecurityQues____Answer
    //请求指令是0029

    NEW_PASSWORD_REPLY = 1035,//(忘记密码时，密保问题通过后用)，给出用户id和新密码，返回成功
    //1035
    //返回指令是1035

    CHANGE_PASSWORD_SUCCESS = 1036,//(记得密码时，修改密码)返回成功
    //1036
    //返回指令是1036

    CHANGE_PASSWORD_FAIL = 1037,//(记得密码时，修改密码)原密码错误，返回失败
    //1037
    //返回指令是1037

};





#endif // REQUESTTYPE_H
