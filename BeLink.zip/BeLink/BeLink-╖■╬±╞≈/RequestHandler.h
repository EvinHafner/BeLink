#ifndef REQUESTHANDLER_H
#define REQUESTHANDLER_H

#include"RequestType.h"
#include"Request.h"
#include"GroupChatInfo.h"
#include<QMessageBox>


//请求处理类，用于处理从客户端发往服务器的信息
class RequestHandler{
public:
    //识别函数后进行统一处理
    static QByteArray allInOneHandler(const Request & request);

    /*
    //识别函数，接收传输编码，识别行为类型
    static RequestType identifyType(const QByteArray &request);
    //编码转请求，接收编码，返回封装的请求类
    static Request codeToRequest(const QByteArray &request);
    //请求转编码
    static QByteArray requestToCode(const Request & request);
    */


    //处理注册请求 0001
    static int handleRegisterRequest(const Request & request);
    //处理登录请求 0002
    static bool handleLoginRequest(const Request & request);
    //好友组名请求 0003
    static QStringList handleGroupNamesRequest(const Request & request);
    //组下好友请求处理  0004，返回该组内所有好友的ID
    static UserInfoList handleFriendOfGroupRequest(const Request & request);
    //好友信息请求处理 0005，返回好友信息
    static UserInfo handleFriendInfomationRequest(const Request & request);
    //更改组名请求处理 0006,返回bool值
    static bool handleChangeGroupNameRequest(const Request & request);
    //新建分组请求处理 0007,返回bool值
    static bool handleCreateFriendGroupRequest(const Request & request);
    //更改好友所在的分组请求处理 0008
    static bool handleFriendChangeGroupRequest(const Request & request);
    //添加好友请求处理 0009
    static bool handleAddFriendRequest(const Request &request);
    //删除好友请求处理 0010
    static bool handleDeleteFriendRequest(const Request &request);
    //更换头像请求处理 0011
    static bool handleChangeAvatarRequest(const Request &request);
    //更换昵称请求处理 0012
    static bool handleChangeNicknameRequest(const Request &request);
    //打开聊天页面请求处理 0013，返回好友头像、昵称、IP、消息数量与每条消息的ID
    static UserInfo handleOpenChatRequest(const Request &request);
    //消息信息请求处理 0014 返回消息的类型，内容，时间，senderid,是否匿名
    static Message handleMessageInfomationRequest(const Request &request);
    //删除消息请求处理 0015 给出消息id，返回成功
    static bool handleDeleteMessageRequest(const Request &request);
    //关闭窗口请求处理 0016 给出userId和FriendId，返回成功
    static bool handleCloseChatRequest(const Request &request);
    //发送消息请求 0017 给出senderid，receiverid，msgType，msgContent，msgtime
    static int handleSendMessageRequest(const Request &request);
    //打开群聊窗口请求处理 0018
    static GroupChatInfo handleOpenGroupChatRequest(const Request &request);
    //获取群成员ID请求处理 0019
    static QList<int> handleGroupChatMemberIdRequest(const Request &request);
    //发送群消息请求处理  0020
    static int handleSendGroupChatMessageRequest(const Request &request);
    //删除群消息请求处理  0021
    static void handleDeleteGroupChatMessageRequest(const Request &request);
    //关闭群聊窗口请求处理  0022
    static void handleCloseGroupChatRequest(const Request &request);
    //加入群聊请求处理 0023
    static bool handleJoinGroupChatRequest(const Request &request);
    //退出群聊请求处理 0024
    static bool handleQuitGroupChatRequest(const Request &request);
    //建群请求处理 0025
    static int handleCreateGroupChatRequest(const Request &request);
    //请求主页面群信息处理 0026
    static GroupChatInfo handleGroupChatInformationRequest(const Request &request);
    //请求某个用户所有加入的群id 0027
    static QList<int> handleGroupChatOfUserRequest(const Request &request);
    //(群聊)请求某个用户的信息，给出id，返回昵称、头像、是否在线  0028
    static UserInfo handleUserInfoRequest(const Request &request);
    //密保信息请求  0029
    static QStringList handleSecurityQuestionAnswerRequest(const Request &request);
    //（密保通过后）更换密码请求  0030
    static bool handleNewPasswordRequest(const Request &request);
    //（给出原密码的）更换密码请求  0031
    static bool handleChangePasswordRequest(const Request &request);
    
    
    
    


    //注册请求返回 1001
    static QByteArray handleRegisterReply(int ID);
    //登录请求成功返回 1002
    static QByteArray handleLoginSuccess(const Request & request);
    //登录请求失败返回 1003
    static QByteArray handleLoginFailure();
    //好友组名请求返回 1005
    static QByteArray handleGroupNamesReply(QStringList qslist);
    //组内好友请求返回 1006
    static QByteArray handleFriendOfGroupReply(UserInfoList userInfoList);
    //请求好友信息（昵称，头像，是否在线，是否有未读消息） 1007
    static QByteArray handleFriendInfomationReply(const Request & request,UserInfo userInfo);
    //更改好友分组名成功 1008
    static QByteArray handleChangeGroupNameSuccess();
    //更改好友分组名失败 1009
    static QByteArray handleChangeGroupNameFailure();
    //新建分组成功 1010
    static QByteArray handleCreateFriendGroupSuccess();
    //新建分组失败 1011
    static QByteArray handleCreateFriendGroupFailure();
    //更改好友所在的分组成功 1012
    static QByteArray handleFriendChangeGroupSuccess();
    //添加好友成功 1013
    static QByteArray handleAddFriendSuccess();
    //添加好友失败 1014
    static QByteArray handleAddFriendFailure();
    //删除好友成功 1015
    static QByteArray handleDeleteFriendSuccess();
    //更换头像成功 1016
    static QByteArray handleChangeAvatarSuccess();
    //更换昵称成功 1017
    static QByteArray handleChangeNicknameSuccess();
    //打开聊天窗口返回操作 1018
    static QByteArray handleOpenChatReply(const Request & request,UserInfo friendInfo);
    //消息信息请求返回操作 1019
    static QByteArray handleMessageInfomationReply(Message msg);
    //删除消息请求返回操作 1020
    static QByteArray handleDeleteMessageSuccess();
    //关闭窗口请求返回操作 1021
    static QByteArray handleCloseChatSuccess();
    //发送消息请求返回操作 1022
    static QByteArray handleSendMessageReply(int msgId);
    //打开群聊窗口请求返回 1023
    static QByteArray handleOpenGroupChatReply(const Request & request,GroupChatInfo groupChatInfo);
    //群成员id请求返回  1024
    static QByteArray handleGroupChatMemberIdReply(QList<int> groupMemberId);
    //发送群消息请求返回 1025
    static QByteArray handleSendGroupChatMessageReply(int groupMessageId);
    //删除群消息请求返回 1026
    static QByteArray handleDeleteGroupChatMessageReply();
    //关闭群聊窗口请求返回 1027
    static QByteArray handleCloseGroupChatReply();
    //加入群聊请求处理返回 1028
    static QByteArray handleJoinGroupChatReply();
    //退出群聊请求处理返回 1029
    static QByteArray handleQuitGroupChatReply();
    //建立群聊请求处理返回 1030
    static QByteArray handleCreateGroupChatReply(int groupChatId);
    //请求群消息处理返回 1031
    static QByteArray handleGroupChatInformationReply(const Request & request,GroupChatInfo groupChatInfo);
    //返回某个用户所有加入的群id 1032
    static QByteArray handleGroupChatOfUserReply(QList<int> groupChatIdList);
    //(群聊)请求某个用户的信息，给出id，返回昵称、头像、是否在线 返回  1033
    static QByteArray handleUserInfoReply(UserInfo groupMemberInfo);
    //密保信息请求返回  1034
    static QByteArray handleSecurityQuestionAnswerReply(QStringList securityInfo);
    //（密保通过后）更换密码请求返回成功  1035
    static QByteArray handleNewPasswordSuccess();
    //（给出原密码的）更换密码请求返回成功  1036
    static QByteArray handleChangePasswordSuccess(const Request & request);
    //（给出原密码的）更换密码请求返回失败  1037
    static QByteArray handleChangePasswordFailure();
    

};

#endif // REQUESTHANDLER_H
