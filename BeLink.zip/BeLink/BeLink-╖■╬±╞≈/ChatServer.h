#ifndef CHATSERVER_H
#define CHATSERVER_H
#include <QHostInfo>
#include <QNetworkInterface>

#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>
#include <QList>

class ChatServer : public QObject
{
    Q_OBJECT

public:
    ChatServer(QObject *parent = nullptr);

private slots:
    void newConnection();
    void readyRead();
    void sendMessage(const QByteArray &message);

private:
    QTcpServer *server;
    QList<QTcpSocket *> sockets;
};

#endif // CHATSERVER_H

