#include "ChatServer.h"
#include "DataBase.h"
#include <QApplication>
#include "mainwindow.h"
#include "Request.h"
#include "RequestHandler.h"
#include "server.h"
#include <QStyleFactory>
#include <QBuffer>
int main(int argc, char *argv[])
{

    /*QImage image(":/bizhi/TestImage.png");
    QByteArray bytes;
    QBuffer buffer(&bytes);
    image.save(&buffer, "png");
    QString base64str = QString("data:image/png;base64," + bytes.toBase64());

    std::cout << base64str.toStdString();
    buffer.close();*/










    DataBase* database = DataBase::getInstance();
    MessageList messageList = database->getMessagesBetweenUsers(10004, 10005);
    messageList.printList();
    QApplication a(argc, argv);
    a.setStyle(QStyleFactory::create("Macintosh"));
    server w;
    w.show();
    return a.exec();
}
