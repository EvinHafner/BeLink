#include<Request.h>

Request::Request(const QByteArray &request){
    codeToRequest(request);
}
Request::Request(){}

RequestType Request::identifyType(const QByteArray &request){
    QString msg=request.mid(0,4);
    quint16 ID=msg.toUInt();
    return static_cast<RequestType>(ID);
    /*if (ID==1){
        return RequestType::REGISTER_REQUEST;
    }
    else if (ID==2){
        return RequestType::LOGIN_REQUEST;
    }*/
}

void Request::codeToRequest(const QByteArray &request){
    this->requestType = identifyType(request);
    QString tmpMsgNum=request.mid(4,4);
    this->msgNum = tmpMsgNum.toUInt();
    //读取完类型和信息条数后，循环读取后面的信息具体内容
    QString pureMsg=request.mid(8);
    for(int i=0;i<this->msgNum;i++){
        quint16 length=pureMsg.mid(0,4).toUInt();
        pureMsg=pureMsg.mid(4);
        this->msgList.append(pureMsg.mid(0,length));
        pureMsg=pureMsg.mid(length);
    }
}

QByteArray Request::requestToCode(){
    QString tmpcode;
    quint16 tmpID=static_cast<int>(this->requestType);
    tmpcode=QString("%1").arg(tmpID, 4, 10, QLatin1Char('0'));
    tmpcode+=QString("%1").arg(this->msgNum, 4, 10, QLatin1Char('0'));
    for (int i=0;i<this->msgNum;i++){
        quint16 length=this->msgList[i].length();
        tmpcode+=QString("%1").arg(length, 4, 10, QLatin1Char('0'));
        tmpcode+=this->msgList[i];
    }
    return tmpcode.toUtf8();
}

QString sthToLengthString(int num)
{
    QString tmpNum=static_cast<QString>(num);
    int length=tmpNum.length();
    return QString("%1").arg(length, 4, 10, QLatin1Char('0'));
}
QString sthToLengthString(QString str)
{
    int length=str.length();
    return QString("%1").arg(length, 4, 10, QLatin1Char('0'));
}
QString sthToLengthString(QStringList qslist)
{
    int length=qslist.length();
    return QString("%1").arg(length, 4, 10, QLatin1Char('0'));
}
