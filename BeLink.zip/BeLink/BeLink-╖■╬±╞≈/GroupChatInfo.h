#ifndef GROUPCHATINFO_H
#define GROUPCHATINFO_H
#include <bits/stdc++.h>
#include<iostream>
#include <algorithm>
#include <QObject>
#include <QDebug>
class GroupChatInfo
{
public:
    GroupChatInfo(   int id = 0x0000,
                    QString name = "",
                    QString avatar_url = ""
            ): id(id), name(name), avatar_url(avatar_url){}
    int id;
    QString name;
    QString avatar_url;
};

#endif // GROUPCHATINFO_H
