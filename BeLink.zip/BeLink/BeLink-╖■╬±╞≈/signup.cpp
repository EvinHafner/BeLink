#include "signup.h"
#include "ui_signup.h"
#include "mainwindow.h"
#include <QGraphicsDropShadowEffect>
#include <QCoreApplication>
#include <QTextCodec>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QTime>
#include <QSqlError>
#include <QtDebug>
#include <QSqlDriver>
#include <QSqlRecord>
#include <QWidget>
#include <QValidator>
#include <QMessageBox>

signup::signup(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::signup)
{
    ui->setupUi(this);
    //设置背景图片
    QPixmap *pix = new QPixmap(":/bizhi/登录壁纸.jpeg");
    QSize sz = ui->beijing1->size();
    ui->beijing1->setPixmap(pix->scaled(sz));
    //设置一键清空
    ui->lineEdit_2->setClearButtonEnabled(true);
    //密码格式（由数字和26个英文字母组成的字符串）
    QRegExp regx("^[A-Za-z0-9]+$");
    QValidator *validatorName = new QRegExpValidator(regx);
    ui->lineEdit_2->setValidator(validatorName);
    ui->lineEdit_3->setValidator(validatorName);

}

signup::~signup()
{
    delete ui;
}

void signup::on_pushButton_clicked()
{
    QString username=ui->lineEdit->text();//昵称
    QString passwd=ui->lineEdit_2->text();//密码
    QString surepasswd=ui->lineEdit_3->text();//确认密码
    QString question=ui->lineEdit_4->text();//密保问题
    QString solution=ui->lineEdit_5->text();//回答

    if(username==NULL||passwd==NULL||surepasswd==NULL||question==NULL||solution==NULL)
    {
        QMessageBox::warning(this,"注册认证","内容不能为空");
    }
    else
    {
        if(passwd!=surepasswd)
        {
            QMessageBox::warning(this,"注册认证","两次密码不一致");
        }

    }


}

void signup::on_lineEdit_3_editingFinished()
{
    QString passwd=ui->lineEdit_2->text();
    QString surepasswd=ui->lineEdit_3->text();
    if(passwd!=surepasswd)
    {
        QMessageBox::warning(this,"注册认证","两次密码不一致");
    }
}
//返回登录界面
void signup::on_pushButton_2_clicked()
{
    this->close();
    MainWindow *s=new MainWindow;
    s->show();
}
