#ifndef MESSAGE_H
#define MESSAGE_H
#include <QObject>
#include <bits/stdc++.h>
enum class MessageType :int{
    Text = 0,Avatar = 1,File = 2
};

class Message{
public:
    Message(   MessageType msgType = MessageType::Text,
                int msgId = 0,
                QString msgContent = "",
                QString msgTime = "",
                int senderId = 0
            );
    MessageType getMsgType() const;
    int     getMsgID() const;
    QString getMsgContent() const;
    QString getMsgTime() const;
    int     getSenderID() const;
    
protected:
    MessageType msgType;
    int msgId;
    QString msgContent;
    QString msgTime;
    int senderId;
};

#endif // MESSAGE_H
