#include "server.h"
#include "ui_server.h"
#include <QHostInfo>
#include <QNetworkInterface>
#include <QDateTime>
#include <QMessageBox>


server::server(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::server)
{
    ui->setupUi(this);
    startServer();
}

server::~server()
{
    delete ui;
}
void sleep(unsigned int msec)
{
    //currentTime返回当前的时间，用当前的时间加上我们要延时的时间mesc得到一个新的时刻
    QTime reachTime = QTime::currentTime().addMSecs(msec);
    while(QTime::currentTime()<reachTime)
        QCoreApplication::processEvents(QEventLoop::AllEvents,100);
}

void server::refresh()
{
    // 刷新用户列表
    ui->userBrowser->clear();
    foreach (QTcpSocket *socket, sockets)
    {
        QString ipstr=socket->peerAddress().toString();
        quint16 portUint= socket->peerPort();
        QString nmsg=QString("IP: %1, port: %2").arg(ipstr).arg(portUint);

        //if(portUint == 0)
        //    sockets.removeOne(socket);

        ui->userBrowser->append(nmsg);
    }

}

void server::startServer()
{
    // 创建一个 QTcpServer 实例
    tServer = new QTcpServer(this);

    QString ipAddress = QHostInfo::localHostName();
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();

    for (const QHostAddress &address : ipAddressesList) {
        if (address.protocol() == QAbstractSocket::IPv4Protocol && !address.isLoopback())
            ipAddress = address.toString();
    }
    port = 12345;

    ui->IPText->setText(ipAddress);
    ui->PortText->setText(QString::number(port));

    //port = ui->PortText->text().toUInt();
    //if (port == 0x3f3f)
    //    QMessageBox::critical(this,"critical","错误, 请先设置端口");
    ui->messageBrowser->append("server started!");

    // 将 newConnection 信号连接到 newConnection 槽函数
    connect(tServer, &QTcpServer::newConnection, this, &server::newConnection);

    // 尝试监听任意可用 IP 地址的端口
    tServer->listen(QHostAddress::Any, port);
    if(tServer->isListening())
        ui->messageBrowser->append("now listening!");

    // 每0.5秒刷新用户列表
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(refresh()));
    timer->start(500);
}

void server::closeServer()
{
    tServer->close();
}

void server::newConnection()
{
    // 获取下一个等待连接的套接字
    QTcpSocket *socket = tServer->nextPendingConnection();

    // 将套接字添加到套接字列表中
    sockets.append(socket);

    // 连接套接字的 readyRead 信号到 readyRead 槽函数
    connect(socket, &QTcpSocket::readyRead, this, &server::readyRead);

    //
    QString ipstr=socket->peerAddress().toString();
    quint16 portUint= socket->peerPort();
    QString nmsg=QString("new user connected, IP: %1, port: %2").arg(ipstr).arg(portUint);
    ui->messageBrowser->append(nmsg);
}

void server::readyRead()
{
    // 获取发送信号的套接字
    QTcpSocket *senderSocket = qobject_cast<QTcpSocket *>(sender());
    if (!senderSocket)
        return;

    // 读取套接字的数据
    QByteArray data = senderSocket->readAll();
    QString dataStr = data;
    QStringList dataList = dataStr.split("\n");
    QHostAddress userIP = senderSocket->peerAddress();
    QString ipAddr = QString::number(userIP.toIPv4Address());

    foreach (const QString &str, dataList) {
        // 处理每个单独的字符串
        qDebug() << str;
        if(str == ""){
            continue;
        }
        Request re;
        re.codeToRequest(str.toUtf8());
        QByteArray reply = RequestHandler::allInOneHandler(re);
        QString replyStr= QString::fromUtf8(reply);
        replyStr += "\n";
        sendMessageToIP(reply, userIP);
        ui->messageBrowser->append("Received: " + str);
        QString dataMsg = QString::fromUtf8(data);
        QString attention = QString("%1: %2").arg(ipAddr).arg(dataMsg);
        ui->messageBrowser->append(attention);
        QString replyMsg = QString::fromUtf8(reply);
        ui->messageBrowser->append(replyMsg);

    }


    // // 将接收到的消息发送给user
    // sendMessage(reply, senderSocket);
    // senderSocket->write(reply);

}

void server::sendMessageToIP(const QByteArray &message, const QHostAddress &IP)
{
    foreach(QTcpSocket *socket, sockets)
    {
        if(socket->peerAddress() == IP)
            socket->write(message);
    }
}

void server::sendMessage(const QByteArray &message, QTcpSocket *senderSocket)
{
    senderSocket->write(message);
    qint16 senderPort = senderSocket->peerPort();
    QString port = QString::number(senderPort);
    QString msg = "send to" + port + ":  ";
    ui->messageBrowser->append(msg + message);
}


void server::on_pushButton_clicked()
{
     if(tServer->isListening())
        ui->messageBrowser->append("server has already started!");
    else
    {
         // 尝试监听任意可用 IP 地址的端口
         tServer->listen(QHostAddress::Any, port);
         if(tServer->isListening())
             ui->messageBrowser->append("restart to listening!");
    }
}


void server::on_pushButton_2_clicked()
{
    if(tServer->isListening())
    {
        closeServer();
        ui->messageBrowser->append("stop connecting!");
    }
    else
        ui->messageBrowser->append("server has already stoped!");
}


void server::on_pushButton_3_clicked()
{
    // sendMessageTo();
}


void server::on_checkButton_clicked()
{
    if(tServer->isListening())
    {
        ui->messageBrowser->append("still listening!");
    }
    else
        ui->messageBrowser->append("not listening!!!");
}

