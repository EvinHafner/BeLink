#ifndef USERINFO_H
#define USERINFO_H
#include <bits/stdc++.h>
#include<iostream>
#include <algorithm>
#include <QObject>
#include <QDebug>
class UserInfo{
public:
    UserInfo(   int id = 0x0000,
                QString name = "",
                QString pwd = "",
                QString avatar_url = "",
                QString ip = ""
            );
    int     getID() const;
    QString getName() const;
    QString getPwd() const;
    QString getAvatarUrl() const;
    QString getIp() const;
protected:
    int id;
    QString name;
    QString pwd;
    QString avatar_url;
    QString ip;
};




#endif // USERINFO_H
