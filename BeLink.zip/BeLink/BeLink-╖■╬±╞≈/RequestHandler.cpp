#include"RequestHandler.h"
#include <QDebug>
#include "DataBase.h"
#include<RequestType.h>

/*
RequestType RequestHandler::identifyType(const QByteArray &request){
    QString msg=request.mid(0,4);
    quint16 ID=msg.toUInt();
    return static_cast<RequestType>(ID);
//    if (ID==1){
//        return RequestType::REGISTER_REQUEST;
//    }
//    else if (ID==2){
//        return RequestType::LOGIN_REQUEST;
//    }
}

Request RequestHandler::codeToRequest(const QByteArray &request){
    Request tmpRequest;
    tmpRequest.requestType = identifyType(request);
    QString tmpMsgNum=request.mid(4,4);
    tmpRequest.msgNum = tmpMsgNum.toUInt();
    //读取完类型和信息条数后，循环读取后面的信息具体内容
    QString pureMsg=request.mid(8);
    for(int i=0;i<tmpRequest.msgNum;i++){
        quint16 length=pureMsg.mid(0,4).toUInt();
        pureMsg=pureMsg.mid(4);
        tmpRequest.msgList.append(pureMsg.mid(0,length));
        pureMsg=pureMsg.mid(length);
    }
    return tmpRequest;
}

QByteArray RequestHandler::requestToCode(const Request & request){
    QString tmpcode;
    quint16 tmpID=static_cast<int>(request.requestType);
    tmpcode=QString("%1").arg(tmpID, 4, 10, QLatin1Char('0'));
    tmpcode+=QString("%1").arg(request.msgNum, 4, 10, QLatin1Char('0'));
    for (int i=0;i<request.msgNum;i++){
        quint16 length=request.msgList[i].length();
        tmpcode+=QString("%1").arg(length, 4, 10, QLatin1Char('0'));
        tmpcode+=request.msgList[i];
    }
    return tmpcode.toUtf8();
}*/

//注册请求处理  0001，返回用户ID
int RequestHandler::handleRegisterRequest(const Request & request){
    DataBase* database = DataBase::getInstance();
    int id = database->addUserToDB(request.msgList[0],request.msgList[1],request.msgList[2],request.msgList[3],request.msgList[4]);

    return id;
}

//登录请求处理  0002，返回登录信息（true成功，false失败）
bool RequestHandler::handleLoginRequest(const Request & request){
    DataBase* database = DataBase::getInstance();
    bool loginSuccess = database->checkUserLegalByIdAndPassword(request.msgList[0].toInt(),request.msgList[1]);
    return loginSuccess;
}
//好友组名请求处理  0003，返回所有好友组名
QStringList RequestHandler::handleGroupNamesRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    QStringList qslist=database->getFriendGroupNamesById(request.msgList[0].toInt());
    return qslist;
}
//组下好友请求处理  0004，返回该组内所有好友的ID
UserInfoList RequestHandler::handleFriendOfGroupRequest(const Request & request)
{
    DataBase* database = DataBase::getInstance();
    UserInfoList userInfoList = database->getFriendInfoListByUserIDandFriendGroupName(request.msgList[0].toInt(),request.msgList[1]);
    return userInfoList;
}
//好友信息请求处理 0005，返回好友信息
UserInfo RequestHandler::handleFriendInfomationRequest(const Request & request)
{
    DataBase* database = DataBase::getInstance();
    UserInfo friendInfo = database->getUserInfoById(request.msgList[1].toInt());
    return friendInfo;
}
//更改组名请求处理 0006,返回bool值
bool RequestHandler::handleChangeGroupNameRequest(const Request & request)
{
    DataBase* database = DataBase::getInstance();
    return database->changeFriendGroupName(request.msgList[0].toInt(),request.msgList[1],request.msgList[2]);
}
//新建分组请求处理 0007,返回bool值
bool RequestHandler::handleCreateFriendGroupRequest(const Request & request)
{
    DataBase* database = DataBase::getInstance();
    return database->createFriendGroup(request.msgList[0].toInt(),request.msgList[1]);
}
//更改好友所在的分组请求处理 0008
bool RequestHandler::handleFriendChangeGroupRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    return database->changeFriendGroup(request.msgList[0].toInt(),request.msgList[1].toInt(),request.msgList[2]);
}
//添加好友请求处理 0009
bool RequestHandler::handleAddFriendRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    return database->addFriendship(request.msgList[0].toInt(),request.msgList[1].toInt());
}
//删除好友请求处理 0010
bool RequestHandler::handleDeleteFriendRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    return database->deleteFriendship(request.msgList[0].toInt(),request.msgList[1].toInt());
}
//更换头像请求处理 0011
bool RequestHandler::handleChangeAvatarRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    return database->changeAvatarByIdAndUrl(request.msgList[0].toInt(),request.msgList[1]);
}
//更换昵称请求处理 0012
bool RequestHandler::handleChangeNicknameRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    return database->changeNicknameByIdAndNewName(request.msgList[0].toInt(),request.msgList[1]);
}
//打开聊天窗口请求处理 0013
UserInfo RequestHandler::handleOpenChatRequest(const Request &request){
    DataBase* database = DataBase::getInstance();
    UserInfo userInfo = database->getUserInfoById(request.msgList[1].toInt());
    return userInfo;
}
//消息信息请求处理 0014 返回消息的类型，内容，时间，senderid，是否匿名
Message RequestHandler::handleMessageInfomationRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    Message msg = database->getMessageById(request.msgList[0].toInt());
    return msg;
}
//删除消息请求处理 0015 给出消息id，返回成功
bool RequestHandler::handleDeleteMessageRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    database->deleteFriendMessage(request.msgList[0].toInt());
    return database->deleteMsgIsNIMING(request.msgList[0].toInt());
}
//关闭窗口请求处理 0016 给出userId和FriendId，返回成功
bool RequestHandler::handleCloseChatRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    return database->whenCloseWindow(request.msgList[0].toInt(),request.msgList[1].toInt());
}
//发送消息请求 0017 给出senderid，receiverid，msgType，msgContent，msgtime,返回消息id
int RequestHandler::handleSendMessageRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    MessageType msgType;
    if(request.msgList[2] == "0"){
        msgType = MessageType::Text;
    }else if (request.msgList[2] == "1"){
        msgType = MessageType::Avatar;
    }else if (request.msgList[2] == "2"){
        msgType = MessageType::File;
    }else{
        msgType = MessageType::Text;
        qDebug() << "发送的消息类型不明确！！！";
    }
    int msgId = database->addFriendMessage(request.msgList[0].toInt(),request.msgList[1].toInt(),msgType,request.msgList[3],request.msgList[4]);
    database->insertMsgIsNIMING(msgId,false);
    return msgId;

}
//打开群聊窗口请求处理 0018
GroupChatInfo RequestHandler::handleOpenGroupChatRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    database->openGroupChatWindow(request.msgList[0].toInt(),request.msgList[1].toInt());
    GroupChatInfo groupChatInfo = database->getGroupInfoById(request.msgList[1].toInt());
    return groupChatInfo;
}
//获取群成员ID请求处理 0019
QList<int> RequestHandler::handleGroupChatMemberIdRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    QList<int> userIdsList = database->getUsersInGroup(request.msgList[0].toInt());
    return userIdsList;

}
//发送群消息请求处理  0020
int RequestHandler::handleSendGroupChatMessageRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    MessageType msgType;
    if(request.msgList[2] == "0"){
        msgType = MessageType::Text;
    }else if (request.msgList[2] == "1"){
        msgType = MessageType::Avatar;
    }else if (request.msgList[2] == "2"){
        msgType = MessageType::File;
    }else{
        msgType = MessageType::Text;
        qDebug() << "发送的消息类型不明确！！！";
    }
    int msgId = database->sendGroupChatMessage(request.msgList[0].toInt(),request.msgList[1].toInt(),msgType,request.msgList[3],request.msgList[4]);
    bool isNIMING;
    if(request.msgList[5] == "0")
    {
        isNIMING = false;
    }
    else if(request.msgList[5] == "1")
    {
        isNIMING = true;
    }else{
        qDebug() << "发送的消息类型不明确！！！";
        isNIMING = false;
    }
    database->insertMsgIsNIMING(msgId,isNIMING);
    return msgId;

}
//删除群消息请求处理  0021
void RequestHandler::handleDeleteGroupChatMessageRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    database->deleteFriendMessage(request.msgList[0].toInt());
    database->deleteMsgIsNIMING(request.msgList[0].toInt());
}
//关闭群聊窗口请求处理  0022
void RequestHandler::handleCloseGroupChatRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    database->updateFriendChatWindow(request.msgList[0].toInt(),request.msgList[1].toInt(),false);
}
//加入群聊请求处理 0023
bool RequestHandler::handleJoinGroupChatRequest(const Request &request){
    DataBase* database = DataBase::getInstance();
    database->joinGroupChat(request.msgList[0].toInt(),request.msgList[1].toInt());
    return true;
}
//退出群聊请求处理 0024
bool RequestHandler::handleQuitGroupChatRequest(const Request &request){
    DataBase* database = DataBase::getInstance();
    database->quitGroupChat(request.msgList[0].toInt(),request.msgList[1].toInt());
    return true;
}
//建群请求处理 0025
int RequestHandler::handleCreateGroupChatRequest(const Request &request){
    DataBase* database = DataBase::getInstance();
    return database->createGroupChat(request.msgList[0].toInt(),request.msgList[1]);
}
//请求主页面群信息处理 0026
GroupChatInfo RequestHandler::handleGroupChatInformationRequest(const Request &request){
    DataBase* database = DataBase::getInstance();
    return database->getGroupInfoById(request.msgList[1].toInt());
}
//请求某个用户所有加入的群id 0027
QList<int> RequestHandler::handleGroupChatOfUserRequest(const Request &request){
    DataBase* database = DataBase::getInstance();
    QList<int> groupChatIdList = database->getUserJoinedGroups(request.msgList[0].toInt());
    return groupChatIdList;
}
//(群聊)请求某个用户的信息，给出id，返回昵称、头像、是否在线  0028
UserInfo RequestHandler::handleUserInfoRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    UserInfo groupMemberInfo = database->getUserInfoById(request.msgList[0].toInt());
    return groupMemberInfo;
}
//密保信息请求  0029
QStringList RequestHandler::handleSecurityQuestionAnswerRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    QStringList securityInfo = database->getUserSecurityQuestion(request.msgList[0].toInt());
    return securityInfo;
}
//（密保通过后）更换密码请求  0030
bool RequestHandler::handleNewPasswordRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    return database->updateUserPassword(request.msgList[0].toInt(),request.msgList[1]);
}
//（给出原密码的）更换密码请求  0031
bool RequestHandler::handleChangePasswordRequest(const Request &request)
{
    DataBase* database = DataBase::getInstance();
    QString truePassword = (database->getUserInfoById(request.msgList[0].toInt())).getPwd();
    if(truePassword == request.msgList[1]){
        return true;
    }
    else{
        return false;
    }
}
















//注册请求返回  1001
QByteArray RequestHandler::handleRegisterReply(int ID)
{
    Request re;
    re.requestType = RequestType::REGISTER_SUCCESS;
    re.msgNum = 1;
    re.msgList.append(QString::number(ID));
    return re.requestToCode();
}
//登录成功后请求返回 1002
QByteArray RequestHandler::handleLoginSuccess(const Request & request){
    DataBase* database = DataBase::getInstance();
    int id = request.msgList[0].toInt();
    UserInfo userInfo =  database->getUserInfoById(id);
    Request re;
    re.msgList.append(userInfo.getName());
    re.msgList.append(userInfo.getAvatarUrl());
    re.msgList.append(userInfo.getIp());
    re.msgNum=3;
    re.requestType=RequestType::LOGIN_SUCCESS;
    return re.requestToCode();
}

//登录失败后请求返回 1003
QByteArray RequestHandler::handleLoginFailure()
{
    return "1003";
}

//好友组名请求返回 1005
QByteArray RequestHandler::handleGroupNamesReply(QStringList qslist)
{
    Request re;
    QString length=sthToLengthString(qslist);
    re.msgNum=length.toInt();
    re.msgList=qslist;
    re.requestType=RequestType::GROUP_NAMES_REPLY;
    return re.requestToCode();
}
//组内好友请求返回 1006
QByteArray RequestHandler::handleFriendOfGroupReply(UserInfoList userInfoList)
{
    Request re;
    re.requestType=RequestType::FRIENDS_OF_GROUP_REPLY;
    QStringList idlist;
    UserInfoNode *current = userInfoList.getHead();
    while(current)
    {
        int id = current->data.getID();
        idlist.append(QString::number(id));
        current = current->next;
    }
    re.msgList=idlist;
    re.msgNum=re.msgList.length();
    return re.requestToCode();
}
//请求好友信息（昵称，头像，是否在线，是否有未读消息） 1007
QByteArray RequestHandler::handleFriendInfomationReply(const Request & request,UserInfo userInfo)
{
    DataBase* database = DataBase::getInstance();
    Request re;
    re.requestType=RequestType::FRIEND_INFOMATION_REPLY;
    re.msgNum=4;
    re.msgList.append(userInfo.getName());
    re.msgList.append(userInfo.getAvatarUrl());
    bool isOnline = database->checkIsOnlineById(request.msgList[0].toInt());
    re.msgList.append(isOnline ? "1" : "0");
    bool existMessage = database->checkExistMessageById(request.msgList[0].toInt(),request.msgList[1].toInt());
    re.msgList.append(existMessage ? "1" : "0");
    return re.requestToCode();
}
//更改好友分组名成功 1008
QByteArray RequestHandler::handleChangeGroupNameSuccess()
{
    QString qstr="1008";
    return qstr.toUtf8();
}
//更改好友分组名失败 1009
QByteArray RequestHandler::handleChangeGroupNameFailure()
{
    QString qstr="1009";
    return qstr.toUtf8();
}
//新建分组成功 1010
QByteArray RequestHandler::handleCreateFriendGroupSuccess()
{
    QString qstr="1010";
    return qstr.toUtf8();
}
//新建分组失败 1011
QByteArray RequestHandler::handleCreateFriendGroupFailure()
{
    QString qstr="1011";
    return qstr.toUtf8();
}
//更改好友所在的分组成功 1012
QByteArray RequestHandler::handleFriendChangeGroupSuccess()
{
    QString qstr="1012";
    return qstr.toUtf8();
}
//添加好友成功 1013
QByteArray RequestHandler::handleAddFriendSuccess()
{
    QString qstr="1013";
    return qstr.toUtf8();
}
//添加好友失败 1014
QByteArray RequestHandler::handleAddFriendFailure()
{
    QString qstr="1014";
    return qstr.toUtf8();
}
//删除好友成功 1015
QByteArray RequestHandler::handleDeleteFriendSuccess()
{
    QString qstr="1015";
    return qstr.toUtf8();
}
//更换头像成功 1016
QByteArray RequestHandler::handleChangeAvatarSuccess()
{
    QString qstr="1016";
    return qstr.toUtf8();
}
//更换昵称成功 1017
QByteArray RequestHandler::handleChangeNicknameSuccess()
{
    QString qstr="1017";
    return qstr.toUtf8();
}
//打开聊天窗口返回操作 1018
QByteArray RequestHandler::handleOpenChatReply(const Request & request,UserInfo friendInfo)
{
    DataBase* database = DataBase::getInstance();
    MessageList messageList = database->getMessagesBetweenUsers(request.msgList[0].toInt(),friendInfo.getID());
    int messageCount = 0;
    MessageNode* current = messageList.getHead();
    while (current) {
        ++messageCount;
        current = current->next;
    }
    QStringList messageIdList;
    current = messageList.getHead();
    while (current) {
        messageIdList.append(QString::number(current->data.getMsgID()));
        current = current->next;
    }
    Request re;
    re.msgNum = 4 + messageCount;
    re.requestType = RequestType::OPEN_CHAT_REPLY;
    re.msgList.append(friendInfo.getAvatarUrl());
    re.msgList.append(friendInfo.getName());
    re.msgList.append(friendInfo.getIp());
    re.msgList.append(QString::number(messageCount));
    for(int i = 0 ; i < messageCount ; i++){
        re.msgList.append(messageIdList[i]);
    }
    return re.requestToCode();
}
//消息信息请求返回操作 1019
QByteArray RequestHandler::handleMessageInfomationReply(Message msg){
    DataBase* database = DataBase::getInstance();
    bool IsNIMING = database->getIsNIMING(msg.getMsgID());
    Request re;
    re.requestType = RequestType::MESSAGE_INFOMATION_REPLY;
    re.msgNum = 5;
    if(msg.getMsgType() == MessageType::Text){
        re.msgList.append("0");
    }else if(msg.getMsgType() == MessageType::Avatar){
        re.msgList.append("1");
    }else{
        re.msgList.append("2");
    }
    re.msgList.append(msg.getMsgContent());
    re.msgList.append(msg.getMsgTime());
    re.msgList.append(QString::number(msg.getSenderID()));
    QString IsNIMINGstr;
    if(IsNIMING == true){
        IsNIMINGstr = "1";
    }else{
        IsNIMINGstr = "0";
    }
    re.msgList.append(IsNIMINGstr);
    return re.requestToCode();
}
//删除消息请求返回操作 1020
QByteArray RequestHandler::handleDeleteMessageSuccess()
{
    QString qstr="1020";
    return qstr.toUtf8();
}
//关闭窗口请求返回操作 1021
QByteArray RequestHandler::handleCloseChatSuccess()
{
    QString qstr="1021";
    return qstr.toUtf8();
}
//发送消息请求返回操作 1022
QByteArray RequestHandler::handleSendMessageReply(int msgId){
    Request re;
    re.requestType = RequestType::SEND_MESSAGE_REPLY;
    re.msgNum = 1;
    re.msgList.append(QString::number(msgId));
    return re.requestToCode();
}
//打开群聊窗口请求返回 1023
QByteArray RequestHandler::handleOpenGroupChatReply(const Request & request,GroupChatInfo groupChatInfo)
{
    Request re;
    DataBase* database = DataBase::getInstance();
    //打开群聊时，先updatefriendchatwindow，再updateGroupMemberExistMessage，
    //然后用groupid返回groupinfo，在给出groupid，返回消息数和ids
    //QStringList msgList =
    QList<int> msgIdsList = database->getMessagesForReceiver(request.msgList[1].toInt());
    int msgIdNum = msgIdsList.size();
    QString msgIdNumStr = sthToLengthString(msgIdNum);
    re.requestType = RequestType::OPEN_CHAT_REPLY;
    re.msgNum = 3 + msgIdNum;
    re.msgList.append(groupChatInfo.avatar_url);
    re.msgList.append(groupChatInfo.name);
    for(int i = 0 ;i < msgIdNum ; i++){
        re.msgList.append(QString::number(msgIdsList[i]));
    }
    return re.requestToCode();
}
//群成员id请求返回  1024
QByteArray RequestHandler::handleGroupChatMemberIdReply(QList<int> groupMemberId)
{
    Request re;
    int groupMemberIdNum = groupMemberId.size();
    re.requestType = RequestType::GROUP_MEMBERS_ID_REPLY;
    re.msgNum = groupMemberIdNum;
    for(int i = 0 ; i < groupMemberIdNum ; i++ ){
        re.msgList.append(QString::number(groupMemberId[i]));
    }
    return re.requestToCode();
}
//发送群消息请求返回 1025
QByteArray RequestHandler::handleSendGroupChatMessageReply(int groupMessageId)
{
    Request re;
    re.requestType = RequestType::SEND_GROUP_MESSAGE_REPLY;
    re.msgNum = 1;
    re.msgList.append(QString::number(groupMessageId));
    return re.requestToCode();
}
//删除群消息请求返回 1026
QByteArray RequestHandler::handleDeleteGroupChatMessageReply()
{
    QString replystr = "1026";
    return replystr.toUtf8();
}
//关闭群聊窗口请求返回 1027
QByteArray RequestHandler::handleCloseGroupChatReply()
{
    QString replystr = "1027";
    return replystr.toUtf8();
}
//加入群聊请求处理返回 1028
QByteArray RequestHandler::handleJoinGroupChatReply(){
    QString replystr = "1028";
    return replystr.toUtf8();
}
//退出群聊请求处理返回 1029
QByteArray RequestHandler::handleQuitGroupChatReply(){
    QString replystr = "1029";
    return replystr.toUtf8();
}
//建立群聊请求处理返回 1030
QByteArray RequestHandler::handleCreateGroupChatReply(int groupChatId){
    Request re;
    re.requestType = RequestType::CREATE_GROUP_CHAT_REPLY;
    re.msgNum = 1;
    re.msgList.append(QString::number(groupChatId));
    return re.requestToCode();
}
//请求群消息处理返回 1031
QByteArray RequestHandler::handleGroupChatInformationReply(const Request &request,GroupChatInfo groupChatInfo){
    DataBase* database = DataBase::getInstance();
    bool existMsg = database->checkExistMessageInGroup(request.msgList[1].toInt(),request.msgList[0].toInt());
    QString existMsgStr;
    if(existMsg == true){
        existMsgStr = "1";
    }else if (existMsg == false){
        existMsgStr = "0";
    }else{
        printf("g!!!!!!!!!!!!!!!1\n");
        existMsgStr = "0";
    }

    Request re;
    re.requestType = RequestType::GROUP_CHAT_INFOMATION_REPLY;
    re.msgNum = 3;
    re.msgList.append(groupChatInfo.name);
    re.msgList.append(groupChatInfo.avatar_url);
    re.msgList.append(existMsgStr);
    return re.requestToCode();

}
//返回某个用户所有加入的群id 1032
QByteArray RequestHandler::handleGroupChatOfUserReply(QList<int> groupChatIdList){
    Request re;
    re.requestType = RequestType::GROUP_CHAT_OF_USER_REPLY;
    int groupChatIdNum = groupChatIdList.length();
    re.msgNum = groupChatIdNum;
    for(int i = 0 ; i < groupChatIdNum ; i++){
        re.msgList.append(QString::number(groupChatIdList[i]));
    }
    return re.requestToCode();
}
//(群聊)请求某个用户的信息，给出id，返回昵称、头像、是否在线 返回  1033
QByteArray RequestHandler::handleUserInfoReply(UserInfo groupMemberInfo)
{
    DataBase* database = DataBase::getInstance();
    Request re;
    re.requestType = RequestType::USERINFO_REPLY;
    re.msgNum = 3;
    re.msgList.append(groupMemberInfo.getName());
    re.msgList.append(groupMemberInfo.getAvatarUrl());
    if (database->checkIsOnlineById(groupMemberInfo.getID()) == true){
        re.msgList.append("1");
    }
    else if (database->checkIsOnlineById(groupMemberInfo.getID()) == false){
        re.msgList.append("0");
    }
    else{
        re.msgList.append("0");
    }
    return re.requestToCode();
}
//密保信息请求返回  1034
QByteArray RequestHandler::handleSecurityQuestionAnswerReply(QStringList securityInfo)
{
    Request re;
    re.requestType = RequestType::SECURITY_QUESTION_ANSWER_REPLY;
    re.msgNum = 2;
    re.msgList.append(securityInfo[0]);
    re.msgList.append(securityInfo[1]);
    return re.requestToCode();
}
//（密保通过后）更换密码请求返回成功  1035
QByteArray RequestHandler::handleNewPasswordSuccess()
{
    QString qstr="1035";
    return qstr.toUtf8();
}
//（给出原密码的）更换密码请求返回成功  1036
QByteArray RequestHandler::handleChangePasswordSuccess(const Request & request)
{
    DataBase* database = DataBase::getInstance();
    database->updateUserPassword(request.msgList[0].toInt(),request.msgList[2]);
    QString qstr="1036";
    return qstr.toUtf8();
}
//（给出原密码的）更换密码请求返回失败  1037
QByteArray RequestHandler::handleChangePasswordFailure()
{
    QString qstr="1037";
    return qstr.toUtf8();
}




QByteArray RequestHandler::allInOneHandler(const Request & request)
{
    QByteArray codeReply;
    //0001  1001
    if(request.requestType== RequestType::REGISTER_REQUEST)
    {
        int userID=handleRegisterRequest(request);
        codeReply=handleRegisterReply(userID);
    }
    //0002  1002 1003
    if(request.requestType== RequestType::LOGIN_REQUEST)
    {
        bool situation=handleLoginRequest(request);
        if(situation)
        {
            codeReply=handleLoginSuccess(request);
        }
        else
        {
            codeReply=handleLoginFailure();
        }
    }
    //0003  1005
    if(request.requestType == RequestType::GROUP_NAMES_REQUEST)
    {
        QStringList qslist=handleGroupNamesRequest(request);
        codeReply=handleGroupNamesReply(qslist);
    }
    //0004  1006
    if(request.requestType == RequestType::FRIENDS_OF_GROUP_REQUEST)
    {
        UserInfoList userInfoList = handleFriendOfGroupRequest(request);
        codeReply=handleFriendOfGroupReply(userInfoList);
    }
    //0005  1007
    if(request.requestType == RequestType::FRIEND_INFOMATION_REQUEST)
    {
        UserInfo userInfo = handleFriendInfomationRequest(request);
        codeReply=handleFriendInfomationReply(request,userInfo);
    }
    //0006  1008 1009
    if(request.requestType == RequestType::CHANGE_GTOUP_NAME_REQUEST)
    {
        bool situation=handleChangeGroupNameRequest(request);
        if(situation)
        {
            codeReply=handleChangeGroupNameSuccess();
        }
        else
        {
            codeReply=handleChangeGroupNameFailure();
        }
    }
    //0007  1010 1011
    if(request.requestType == RequestType::CREATE_GROUP_REQUEST)
    {
        bool situation=handleCreateFriendGroupRequest(request);
        if(situation)
        {
            codeReply=handleCreateFriendGroupSuccess();
        }
        else
        {
            codeReply=handleCreateFriendGroupFailure();
        }
    }
    //0008  1012
    if(request.requestType == RequestType::CHANGE_FRIEND_GROUP_REQUEST)
    {
        handleFriendChangeGroupRequest(request);
        codeReply=handleFriendChangeGroupSuccess();
    }
    //0009  1013 1014
    if(request.requestType == RequestType::ADD_FRIEND_REQUEST)
    {
        bool situation=handleAddFriendRequest(request);
        if(situation)
        {
            codeReply=handleAddFriendSuccess();
        }
        else
        {
            codeReply=handleAddFriendFailure();
        }
    }
    //0010  1015
    if(request.requestType == RequestType::DELETE_FRIEND_REQUEST)
    {
        handleDeleteFriendRequest(request);
        codeReply=handleFriendChangeGroupSuccess();
    }
    //0011  1016
    if(request.requestType == RequestType::CHANGE_AVATAR_REQUEST)
    {
        handleChangeAvatarRequest(request);
        codeReply=handleChangeAvatarSuccess();
    }
    //0012  1017
    if(request.requestType == RequestType::CHANGE_NICKNAME_REQUEST)
    {
        handleChangeNicknameRequest(request);
        codeReply=handleChangeNicknameSuccess();
    }
    //0013  1018
    if(request.requestType == RequestType::OPEN_CHAT_REQUEST)
    {
        UserInfo friendInfo = handleOpenChatRequest(request);
        codeReply = handleOpenChatReply(request,friendInfo);
    }
    //0014  1019
    if(request.requestType == RequestType::MESSAGE_INFOMATION_REQUEST)
    {
        Message msg = handleMessageInfomationRequest(request);
        codeReply = handleMessageInfomationReply(msg);
    }
    //0015  1020
    if(request.requestType == RequestType::DELETE_MESSAGE_REQUEST)
    {
        handleDeleteMessageRequest(request);
        codeReply = handleDeleteMessageSuccess();
    }
    //0016  1021
    if(request.requestType == RequestType::CLOSE_CHAT_REQUEST)
    {
        handleCloseChatRequest(request);
        codeReply = handleCloseChatSuccess();
    }
    //0017  1022
    if(request.requestType == RequestType::SEND_MESSAGE_REQUEST)
    {
        int msgId = handleSendMessageRequest(request);
        codeReply = handleSendMessageReply(msgId);
    }
    //0018 1023
    if(request.requestType == RequestType::OPEN_GROUP_CHAT_REQUEST)
    {
        GroupChatInfo groupChatInfo = handleOpenGroupChatRequest(request);
        codeReply = handleOpenGroupChatReply(request,groupChatInfo);
    }
    //0019 1024
    if(request.requestType == RequestType::OPEN_GROUP_CHAT_REQUEST)
    {
        QList<int> groupChatMemberId = handleGroupChatMemberIdRequest(request);
        codeReply = handleGroupChatMemberIdReply(groupChatMemberId);
    }
    //0020 1025
    if(request.requestType == RequestType::OPEN_GROUP_CHAT_REQUEST)
    {
        int groupChatMsg = handleSendGroupChatMessageRequest(request);
        codeReply = handleSendGroupChatMessageReply(groupChatMsg);
    }
    //0021 1026
    if(request.requestType == RequestType::OPEN_GROUP_CHAT_REQUEST)
    {
        handleDeleteGroupChatMessageRequest(request);
        codeReply = handleDeleteGroupChatMessageReply();
    }
    //0022 1027
    if(request.requestType == RequestType::OPEN_GROUP_CHAT_REQUEST)
    {
        handleCloseGroupChatRequest(request);
        codeReply = handleCloseGroupChatReply();
    }
    //0023 1028
    if(request.requestType == RequestType::JOIN_GROUP_CHAT_REQUEST)
    {
        handleJoinGroupChatRequest(request);
        codeReply = handleJoinGroupChatReply();
    }
    //0024 1029
    if(request.requestType == RequestType::QUIT_GROUP_CHAT_REQUEST)
    {
        handleQuitGroupChatRequest(request);
        codeReply = handleQuitGroupChatReply();
    }
    //0025 1030
    if(request.requestType == RequestType::CREATE_GROUP_CHAT_REQUEST)
    {
        int groupChatId = handleCreateGroupChatRequest(request);
        codeReply = handleCreateGroupChatReply(groupChatId);
    }
    //0026 1031
    if(request.requestType == RequestType::GROUP_CHAT_INFOMATION_REQUEST)
    {
        GroupChatInfo groupChatInfo = handleGroupChatInformationRequest(request);
        codeReply = handleGroupChatInformationReply(request,groupChatInfo);
    }
    //0027 1032
    if(request.requestType == RequestType::GROUP_CHAT_OF_USER_REQUEST)
    {
        QList<int> groupChatIdList = handleGroupChatOfUserRequest(request);
        codeReply = handleGroupChatOfUserReply(groupChatIdList);
    }
    //0028 1033
    if(request.requestType == RequestType::USERINFO_REQUEST)
    {
        UserInfo groupMemberInfo = handleUserInfoRequest(request);
        codeReply = handleUserInfoReply(groupMemberInfo);
    }
    //0029 1034
    if(request.requestType == RequestType::SECURITY_QUESTION_ANSWER_REQUEST)
    {
        QStringList securityInfo = handleSecurityQuestionAnswerRequest(request);
        codeReply = handleSecurityQuestionAnswerReply(securityInfo);
    }
    //0030 1035
    if(request.requestType == RequestType::NEW_PASSWORD_REQUEST)
    {
        handleNewPasswordRequest(request);
        codeReply = handleNewPasswordSuccess();
    }
    //0031 1036
    if(request.requestType == RequestType::CHANGE_PASSWORD_REQUEST)
    {
        bool passwordSituation = handleChangePasswordRequest(request);
        if(passwordSituation){
            codeReply = handleChangePasswordSuccess(request);
        }
        else{
            codeReply = handleChangePasswordFailure();
        }
    }
    return codeReply;
}
