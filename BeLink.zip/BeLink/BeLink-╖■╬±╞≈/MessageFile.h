#ifndef MESSAGEFILE_H
#define MESSAGEFILE_H
#include "Message.h"

class MessageFile {
public:
    MessageFile();
    QString fileCode;
    int fileSize;
    Message msg;
};




#endif // MESSAGEFILE_H
