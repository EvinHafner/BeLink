#ifndef SERVER_H
#define SERVER_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QList>
#include <QHostAddress>
#include <QTimer>
#include <Request.h>
#include <RequestHandler.h>

QT_BEGIN_NAMESPACE
namespace Ui { class server; }
QT_END_NAMESPACE

class server : public QWidget
{
    Q_OBJECT

public:
    server(QWidget *parent = nullptr);
    ~server();

private:
    Ui::server *ui;
    QTcpServer *tServer;
    QList<QTcpSocket *> sockets;

    qint16 port;
    QTimer *timer;

    void startServer();
    void closeServer();



private slots:
    void newConnection();
    void readyRead();
    void sendMessage(const QByteArray &message, QTcpSocket *senderSocket);
    void sendMessageToIP(const QByteArray &message, const QHostAddress &IP);
    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_checkButton_clicked();
    void refresh();
};
#endif // SERVER_H
