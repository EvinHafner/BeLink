#include "Message.h"

Message::Message(MessageType msgType,int msgId,QString msgContent,QString msgTime,int senderId)
    :msgType(msgType),msgId(msgId),msgContent(msgContent),msgTime(msgTime),senderId(senderId)
{
}

MessageType Message::getMsgType() const{
    return msgType;
}
int     Message::getMsgID() const{
    return msgId;
}
QString Message::getMsgContent() const{
    return msgContent;
}
QString Message::getMsgTime() const{
    return msgTime;
}
int     Message::getSenderID() const{
    return senderId;
}
