#include "UserInfo.h"

UserInfo::UserInfo(int id, QString name, QString pwd, QString avatar_url,QString ip)
    : id(id), name(name), pwd(pwd), avatar_url(avatar_url),ip(ip)
{
}

int UserInfo::getID() const {
    return id;
}

QString UserInfo::getName() const {
    return name;
}

QString UserInfo::getPwd() const {
    return pwd;
}

QString UserInfo::getAvatarUrl() const {
    return avatar_url;
}

QString UserInfo::getIp() const {
    return ip;
}
