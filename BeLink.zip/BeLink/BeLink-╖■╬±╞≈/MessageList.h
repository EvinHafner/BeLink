#ifndef MESSAGELIST_H
#define MESSAGELIST_H

#include "Message.h"  // 包含你的 Message 类的头文件
//消息链表的节点
class MessageNode {
public:
    MessageNode(Message data) : data(data), next(nullptr) {}
    Message data;
    MessageNode* next;
};
//消息链表
class MessageList {
public:
    MessageList() : head(nullptr), tail(nullptr) {}
    ~MessageList() {
        clear();
    }
    //添加
    void append(const Message& message) {
        MessageNode* newNode = new MessageNode(message);
        if (!head) {
            head = tail = newNode;
        } else {
            tail->next = newNode;
            tail = newNode;
        }
    }

    MessageNode* getHead() const {
        return head;
    }

    // 可以添加其他遍历、删除等操作
    void printList() const {
        MessageNode* current = head;
        while (current) {
            std::cout //<< "Type:" << current->data.getMsgType()
                      << " MsgId:" << current->data.getMsgID()
                      << " Content:" << current->data.getMsgContent().toStdString()
                      << " Time:" << current->data.getMsgTime().toStdString()
                      << " SenderId:" << current->data.getSenderID()
                      << std::endl;
            current = current->next;
        }
    }
    int getMaxMsgId() const{
        int max_id = 0;
        MessageNode* current = head;
        while (current) {
            int temp_id = current->data.getMsgID();
            max_id = std::max(max_id,temp_id);

            current = current->next;
        }
        return max_id;
    }
private:
    MessageNode* head;
    MessageNode* tail;

    void clear() {
        MessageNode* current = head;
        while (current) {
            MessageNode* next = current->next;
            delete current;
            current = next;
        }
        head = tail = nullptr;
    }
};

#endif // MESSAGELIST_H
