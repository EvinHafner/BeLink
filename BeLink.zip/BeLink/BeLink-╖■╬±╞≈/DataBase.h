﻿#ifndef DATABASE_H
#define DATABASE_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include "UserInfo.h"
#include "UserInfoList.h"
#include "Message.h"
#include "MessageList.h"
#include "GroupChatInfo.h"

class DataBase{//这是本软件的数据库的头文件，里面列出了所有对数据库进行的增删改查操作。
public:
    explicit DataBase();
    ~DataBase();
    static DataBase* getInstance();
    bool isDatabaseOpen() const {
            return sqldb.isOpen();
    }
    //注册模块:
    //自动分配ID和头像，昵称、密码、密保问题均不查重。
    //检查合法性后，调用该函数将用户加入数据库中，并自动生成用户Id，默认好友分组，返回成功与否
    int addUserToDB(QString nickname,QString password,QString ip,QString question,QString answer);


    //登录模块：

    //通过ID查询数据库中是否存在某用户
    bool checkUserExistById(int userId);
    //通过ID和密码检查用户身份合法性
    bool checkUserLegalByIdAndPassword(int userId,QString userPwd);
    //如果成功登录，则调用该函数利用Id完成用户在线状态的改变,返回是否成功
    bool changeUserOfflineToOnline(int userId);


    //主页面模块

    //登陆成功后，主页面需要显示头像，ip，昵称，好友分组，好友在线状态等
    //通过id获取UserInfo类，里面包括用户昵称，头像，ip
    UserInfo getUserInfoById(int userId);
    //通过id获取所有好友组名,返回链表
    QStringList getFriendGroupNamesById(int id);
    //通过id、新好友组名创建新的好友分组，不可与旧组名重复，否则会返回错误,返回成功与否
    bool createFriendGroup(int userId,QString newGroupName);
    //通过id、好友组名获取该好友组下每个好友的信息，返回UserInfo型链表
    UserInfoList getFriendInfoListByUserIDandFriendGroupName(int userId,QString friendGroupName);
    //通过id检查在线状态
    bool checkIsOnlineById(int userId);
    //通过双方id查询user是否有这个好友的未读消息
    bool checkExistMessageById(int userId,int friendId);
    //通过双方id检查双方是不是好友
    bool checkFriendship(int userId, int friendId);
    //通过双方id添加好友，此时双方都在默认分组中，返回成功与否
    bool addFriendship(int userId,int friendId);
    //通过双方id删除好友，同时也会删除好友分组中的好友位置，返回成功与否
    bool deleteFriendship(int userId,int friendId);
    //接下来就是一些更换操作
    //通过用户id和新昵称修改用户昵称，返回成功与否
    bool changeNicknameByIdAndNewName(int userId,QString newName);
    //通过用户id和新头像url来更换数据库中储存的头像url，返回成功与否
    bool changeAvatarByIdAndUrl(int userId,QString url);
    //通过用户id、旧组名和新组名来更换数据库中存储的用户好友组名，返回成功与否
    bool changeFriendGroupName(int userId,QString oldName,QString newName);
    //更换某个好友的分组
    bool changeFriendGroup(int userId, int friendId, QString newGroupName);
    //建立群聊 给出userId和GroupName,返回群聊id
    int createGroupChat(int userId,QString groupName);
    //加入群聊 给出userId和GroupId，返回成功与否
    bool joinGroupChat(int userId,int groupId);
    //退出群聊 给出userId和GroupId，返回成功与否
    bool quitGroupChat(int userId,int groupId);
    //打开群聊窗口 给出userId和群id，返回成功与否
    bool openGroupChatWindow(int userId,int groupId);
    //发送群消息 给出userid，groupid，消息类型，消息内容，消息时间，返回int
    int sendGroupChatMessage(int userId,int groupId,MessageType msgType,QString msgContent,QString msgTime);
    //给出groupid，返回group下所有user的id
    QList<int> getUsersInGroup(int groupId);
    //查询某个群的信息 返回GroupInfo类
    GroupChatInfo getGroupInfoById(int groupId);
    //给出userid，返回此user加入的所有的群的id
    QList<int> getUserJoinedGroups(int userId);

    //聊天模块

    //点击某一好友后，会打开与其的聊天框，首先需要显示好友的头像、昵称等信息，之前已经有函数getUserInfoById做到了这件事情，
    //然后需要刷新页面中的聊天记录，此处是通过双方id来获取所有聊天记录，返回的是一个Message类链表
    MessageList getMessagesBetweenUsers(int userId, int friendId);
    //每当用户发送信息，都要在消息数据表中更新数据，并且重新获得聊天记录，下面是通过类型 内容 时间+双方id来添加消息，返回成功与否
    int addFriendMessage(int UserId,int FriendId,MessageType msgType,QString msgContent,QString msgTime);
    //获取消息信息，给出msgid
    Message getMessageById(int msgId);
    //接下来就是通过Msgid来删除消息，返回成功与否
    bool deleteFriendMessage(int msgId);
    //给出receiverid，返回所有给其发的消息的msgid，适用于群聊
    QList<int> getMessagesForReceiver(int receiverId);







    //内部函数 其他模块同学无需了解yonghu

    //测试用函数,列出用户信息表
    UserInfoList getUserInfoList();
    //列出用户在线状态表
    void printAllUserOnlineStatus();
    //列出群信息表
    void printAllGroupChatInfo();
    //获取当前最大用户id
    int getMaxId();
    //获取当前最大消息id
    int getMaxMsgId();
    //查询群的最大id
    int getMaxGroupChatId();
    //给定群的id，查询是否有此群
    bool isGroupExist(int groupId);
    //查询groupmember的existmessage
    bool checkExistMessageInGroup(int groupId, int userId);

    //数据库基本操作
    //插入用户信息表
    bool insertUserInfo(int id,QString nickname,QString password,QString avatar,QString ip );
    //插入好友分组表
    bool insertFriendGroup(int id,QString group_name,int friend_num,int online_friend_num);
    //插入用户密保信息表
    bool insertUserSecurityQuesInfo(int id,QString question,QString answer);
    //插入好友关系表
    bool insertFriendShip(int id,int friend_id,QString friend_group,bool ExistMessage);
    //插入用户在线状态表
    bool insertUserOnline(int id,bool is_online);
    //插入在线消息总表
    bool insertOnlineMsgId(int senderId, int receiverId, int msgId, int msgType, QString msgTime);
    //插入在线文字消息表
    bool insertOnlineTextMsg(int msgId, QString textContent);
    //插入在线图片消息表
    bool insertOnlineAvatarMsg(int msgId, QString avatarUrl);
    //插入在线文件消息表
    bool insertOnlineFileMsg(int msgId, QString fileName);
    //插入群信息表
    bool insertGroupInfo(int groupId,QString groupAvatar, const QString &groupName, int groupPeopleNum);
    //插入群成员表
    bool insertGroupMember(int groupId, int userId, bool existMessage);
    //插入好友窗口表
    bool insertFriendChatWindow(int userId, int friendId, bool isOpen);
    //插入消息匿名表
    bool insertMsgIsNIMING(int msgId, bool isNIMING);

    //获取全部消息
    MessageList getAllMessages();
    //查询TextOnlineMsg的内容，返回字符串
    QString getOnlineTextContentFromMsgId(int msgId);
    //查询AvatarOnlineMsg的内容，返回字符串
    QString getOnlineAvatarContentFromMsgId(int msgId);
    //查询FileOnlineMsg的内容，返回字符串
    QString getOnlineFileContentFromMsgId(int msgId);
    //获取某个好友的组别
    QString getFriendGroup(int userId, int friendId);
    //获取某个用户的密保问题和答案
    QStringList getUserSecurityQuestion(int userId);


    //获取消息是否匿名
    bool getIsNIMING(int msgId);


    //更改好友窗口打开状态
    bool updateFriendChatWindow(int userId, int friendId, bool isOpen);
    //改变好友是否给我发送消息的状态
    bool updateFriendshipExistMessage(int userId, int friendId, bool existMessage);
    //更改某个User的某个friendGroup的数量，传入的int是改变量
    bool updateFriendGroupFriendNum(int userId, QString groupName, int friendNumChange);
    //当用户发来消息时对window和existmessage的操作
    bool whenReceiveMessage(int receiverId, int senderId);
    //当用户接受群的消息
    bool whenReceiveGroupChatMessage(int receiverId,int groupId);
    //当用户打开某个好友的窗口
    bool whenOpenWindow(int userId,int friendId);
    //当用户关闭某个好友的窗口
    bool whenCloseWindow(int userId,int friendID);
    //当用户关闭某个群的窗口
    bool whenCloseGroupChatWindow(int userId,int groupId);
    //更改群聊是否给我发送消息的状态
    bool updateGroupMemberExistMessage(int groupId, int userId, bool existMessage);
    //更改群聊人数
    bool updateGroupPeopleNum(int groupId, int changeAmount);
    //更改密码
    bool updateUserPassword(int userId, const QString &newPassword);


    //删除群聊成员表中信息
    bool deleteGroupMember(int userId, int groupId);
    //删除消息匿名表的信息
    bool deleteMsgIsNIMING(int msgId);
    
private:
    QSqlDatabase sqldb;
    static DataBase* db;


    DataBase(const DataBase&);
    DataBase& operator=(const DataBase&);
};


#endif // DATABASE_H
